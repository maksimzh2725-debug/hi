﻿param(
    [string]$TextFile = '',
    [string]$Target = ''
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Net.Http

# На части систем PowerShell 5.1 по умолчанию без TLS 1.2 — запросы падают
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }


Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class HotKeyApi
{
    [DllImport("user32.dll")]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);
    [DllImport("user32.dll")]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    [DllImport("user32.dll")]
    public static extern bool GetCursorPos(out POINT p);
    [DllImport("user32.dll")]
    public static extern uint GetClipboardSequenceNumber();
    public struct POINT { public int X; public int Y; }
}
"@

$script:root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:cfgFile = Join-Path $script:root 'settings.json'

$defaults = [ordered]@{
    Target       = 'Русский'
    Hotkey       = 'Ctrl+Alt+E'
    Bg1          = '#1F1F1F'
    Bg2          = '#030303'
    Accent       = '#FFFFFF'
    TextColor    = '#FFFFFF'
    FontSize     = 28
    Opacity      = 95
    ShowOriginal = $true
    CopyResult   = $true
    CloseOnEsc   = $true
    Enabled      = $true
    ShowTrayTip = $true
    TrainingText = 'Hello! How are you? I am learning to translate text with a hotkey.'
    Languages    = @('ru','en','uk','zh','ja','ur','ar','de','hi','tr','it','vi','el','th','he','sv')
    FirstRun     = $true
}

$cfg = [ordered]@{}
foreach ($k in $defaults.Keys) { $cfg[$k] = $defaults[$k] }
if (Test-Path -LiteralPath $script:cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($script:cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in $defaults.Keys) { if ($null -ne $saved.$k) { $cfg[$k] = $saved.$k } }
    } catch { }
}

. (Join-Path $script:root 'languages.ps1')

$script:languages = [ordered]@{}
$activeCodes = @()
if ($cfg.Languages) { foreach ($c in @($cfg.Languages)) { $activeCodes += Get-LanguageCode $c } }
if ($activeCodes.Count -eq 0) { $activeCodes = @('ru', 'en') }
foreach ($lang in $script:languageList) {
    if ($activeCodes -contains $lang.Code) { $script:languages[$lang.Name] = $lang.Code }
}
if ($script:languages.Count -eq 0) { $script:languages['Русский'] = 'ru' }

$script:http = New-Object Net.Http.HttpClient
$script:http.Timeout = [TimeSpan]::FromSeconds(12)
$script:http.DefaultRequestHeaders.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36')

function Get-Hex([string]$value, [string]$fallback) {
    if ($value -match '^#[0-9A-Fa-f]{6}$') { return $value }
    return $fallback
}

function Get-Brush([string]$hex, [double]$alpha = 1) {
    $b = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString((Get-Hex $hex '#FFFFFF')))
    $b.Opacity = $alpha
    return $b
}

function Get-ContrastBrush([string]$hex) {
    $r = [Convert]::ToInt32($hex.Substring(1, 2), 16)
    $g = [Convert]::ToInt32($hex.Substring(3, 2), 16)
    $b = [Convert]::ToInt32($hex.Substring(5, 2), 16)
    if ((0.299 * $r + 0.587 * $g + 0.114 * $b) -gt 150) { return Get-Brush '#111111' }
    return Get-Brush '#FFFFFF'
}

$script:popup = $null
$script:task = $null
$script:poll = New-Object Windows.Threading.DispatcherTimer
$script:poll.Interval = [TimeSpan]::FromMilliseconds(120)
$script:translation = ''
$script:requestId = 0
$script:cursorPoint = $null
$script:langIndex = 0
$script:logFile = Join-Path $script:root 'perevod-errors.log'

function Write-Log([string]$message) {
    try { [IO.File]::AppendAllText($script:logFile, ((Get-Date).ToString('HH:mm:ss') + ' ' + $message + [Environment]::NewLine)) } catch { }
}

function Get-SelectedByUia {
    try {
        Add-Type -AssemblyName UIAutomationClient
        Add-Type -AssemblyName UIAutomationTypes
        $element = [Windows.Automation.AutomationElement]::FocusedElement
        if (-not $element) { return '' }
        $pattern = $element.GetCurrentPattern([Windows.Automation.TextPattern]::Pattern)
        $ranges = $pattern.GetSelection()
        $parts = @()
        foreach ($range in $ranges) { if ($range.GetText(-1)) { $parts += $range.GetText(-1) } }
        return (($parts -join ' ').Trim())
    } catch { return '' }
}

function Read-ClipboardAfterCopy([uint32]$seq) {
    for ($i = 0; $i -lt 12; $i++) {
        Start-Sleep -Milliseconds 60
        if ([HotKeyApi]::GetClipboardSequenceNumber() -ne $seq) {
            try {
                $text = [Windows.Clipboard]::GetText()
                if ($text) { return $text }
            } catch { }
        }
    }
    return ''
}

function Get-Selection {
    $text = Get-SelectedByUia
    if ($text) { return $text }

    # Смотрим не на текст, а на номер буфера: так ловится и копия того же слова
    $seq = [HotKeyApi]::GetClipboardSequenceNumber()
    try {
        $ws = New-Object -ComObject WScript.Shell
        $ws.SendKeys('^c')
    } catch { }
    $text = Read-ClipboardAfterCopy $seq
    if ($text) { return $text }

    # Discord и подобные иногда отдают текст только по Ctrl+Insert
    $seq = [HotKeyApi]::GetClipboardSequenceNumber()
    try { $ws.SendKeys('^{INSERT}') } catch { }
    $text = Read-ClipboardAfterCopy $seq
    if ($text) { return $text }

    return ''
}

function Set-Status([string]$message) {
    if ($script:statusBlock) { $script:statusBlock.Text = $message }
}

function Set-PopupText([string]$message) { Set-Status $message }

function Update-LangButton {
    if (-not $script:langButton) { return }
    $code = @($script:languages.Values)[$script:langIndex]
    $script:langButton.Content = (Get-LanguageLabel $code) + '  ▾'
    $script:badgeBlock.Text = 'AUTO → ' + $code.ToUpper()
}

$script:python = Join-Path $script:root 'venv\Scripts\python.exe'
$script:localScript = Join-Path $script:root 'local_translate.py'
$script:offlineSupport = @('ru','en','uk','zh','ja','ar','de','hi','tr','it','vi','el','th','he','sv','ur')

$script:server = $null
$script:serverIn = $null
$script:serverOut = $null
$script:serverPath = Join-Path $script:root 'local_server.py'

function Start-LocalServer {
    try {
        Get-CimInstance Win32_Process -Filter "Name='python.exe'" | Where-Object { $_.CommandLine -like '*local_server.py*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        $psi = New-Object Diagnostics.ProcessStartInfo
        $psi.FileName = $script:python
        $psi.Arguments = '"' + $script:serverPath + '"'
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        $psi.RedirectStandardInput = $true
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
        $psi.StandardErrorEncoding = [Text.Encoding]::UTF8
        $env:PYTHONIOENCODING = 'utf-8'
        $script:server = [Diagnostics.Process]::Start($psi)
        $script:serverIn = $script:server.StandardInput.BaseStream
        $script:serverOut = $script:server.StandardOutput
    } catch {
        $script:server = $null
    }
}

function Translate-ByServer([string]$query, [string]$code) {
    if (-not $script:server -or $script:server.HasExited) { Start-LocalServer }
    if (-not $script:server -or $script:server.HasExited) { return $null }
    try {
        $json = @{ text = $query; to = $code } | ConvertTo-Json -Compress
        $bytes = [Text.Encoding]::UTF8.GetBytes($json + "`n")
        $script:serverIn.Write($bytes, 0, $bytes.Length)
        $script:serverIn.Flush()
        $line = $script:serverOut.ReadLine()
        if (-not $line) { return $null }
        $response = $line | ConvertFrom-Json
        if ($response.text) { return [string]$response.text }
        return $null
    } catch {
        return $null
    }
}

function Start-Translate {
    $text = $script:inputBox.Text.Trim()
    if (-not $text) {
        Set-Status 'Выделите слово или введите текст'
        return
    }
    $code = @($script:languages.Values)[$script:langIndex]
    if ($script:offlineSupport -notcontains $code) {
        Set-Status 'Для этого языка нет офлайн-модели'
        return
    }

    $query = $text
    if ($query.Length -gt 1200) { $query = $query.Substring(0, 1200) }
    Set-Status 'Перевод…'

    $translated = Translate-ByServer $query $code
    if (-not $translated) {
        # запасной путь: отдельный запуск, если сервер не поднялся
        try {
            $temp = Join-Path $env:TEMP ('perevod-local-' + [guid]::NewGuid().ToString('N') + '.txt')
            [IO.File]::WriteAllText($temp, $query, (New-Object Text.UTF8Encoding($false)))
            $psi = New-Object Diagnostics.ProcessStartInfo
            $psi.FileName = $script:python
            $psi.Arguments = '"' + $script:localScript + '" --to ' + $code + ' --file "' + $temp + '"'
            $psi.UseShellExecute = $false
            $psi.CreateNoWindow = $true
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
            $psi.StandardErrorEncoding = [Text.Encoding]::UTF8
            $env:PYTHONIOENCODING = 'utf-8'
            $proc = [Diagnostics.Process]::Start($psi)
            $out = $proc.StandardOutput.ReadToEnd()
            $err = $proc.StandardError.ReadToEnd()
            $proc.WaitForExit(60000) | Out-Null
            Remove-Item -LiteralPath $temp -Force -ErrorAction SilentlyContinue
            if ($proc.ExitCode -eq 0 -and $out.Trim()) { $translated = $out.Trim() }
        } catch {
            Write-Log ('local: ' + $_.Exception.Message)
        }
    }

    if (-not $translated) {
        Set-Status 'Не удалось перевести офлайн'
        return
    }

    $script:translation = $translated
    $script:resultBlock.Text = $script:translation
    if ([bool]$cfg.CopyResult) {
        try { [Windows.Clipboard]::SetText($script:translation) } catch { }
    }
    Set-Status 'Перевод готов'
}
$script:poll.Add_Tick({
    try {
    if (-not $script:task -or -not $script:task.IsCompleted) { return }
    $script:poll.Stop()
    if ($script:taskId -ne $script:requestId) { return }
    if ($script:task.IsFaulted) {
        if (Send-NextRequest) { return }
        $reason = ''
        try { $reason = $script:task.Exception.GetBaseException().Message } catch { }
        if ($reason -match '429') {
            Set-Status 'Google временно ограничил запросы — попробуйте через пару минут'
        } else {
            Set-Status 'Нет связи с переводчиком'
        }
        return
    }
    try {
        $data = $script:task.Result | ConvertFrom-Json
        $parts = @()
        foreach ($segment in $data[0]) {
            if ($segment -and $segment[0]) { $parts += [string]$segment[0] }
        }
        $script:translation = ($parts -join '')
        if (-not $script:translation) { $script:translation = '(пусто)' }
        $script:resultBlock.Text = $script:translation
        if ([bool]$cfg.CopyResult) {
            try { [Windows.Clipboard]::SetText($script:translation) } catch { }
            Set-Status 'Перевод готов'
        } else {
            Set-Status 'Перевод готов'
        }
    } catch {
        Set-Status 'Не удалось разобрать ответ'
    }
    } catch {
        Write-Log ('poll: ' + $_.Exception.Message)
    }
})

function Set-BlurBackdrop($window) {
    try {
        $src = [Windows.PresentationSource]::FromVisual($window)
        $scale = 1.0
        if ($src -and $src.CompositionTarget) { $scale = $src.CompositionTarget.TransformToDevice.M11 }
        $x = [int]($window.Left * $scale)
        $y = [int]($window.Top * $scale)
        $w = [int]($window.ActualWidth * $scale)
        $h = [int]($window.ActualHeight * $scale)
        if ($w -lt 10 -or $h -lt 10) { return }
        # Как в приветствии: снимок уменьшаем вдвое, а размытие делает BlurEffect
        $full = New-Object Drawing.Bitmap $w, $h
        $g = [Drawing.Graphics]::FromImage($full)
        $g.CopyFromScreen($x, $y, 0, 0, $full.Size)
        $g.Dispose()
        $bmp = New-Object Drawing.Bitmap ([int]($w / 2)), ([int]($h / 2))
        $g2 = [Drawing.Graphics]::FromImage($bmp)
        $g2.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
        $g2.DrawImage($full, 0, 0, $bmp.Width, $bmp.Height)
        $g2.Dispose()
        $full.Dispose()
        $ms = New-Object IO.MemoryStream
        $bmp.Save($ms, [Drawing.Imaging.ImageFormat]::Png)
        $bmp.Dispose()
        $ms.Position = 0
        $img = New-Object Windows.Media.Imaging.BitmapImage
        $img.BeginInit()
        $img.StreamSource = $ms
        $img.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $img.EndInit()
        $img.Freeze()
        $script:backImage.Source = $img
    } catch { }
}

function Show-Popup([string]$text) {
    if ($script:popup -and $script:popup.IsVisible) {
        try { $script:popup.Hide() } catch { }
    }
    $script:translation = ''

    $font = [math]::Min(20, [math]::Max(14, [int]$cfg.FontSize))
    $xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True"
        ShowInTaskbar="False" SizeToContent="Height" Width="380" MaxHeight="420" WindowStartupLocation="Manual"
        FontFamily="Segoe UI">
    <Window.Resources>
        <Style x:Key="Flat" TargetType="Button">
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" Background="{TemplateBinding Background}" CornerRadius="6" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Opacity" Value="0.75"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>
    <Grid>
        <Canvas ClipToBounds="True">
            <Image x:Name="BackImage" Stretch="Fill">
                <Image.Effect>
                    <BlurEffect Radius="30" KernelType="Gaussian" RenderingBias="Performance"/>
                </Image.Effect>
            </Image>
        </Canvas>
        <Border x:Name="Root" CornerRadius="14" BorderThickness="1" Padding="12,9">
            <StackPanel>
                <DockPanel>
                    <Button x:Name="BtnClose" Content="✕" FontSize="11" Width="22" Height="22" Padding="0" Style="{StaticResource Flat}"
                            BorderThickness="0" DockPanel.Dock="Right" VerticalAlignment="Center"/>
                    <Border x:Name="Badge" CornerRadius="7" Padding="6,2" Margin="6,0,0,0" VerticalAlignment="Center"
                            DockPanel.Dock="Left">
                        <TextBlock x:Name="BadgeText" Text="AUTO → RU" FontSize="10"/>
                    </Border>
                    <Button x:Name="BtnLang" Content="Русский  ▾" FontSize="11" Height="22" Padding="8,0" Style="{StaticResource Flat}"
                            BorderThickness="0" DockPanel.Dock="Left"/>
                </DockPanel>
                <Border x:Name="LangPanel" Visibility="Collapsed" Margin="0,6,0,0" CornerRadius="8" Padding="6">
                    <ScrollViewer MaxHeight="150" VerticalScrollBarVisibility="Auto"><WrapPanel x:Name="LangList"/></ScrollViewer>
                </Border>
                <TextBox x:Name="TxtInput" Margin="0,8,0,0" Padding="7,5" FontSize="12" BorderThickness="0"
                         TextWrapping="Wrap" AcceptsReturn="False" MaxHeight="60"/>
                <TextBlock x:Name="Result" TextWrapping="Wrap" FontSize="$font" Margin="0,7,0,0" FontWeight="Light"/>
                <DockPanel Margin="0,9,0,0">
                    <Button x:Name="BtnCopy" Content="Скопировать перевод" Padding="10,4" BorderThickness="0" FontSize="11" Style="{StaticResource Flat}"/>
                    <TextBlock x:Name="Status" VerticalAlignment="Center" Margin="8,0,0,0" FontSize="10" Opacity="0.7"/>
                </DockPanel>
            </StackPanel>
        </Border>
    </Grid>
</Window>
"@
    $window = [Windows.Markup.XamlReader]::Parse($xaml)
    $root = $window.FindName('Root')
    $badge = $window.FindName('Badge')
    $badgeText = $window.FindName('BadgeText')
    $inputBox = $window.FindName('TxtInput')
    $result = $window.FindName('Result')
    $btnLang = $window.FindName('BtnLang')
    $btnCopy = $window.FindName('BtnCopy')
    $btnClose = $window.FindName('BtnClose')
    $status = $window.FindName('Status')

    $bg1 = Get-Hex ([string]$cfg.Bg1) '#1F1F1F'
    $bg2 = Get-Hex ([string]$cfg.Bg2) '#030303'
    $accent = Get-Hex ([string]$cfg.Accent) '#FFFFFF'
    $textColor = Get-Hex ([string]$cfg.TextColor) '#FFFFFF'

    $overlay = New-Object Windows.Media.LinearGradientBrush
    $overlay.StartPoint = New-Object Windows.Point 0, 0
    $overlay.EndPoint = New-Object Windows.Point 1, 1
    $c1 = [Windows.Media.ColorConverter]::ConvertFromString($bg1)
    $c2 = [Windows.Media.ColorConverter]::ConvertFromString($bg2)
    $c1.A = 95
    $c2.A = 120
    $overlay.GradientStops.Add((New-Object Windows.Media.GradientStop ($c1, 0)))
    $overlay.GradientStops.Add((New-Object Windows.Media.GradientStop ($c2, 1)))
    $root.Background = $overlay
    $root.BorderBrush = Get-Brush $accent 0.35

    $textBrush = Get-Brush $textColor
    $muted = Get-Brush $textColor 0.6
    foreach ($element in @($badgeText, $result)) { $element.Foreground = $textBrush }
    $status.Foreground = $muted
    $badge.Background = Get-Brush $accent 0.16

    $inputBox.Background = Get-Brush $textColor 0.1
    $inputBox.Foreground = $textBrush
    $inputBox.CaretBrush = $textBrush

    $darkButton = Get-Brush '#2A2E34'
    foreach ($button in @($btnLang, $btnClose)) {
        $button.Background = $darkButton
        $button.Foreground = $textBrush
    }
    $btnCopy.Background = Get-Brush $accent 0.9
    $btnCopy.Foreground = Get-ContrastBrush $accent

    $script:popup = $window
    $script:badge = $badge
    $script:badgeBlock = $badgeText
    $script:langButton = $btnLang
    $script:inputBox = $inputBox
    $script:resultBlock = $result
    $script:statusBlock = $status
    $script:backImage = $window.FindName('BackImage')

    $script:langPanel = $window.FindName('LangPanel')
    $script:langList = $window.FindName('LangList')
    $script:langPanel.Background = Get-Brush '#23262B'
    $index = 0
    foreach ($name in $script:languages.Keys) {
        $item = New-Object Windows.Controls.Button
        $item.Content = Get-LanguageLabel $script:languages[$name]
        $item.Tag = $index
        $item.FontSize = 11
        $item.Padding = '8,3'
        $item.Margin = '0,0,5,5'
        $item.BorderThickness = 0
        $item.Style = $window.FindResource('Flat')
        $item.Background = Get-Brush '#2F343B'
        $item.Foreground = $textBrush
        $item.Add_Click({
            param($sender, $eventArgs)
            try {
                $script:langIndex = [int]$sender.Tag
                $script:langPanel.Visibility = 'Collapsed'
                Update-LangButton
                Start-Translate
            } catch { Write-Log ('lang: ' + $_.Exception.Message) }
        })
        $script:langList.Children.Add($item) | Out-Null
        $index++
    }
    $btnLang.Add_Click({
        try {
            if ($script:langPanel.Visibility -eq 'Visible') { $script:langPanel.Visibility = 'Collapsed' }
            else { $script:langPanel.Visibility = 'Visible' }
        } catch { Write-Log ('langpanel: ' + $_.Exception.Message) }
    })

    $targetValue = [string]$cfg.Target
    if ($Target) { $targetValue = $Target }
    $targetCode = Get-LanguageCode $targetValue
    $langIndex = [Array]::IndexOf(@($script:languages.Values), $targetCode)
    if ($langIndex -lt 0) { $langIndex = 0 }
    $script:langIndex = $langIndex
    Update-LangButton

    $inputBox.Text = $text
    $inputBox.ToolTip = 'Выделите текст или введите слово и нажмите Enter'

    $inputBox.Add_KeyDown({
        param($sender, $eventArgs)
        try {
            if ($eventArgs.Key -eq 'Enter') { Start-Translate; $eventArgs.Handled = $true }
        } catch { Write-Log ('input: ' + $_.Exception.Message) }
    })
    $btnCopy.Add_Click({
        try {
            if (-not $script:translation) { return }
            try {
                [Windows.Clipboard]::SetText($script:translation)
                Set-Status 'Скопировано'
                $script:statusBlock.BeginAnimation([Windows.UIElement]::OpacityProperty, $null)
                $script:statusBlock.Opacity = 0.85
                if ($script:statusTimer) { $script:statusTimer.Stop(); $script:statusTimer.Start() }
            } catch { Set-Status 'Буфер занят' }
        } catch { Write-Log ('copy: ' + $_.Exception.Message) }
    })
    $btnClose.Add_Click({ $window.Hide() })


    # Показываем прозрачным, чтобы захватить фон без самого окна
    $script:statusTimer = New-Object Windows.Threading.DispatcherTimer
    $script:statusTimer.Interval = [TimeSpan]::FromMilliseconds(1200)
    $script:statusTimer.Add_Tick({
        $script:statusTimer.Stop()
        if (-not $script:statusBlock) { return }
        $fade = New-Object Windows.Media.Animation.DoubleAnimation(0.0, [TimeSpan]::FromMilliseconds(600))
        $script:statusBlock.BeginAnimation([Windows.UIElement]::OpacityProperty, $fade)
    })

    $rootGrid = $window.FindName('RootGrid')
    $script:popupGrid = $rootGrid
    $script:popupWindow = $window

    $window.Opacity = 0
    $work = [Windows.SystemParameters]::WorkArea
    $window.Left = $work.Left + 40
    $window.Top = $work.Top + 40
    $window.Show()
    $window.UpdateLayout()

    $width = $window.ActualWidth
    $height = $window.ActualHeight
    $left = $work.Left + ($work.Width - $width) / 2
    $top = $work.Top + ($work.Height - $height) / 2
    if ($script:cursorPoint) {
        $left = $script:cursorPoint.X - $width / 2
        $top = $script:cursorPoint.Y - $height - 16
        if ($top -lt $work.Top + 8) { $top = $script:cursorPoint.Y + 24 }
    }
    if ($left -lt $work.Left + 8) { $left = $work.Left + 8 }
    $maxLeft = $work.Left + $work.Width - $width - 8
    if ($left -gt $maxLeft) { $left = $maxLeft }
    $maxTop = $work.Top + $work.Height - $height - 8
    if ($top -gt $maxTop) { $top = $maxTop }
    $window.Left = $left
    $window.Top = $top
    $window.UpdateLayout()

    # скругляем и сам фон, иначе при другом окне под переводчиком видны прямые углы
    $applyClip = {
        if (-not $script:popupGrid -or -not $script:popupWindow) { return }
        $w = $script:popupWindow.ActualWidth
        $h = $script:popupWindow.ActualHeight
        if ($w -lt 1 -or $h -lt 1) { return }
        $script:popupGrid.Clip = New-Object Windows.Media.RectangleGeometry((New-Object Windows.Rect(0, 0, $w, $h)), 14, 14)
    }
    & $applyClip
    $window.Add_SizeChanged({ & $applyClip })

    $back = $script:backImage
    $back.Width = $width + 80
    $back.Height = $height + 80
    [Windows.Controls.Canvas]::SetLeft($back, -40)
    [Windows.Controls.Canvas]::SetTop($back, -40)

    Set-BlurBackdrop $window
    $window.Opacity = [double]$cfg.Opacity / 100.0
    $window.Activate() | Out-Null

    if ($inputBox.Text) {
        Start-Translate
    } else {
        Set-Status 'Выделите слово или введите текст'
        $inputBox.Focus() | Out-Null
    }
}

function Convert-Hotkey([string]$value) {
    $mods = 0
    $key = $null
    foreach ($part in ($value -split '\+')) {
        $name = $part.Trim()
        switch -Regex ($name) {
            '^(Ctrl|Control)$' { $mods = $mods -bor 0x2; continue }
            '^Alt$'            { $mods = $mods -bor 0x1; continue }
            '^Shift$'          { $mods = $mods -bor 0x4; continue }
            '^Win$'            { $mods = $mods -bor 0x8; continue }
            default            { $key = $name }
        }
    }
    if (-not $key) { return $null }
    try { $vk = [int][Windows.Forms.Keys]$key } catch { return $null }
    if ($vk -le 0) { return $null }
    return @{ Mods = [uint32]$mods; Key = [uint32]$vk }
}

# Одиночный запуск с готовым текстом (из настроек) — без горячей клавиши
if ($TextFile) {
    $text = ''
    if (Test-Path -LiteralPath $TextFile) { $text = [IO.File]::ReadAllText($TextFile, [Text.Encoding]::UTF8) }
    if (-not $text) { $text = [string]$cfg.TrainingText }
    Show-Popup $text
    [Windows.Threading.Dispatcher]::Run()
Write-Log 'dispatcher returned'
    return
}

$created = $false
$mutex = New-Object Threading.Mutex($true, 'Local\PerevodHotkey', [ref]$created)
if (-not $created) { return }

# Первый запуск — показываем, что умеет переводчик
$marker = Join-Path $script:root 'about-shown.txt'
if (-not (Test-Path -LiteralPath $marker)) {
    $about = Join-Path $script:root 'WhatsNew.ps1'
    if (Test-Path -LiteralPath $about) {
        try {
            Start-Process -FilePath 'powershell.exe' -ArgumentList @('-Sta', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $about + '"'))
        } catch { }
    }
    try { [IO.File]::WriteAllText($marker, 'ok') } catch { }
}

$hostWindow = New-Object Windows.Window
$hostWindow.Width = 1
$hostWindow.Height = 1
$hostWindow.Left = -200
$hostWindow.Top = -200
$hostWindow.WindowStyle = 'None'
$hostWindow.ShowInTaskbar = $false
$hostWindow.ShowActivated = $false
$hostWindow.Show()
$handle = (New-Object Windows.Interop.WindowInteropHelper($hostWindow)).Handle

$hotkey = Convert-Hotkey ([string]$cfg.Hotkey)
$registered = $false
if ($hotkey -and [bool]$cfg.Enabled) {
    $registered = [HotKeyApi]::RegisterHotKey($handle, 1, $hotkey.Mods, $hotkey.Key)
}

$source = [Windows.Interop.HwndSource]::FromHwnd($handle)
$source.AddHook({
    param($hwnd, $msg, $wParam, $lParam, [ref]$handled)
    if ($msg -eq 0x0312) {
        $handled.Value = $true
        try {
            if ($script:popup -and $script:popup.IsVisible) {
                Set-PopupText 'Клавиша нажата, ждите перевод'
                return
            }
            $point = New-Object HotKeyApi+POINT
            [void][HotKeyApi]::GetCursorPos([ref]$point)
            $script:cursorPoint = @{ X = $point.X; Y = $point.Y }
            $text = Get-Selection
            Show-Popup $text
        } catch {
            Write-Log ('hotkey: ' + $_.Exception.Message)
        }
    }
})

# Значок в трее, чтобы было видно, что программа запущена
try {
    $tray = New-Object Windows.Forms.NotifyIcon
    $tray.Icon = [Drawing.SystemIcons]::Application
    $tray.Text = 'Переводчик ' + [string]$cfg.Hotkey
    $menu = New-Object Windows.Forms.ContextMenuStrip
    $itemSettings = $menu.Items.Add('Настройки')
    $itemSettings.Add_Click({ try { Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $script:root 'launch.vbs') + '"') } catch { } })
    $itemExit = $menu.Items.Add('Выход')
    $itemExit.Add_Click({ try { $tray.Visible = $false; $tray.Dispose() } catch { }; [Environment]::Exit(0) })
    $tray.ContextMenuStrip = $menu
    $tray.Visible = $true
    $tray.Add_DoubleClick({ try { Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $script:root 'launch.vbs') + '"') } catch { } })
    if ([bool]$cfg.ShowTrayTip) {
        if ($registered) {
            $tray.ShowBalloonTip(4000, 'Переводчик запущен', 'Выделите текст и нажмите ' + [string]$cfg.Hotkey, [Windows.Forms.ToolTipIcon]::Info)
        } else {
            $tray.ShowBalloonTip(6000, 'Клавиша занята', 'Смените клавишу в настройках', [Windows.Forms.ToolTipIcon]::Warning)
        }
    }
} catch { }

if (-not $registered) {
    Show-Popup ('Клавиша ' + [string]$cfg.Hotkey + ' занята другой программой.')
}

Start-LocalServer
[Windows.Threading.Dispatcher]::Run()
try { if ($script:server -and -not $script:server.HasExited) { $script:server.StandardInput.Close() } } catch { }
Write-Log 'dispatcher returned'
