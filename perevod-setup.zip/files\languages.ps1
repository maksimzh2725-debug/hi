﻿$script:languageList = @(
    [pscustomobject]@{ Code = 'ru'; Name = 'Русский';     Native = 'Русский' },
    [pscustomobject]@{ Code = 'en'; Name = 'Английский';  Native = 'English' },
    [pscustomobject]@{ Code = 'uk'; Name = 'Украинский';  Native = 'Українська' },
    [pscustomobject]@{ Code = 'zh'; Name = 'Китайский';   Native = '中文' },
    [pscustomobject]@{ Code = 'ja'; Name = 'Японский';    Native = '日本語' },
    [pscustomobject]@{ Code = 'ur'; Name = 'Урду';        Native = 'اردو' },
    [pscustomobject]@{ Code = 'ar'; Name = 'Арабский';    Native = 'العربية' },
    [pscustomobject]@{ Code = 'de'; Name = 'Немецкий';    Native = 'Deutsch' },
    [pscustomobject]@{ Code = 'hi'; Name = 'Хинди';       Native = 'हिन्दी' },
    [pscustomobject]@{ Code = 'tr'; Name = 'Турецкий';    Native = 'Türkçe' },
    [pscustomobject]@{ Code = 'it'; Name = 'Итальянский'; Native = 'Italiano' },
    [pscustomobject]@{ Code = 'vi'; Name = 'Вьетнамский'; Native = 'Tiếng Việt' },
    [pscustomobject]@{ Code = 'el'; Name = 'Греческий';   Native = 'Ελληνικά' },
    [pscustomobject]@{ Code = 'th'; Name = 'Тайский';     Native = 'ไทย' },
    [pscustomobject]@{ Code = 'he'; Name = 'Иврит';       Native = 'עברית' },
    [pscustomobject]@{ Code = 'sv'; Name = 'Шведский';    Native = 'Svenska' }
)

function Get-LanguageLabel([string]$code) {
    foreach ($lang in $script:languageList) {
        if ($lang.Code -eq $code) { return $lang.Name + ' (' + $lang.Native + ')' }
    }
    return $code
}

function Get-LanguageCode([string]$value) {
    $v = ([string]$value).Trim()
    foreach ($lang in $script:languageList) {
        if ($lang.Code -eq $v -or $lang.Name -eq $v) { return $lang.Code }
    }
    return 'ru'
}
