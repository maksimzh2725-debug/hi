﻿$ErrorActionPreference = 'Stop'

$source = Join-Path $PSScriptRoot 'files'
if (-not (Test-Path -LiteralPath $source)) {
    Write-Host 'Не найдена папка files рядом с установщиком.' -ForegroundColor Red
    Read-Host 'Нажмите Enter'
    exit 1
}

$target = Join-Path $env:LOCALAPPDATA 'Perevod'
New-Item -ItemType Directory -Path $target -Force | Out-Null

$hadSettings = Test-Path -LiteralPath (Join-Path $target 'settings.json')
foreach ($item in @(Get-ChildItem -LiteralPath $source -File)) {
    if ($hadSettings -and $item.Name -eq 'settings.json') { continue }
    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $target $item.Name) -Force
}

# Python нужен один раз: движок и модели скачиваются при установке
$python = $null
foreach ($name in @('python.exe', 'py.exe')) {
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd) { $python = $cmd.Source; break }
}

if (-not $python) {
    Write-Host ''
    Write-Host 'Для офлайн-перевода нужен Python 3.10 или новее.' -ForegroundColor Yellow
    Write-Host 'Скачайте с https://www.python.org/downloads/ и запустите установщик заново.'
    Read-Host 'Нажмите Enter'
    exit 1
}

$venv = Join-Path $target 'venv'
$vpy = Join-Path $venv 'Scripts\python.exe'
if (-not (Test-Path -LiteralPath $vpy)) {
    Write-Host 'Готовлю окружение…' -ForegroundColor Cyan
    & $python -m venv $venv
}

Write-Host 'Скачиваю движок перевода (это займёт несколько минут)…' -ForegroundColor Cyan
& $vpy -m pip install --upgrade pip --quiet
& $vpy -m pip install argostranslate langdetect --quiet

$argospm = Join-Path $venv 'Scripts\argospm.exe'
$codes = @('ru', 'uk', 'zh', 'ja', 'ur', 'ar', 'de', 'hi', 'tr', 'it', 'vi', 'el', 'th', 'he', 'sv')
Write-Host 'Скачиваю языковые модели…' -ForegroundColor Cyan
& $argospm update | Out-Null
foreach ($code in $codes) {
    & $argospm install "translate-en_$code" | Out-Null
    & $argospm install "translate-${code}_en" | Out-Null
}

$wscript = Join-Path $env:WINDIR 'System32\wscript.exe'
$shell = New-Object -ComObject WScript.Shell

$desktop = [Environment]::GetFolderPath('Desktop')
$lnk = $shell.CreateShortcut((Join-Path $desktop 'Перевод (настройка).lnk'))
$lnk.TargetPath = $wscript
$lnk.Arguments = '"' + (Join-Path $target 'launch.vbs') + '"'
$lnk.WorkingDirectory = $target
$lnk.Description = 'Настройка переводчика'
$lnk.Save()

$startup = [Environment]::GetFolderPath('Startup')
$lnk2 = $shell.CreateShortcut((Join-Path $startup 'Перевод.lnk'))
$lnk2.TargetPath = $wscript
$lnk2.Arguments = '"' + (Join-Path $target 'Translate.vbs') + '"'
$lnk2.WorkingDirectory = $target
$lnk2.Description = 'Перевод по клавише'
$lnk2.Save()

Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $target 'Translate.vbs') + '"')
$about = Join-Path $target 'WhatsNew.ps1'
if (Test-Path -LiteralPath $about) {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-Sta', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $about + '"'))
}

Write-Host ''
Write-Host "Готово. Программа установлена в: $target" -ForegroundColor Green
Write-Host 'Перевод работает без интернета. Клавиша: Ctrl+Alt+Q.'
exit 0
