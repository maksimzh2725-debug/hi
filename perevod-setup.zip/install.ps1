﻿$ErrorActionPreference = 'Stop'

$source = Join-Path $PSScriptRoot 'files'
if (-not (Test-Path -LiteralPath $source)) {
    Write-Host 'Не найдена папка files рядом с установщиком.' -ForegroundColor Red
    Read-Host 'Нажмите Enter'
    exit 1
}

$target = Join-Path $env:LOCALAPPDATA 'Perevod'
New-Item -ItemType Directory -Path $target -Force | Out-Null

$hadSettings = Test-Path -LiteralPath (Join-Path $target 'settings.json')
foreach ($item in @(Get-ChildItem -LiteralPath $source -File)) {
    if ($hadSettings -and $item.Name -eq 'settings.json') { continue }
    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $target $item.Name) -Force
}

$wscript = Join-Path $env:WINDIR 'System32\wscript.exe'
$shell = New-Object -ComObject WScript.Shell

$desktop = [Environment]::GetFolderPath('Desktop')
$lnk = $shell.CreateShortcut((Join-Path $desktop 'Перевод (настройка).lnk'))
$lnk.TargetPath = $wscript
$lnk.Arguments = '"' + (Join-Path $target 'launch.vbs') + '"'
$lnk.WorkingDirectory = $target
$lnk.Description = 'Настройка переводчика'
$lnk.Save()

$startup = [Environment]::GetFolderPath('Startup')
$lnk2 = $shell.CreateShortcut((Join-Path $startup 'Перевод.lnk'))
$lnk2.TargetPath = $wscript
$lnk2.Arguments = '"' + (Join-Path $target 'Translate.vbs') + '"'
$lnk2.WorkingDirectory = $target
$lnk2.Description = 'Перевод по клавише'
$lnk2.Save()

Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $target 'Translate.vbs') + '"')
$about = Join-Path $target 'WhatsNew.ps1'
if (Test-Path -LiteralPath $about) {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-Sta', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $about + '"'))
}

Write-Host ''
Write-Host "Готово. Программа установлена в: $target" -ForegroundColor Green
Write-Host 'На рабочем столе: «Перевод (настройка)».'
Write-Host 'Клавиша перевода: Ctrl+Alt+Q (перехватывается, пока программа запущена).'
exit 0
