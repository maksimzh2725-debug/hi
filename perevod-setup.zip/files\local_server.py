import json
import re
import sys

from argostranslate import translate
from langdetect import DetectorFactory, detect_langs

DetectorFactory.seed = 0

LANGS = {lang.code: lang for lang in translate.get_installed_languages()}


def detect_source(text):
    try:
        best = None
        for cand in detect_langs(text):
            if cand.lang in LANGS and cand.prob >= 0.6:
                if best is None or cand.prob > best.prob:
                    best = cand
        if best:
            return best.lang
    except Exception:
        pass
    if re.search(r"[\u0400-\u04FF]", text):
        return "ru" if "ru" in LANGS else ("uk" if "uk" in LANGS else "en")
    if re.search(r"[\u4e00-\u9fff]", text):
        return "zh"
    if re.search(r"[\u3040-\u30ff]", text):
        return "ja"
    if re.search(r"[\u0600-\u06FF]", text):
        return "ar"
    if re.search(r"[\u0590-\u05FF]", text):
        return "he"
    if re.search(r"[\u0E00-\u0E7F]", text):
        return "th"
    if re.search(r"[\u0370-\u03FF]", text):
        return "el"
    if re.search(r"[\u0900-\u097F]", text):
        return "hi"
    return "en"


def pair(source, target):
    a = LANGS.get(source)
    b = LANGS.get(target)
    if not a or not b:
        return None
    try:
        return a.get_translation(b)
    except Exception:
        return None


def translate_text(text, target):
    source = detect_source(text)
    if source == target:
        return text
    if source not in LANGS:
        source = "en"
    result = None
    if source == "en" or target == "en":
        tr = pair(source, target)
        if tr:
            result = tr.translate(text)
    if result is None and "en" in LANGS:
        first = pair(source, "en")
        second = pair("en", target)
        if first and second:
            result = second.translate(first.translate(text))
    if result is None:
        tr = pair(source, target)
        if tr:
            result = tr.translate(text)
    return result


def main():
    try:
        warm = "ru" if "ru" in LANGS else next(iter(LANGS))
        translate_text("hello world", warm)
    except Exception:
        pass
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            text = (request.get("text") or "").strip()
            target = request.get("to") or "ru"
            if not text:
                print(json.dumps({"text": ""}), flush=True)
                continue
            result = translate_text(text, target)
            if result is None:
                print(json.dumps({"error": "no_model"}), flush=True)
            else:
                print(json.dumps({"text": result}, ensure_ascii=False), flush=True)
        except Exception as exc:
            print(json.dumps({"error": str(exc)}), flush=True)


if __name__ == "__main__":
    main()
