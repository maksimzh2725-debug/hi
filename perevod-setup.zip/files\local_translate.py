import argparse
import re
import sys

from argostranslate import translate
from langdetect import DetectorFactory, detect_langs

DetectorFactory.seed = 0


def detect_source(text, available):
    try:
        best = None
        for cand in detect_langs(text):
            if cand.lang in available and cand.prob >= 0.6:
                if best is None or cand.prob > best.prob:
                    best = cand
        if best:
            return best.lang
    except Exception:
        pass
    if re.search(r"[\u0400-\u04FF]", text):
        if "ru" in available:
            return "ru"
        if "uk" in available:
            return "uk"
        return "en"
    if re.search(r"[\u4e00-\u9fff]", text):
        return "zh"
    if re.search(r"[\u3040-\u30ff]", text):
        return "ja"
    if re.search(r"[\u0600-\u06FF]", text):
        return "ar"
    if re.search(r"[\u0590-\u05FF]", text):
        return "he"
    if re.search(r"[\u0E00-\u0E7F]", text):
        return "th"
    if re.search(r"[\u0370-\u03FF]", text):
        return "el"
    if re.search(r"[\u0900-\u097F]", text):
        return "hi"
    return "en"


def pick(langs, source, target):
    a = langs.get(source)
    b = langs.get(target)
    if not a or not b:
        return None
    try:
        return a.get_translation(b)
    except Exception:
        return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--to', required=True)
    parser.add_argument('--file')
    args = parser.parse_args()

    if args.file:
        with open(args.file, 'r', encoding='utf-8') as fh:
            text = fh.read().strip()
    else:
        text = sys.stdin.read().strip()
    if not text:
        print('')
        return 0

    target = args.to
    langs = {lang.code: lang for lang in translate.get_installed_languages()}
    source = detect_source(text, set(langs.keys()))

    if source == target:
        print(text)
        return 0

    if source not in langs:
        source = 'en'

    result = None
    if source == 'en' or target == 'en':
        tr = pick(langs, source, target)
        if tr:
            result = tr.translate(text)

    if result is None and 'en' in langs:
        first = pick(langs, source, 'en')
        second = pick(langs, 'en', target)
        if first and second:
            result = second.translate(first.translate(text))

    if result is None:
        tr = pick(langs, source, target)
        if tr:
            result = tr.translate(text)

    if result is None:
        print('(нет офлайн-модели для этого языка)', file=sys.stderr)
        return 2

    print(result)
    return 0


if __name__ == '__main__':
    sys.exit(main())
