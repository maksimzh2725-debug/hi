﻿param([switch]$SelfTest)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$script:root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:cfgFile = Join-Path $script:root 'settings.json'

$defaults = [ordered]@{
    Target             = 'Русский'
    Hotkey             = 'Ctrl+Alt+E'
    Bg1                = '#1F1F1F'
    Bg2                = '#030303'
    Accent             = '#FFFFFF'
    TextColor          = '#FFFFFF'
    FontSize           = 28
    Opacity            = 95
    ShowOriginal       = $true
    CopyResult         = $true
    CloseOnEsc         = $true
    TranslateSelection = $true
    Enabled            = $true
    ShowTrayTip        = $true
    Languages          = @('ru','en','uk','zh','ja','ur','ar','de','hi','tr','it','vi','el','th','he','sv')
    TrainingText       = 'Hello! How are you? I am learning to translate text with a hotkey.'
}

$cfg = [ordered]@{}
foreach ($k in $defaults.Keys) { $cfg[$k] = $defaults[$k] }
if (Test-Path -LiteralPath $script:cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($script:cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in $defaults.Keys) { if ($null -ne $saved.$k) { $cfg[$k] = $saved.$k } }
    } catch { }
}

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Настройка перевода" Width="880" Height="1000" MinWidth="700" MinHeight="480"
        WindowStartupLocation="CenterScreen" Background="#F5F7FA" FontFamily="Segoe UI">
    <Window.Resources>
        <Style TargetType="TextBox">
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="BorderBrush" Value="#C9D3E0"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="Width" Value="260"/>
            <Setter Property="HorizontalAlignment" Value="Left"/>
        </Style>
        <Style TargetType="ComboBox">
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="Padding" Value="6,4"/>
            <Setter Property="Margin" Value="0,4,0,0"/>
            <Setter Property="Width" Value="260"/>
            <Setter Property="HorizontalAlignment" Value="Left"/>
        </Style>
        <Style TargetType="CheckBox">
            <Setter Property="Margin" Value="0,12,0,0"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="Slider">
            <Setter Property="Margin" Value="0,6,0,0"/>
        </Style>
        <Style x:Key="Label" TargetType="TextBlock">
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Foreground" Value="#243447"/>
            <Setter Property="Margin" Value="0,12,0,4"/>
        </Style>
        <Style x:Key="Hint" TargetType="TextBlock">
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Foreground" Value="#6B7A8F"/>
            <Setter Property="Margin" Value="0,6,0,0"/>
            <Setter Property="TextWrapping" Value="Wrap"/>
        </Style>
        <Style x:Key="SectionTitle" TargetType="TextBlock">
            <Setter Property="FontSize" Value="17"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Foreground" Value="#1F2C3D"/>
            <Setter Property="VerticalAlignment" Value="Center"/>
        </Style>
    </Window.Resources>
    <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="28,20,28,24">
        <StackPanel>
            <TextBlock Text="Настройка перевода" FontSize="24" FontWeight="Light" Foreground="#1F2C3D"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Сверху — как будет выглядеть окно перевода. Настройки применяются кнопкой «Сохранить»."/>

            <Border Margin="0,16,0,0" BorderBrush="#D7DEE8" BorderThickness="1">
                <Grid x:Name="PrevRoot" Height="300" ClipToBounds="True">
                    <Rectangle x:Name="PrevBg"/>
                    <StackPanel VerticalAlignment="Center" Margin="26,0">
                        <StackPanel Orientation="Horizontal">
                            <Border x:Name="PrevPairBadge" CornerRadius="10" Padding="9,3">
                                <TextBlock x:Name="PrevPair" Text="AUTO → EN" FontSize="11"/>
                            </Border>
                            <Border x:Name="PrevKeyBadge" CornerRadius="10" Padding="9,3" Margin="8,0,0,0">
                                <TextBlock x:Name="PrevKey" Text="Ctrl+Alt+T" FontSize="11"/>
                            </Border>
                        </StackPanel>
                        <TextBlock x:Name="PrevSource" Text="Привет, как дела?" FontSize="13" Margin="0,18,0,0"/>
                        <TextBlock x:Name="PrevTarget" Text="Hello, how are you?" FontFamily="Segoe UI Light" FontSize="28"
                                   TextWrapping="Wrap" Margin="0,8,0,0"/>
                        <TextBlock x:Name="PrevHint" Text="Выделите текст и нажмите горячую клавишу" FontSize="12" Margin="0,18,0,0"/>
                    </StackPanel>
                </Grid>
            </Border>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Перевод"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Переводить на"/>
            <ComboBox x:Name="CmbTarget"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Исходный язык определяется автоматически: можно вставить или выделить любой текст — он переведётся на выбранный язык."/>



            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Языки перевода"/>
            </Grid>
            <TextBlock Style="{StaticResource Hint}" Text="Отметьте языки, которые будут в списке окна перевода."/>
            <WrapPanel x:Name="LangPanel" Margin="0,6,0,0"/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Вызов"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Горячая клавиша"/>
            <TextBox x:Name="TxtHotkey"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Начальная клавиша — Ctrl+Alt+E. Выделили текст, нажали клавишу — сверху появился перевод. Работает в любой программе, пока переводчик запущен."/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Тренировка"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Тренировочный текст"/>
            <TextBox x:Name="TxtTraining" Width="560" Height="96" AcceptsReturn="True" TextWrapping="Wrap"
                     VerticalScrollBarVisibility="Auto" VerticalContentAlignment="Top"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Этот текст открывается в окне перевода по кнопке ниже — чтобы проверить цвета, размер и выбор языка."/>
            <StackPanel Orientation="Horizontal" Margin="0,10,0,0">
                <Button x:Name="BtnTry" Content="Проверить перевод" Padding="14,7"/>
                <Button x:Name="BtnNet" Content="Проверить связь" Padding="14,7" Margin="8,0,0,0"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Цвета"/>
                <Button x:Name="BtnResetColors" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Фон 1"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalBg1" Width="430"/>
                <TextBox x:Name="TxtBg1" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Фон 2"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalBg2" Width="430"/>
                <TextBox x:Name="TxtBg2" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Акцент"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalAccent" Width="430"/>
                <TextBox x:Name="TxtAccent" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Текст"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalText" Width="430"/>
                <TextBox x:Name="TxtText" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Вид окна"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Размер текста перевода"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldFont" Minimum="16" Maximum="44" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblFont" Text="28 pt" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Прозрачность"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldOpacity" Minimum="50" Maximum="100" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblOpacity" Text="95 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Поведение"/>
            </Grid>
            <CheckBox x:Name="ChkEnabled" Content="Перехватывать Ctrl+Alt+E и показывать перевод"/>
            <CheckBox x:Name="ChkTip" Content="Показывать уведомление при запуске переводчика"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Если снять галочку и сохранить — комбинация снова работает в других программах, перевод не появляется."/>
            <CheckBox x:Name="ChkOriginal" Content="Показывать оригинал над переводом"/>
            <CheckBox x:Name="ChkCopy" Content="Копировать перевод в буфер обмена"/>
            <CheckBox x:Name="ChkEsc" Content="Закрывать окно по Esc"/>
            <CheckBox x:Name="ChkSelection" Content="Переводить сразу при выделении текста"/>

            <StackPanel Orientation="Horizontal" Margin="0,30,0,0">
                <Button x:Name="BtnSave" Content="Сохранить" Background="#2563EB" Foreground="White"
                        BorderBrush="#2563EB" Padding="20,8" FontSize="14" FontWeight="SemiBold" Margin="0,0,8,0"/>
                <Button x:Name="BtnClose" Content="Закрыть" Padding="16,8" FontSize="14"/>
                <TextBlock x:Name="Status" Text="" Margin="14,0,0,0" VerticalAlignment="Center" FontSize="12" Foreground="#3B7A57"/>
            </StackPanel>
        </StackPanel>
    </ScrollViewer>
</Window>
"@

$window = [Windows.Markup.XamlReader]::Parse($xaml)

if ($SelfTest) { Write-Output 'OK'; return }

function Get-Ui([string]$name) { return $window.FindName($name) }

$ui = @{
    PrevRoot = Get-Ui 'PrevRoot'
    PrevBg = Get-Ui 'PrevBg'
    PrevPairBadge = Get-Ui 'PrevPairBadge'
    PrevKeyBadge = Get-Ui 'PrevKeyBadge'
    PrevPair = Get-Ui 'PrevPair'
    PrevKey = Get-Ui 'PrevKey'
    PrevSource = Get-Ui 'PrevSource'
    PrevTarget = Get-Ui 'PrevTarget'
    PrevHint = Get-Ui 'PrevHint'
    CmbTarget = Get-Ui 'CmbTarget'
    TxtHotkey = Get-Ui 'TxtHotkey'
    TxtBg1 = Get-Ui 'TxtBg1'
    TxtBg2 = Get-Ui 'TxtBg2'
    TxtAccent = Get-Ui 'TxtAccent'
    TxtText = Get-Ui 'TxtText'
    PalBg1 = Get-Ui 'PalBg1'
    PalBg2 = Get-Ui 'PalBg2'
    PalAccent = Get-Ui 'PalAccent'
    PalText = Get-Ui 'PalText'
    BtnResetColors = Get-Ui 'BtnResetColors'
    SldFont = Get-Ui 'SldFont'
    LblFont = Get-Ui 'LblFont'
    SldOpacity = Get-Ui 'SldOpacity'
    LblOpacity = Get-Ui 'LblOpacity'
    ChkOriginal = Get-Ui 'ChkOriginal'
    ChkCopy = Get-Ui 'ChkCopy'
    ChkEsc = Get-Ui 'ChkEsc'
    ChkSelection = Get-Ui 'ChkSelection'
    ChkEnabled = Get-Ui 'ChkEnabled'
    ChkTip = Get-Ui 'ChkTip'
    TxtTraining = Get-Ui 'TxtTraining'
    LangPanel = Get-Ui 'LangPanel'
    BtnTry = Get-Ui 'BtnTry'
    BtnNet = Get-Ui 'BtnNet'
    BtnSave = Get-Ui 'BtnSave'
    BtnClose = Get-Ui 'BtnClose'
    Status = Get-Ui 'Status'
}

$script:ready = $false
$script:boxMap = @{ PalBg1 = 'TxtBg1'; PalBg2 = 'TxtBg2'; PalAccent = 'TxtAccent'; PalText = 'TxtText' }
$script:palette = @('#1F1F1F', '#030303', '#16233A', '#070B12', '#FFFFFF', '#5BC0EB', '#F5C26B', '#E06C75', '#7BD88F', '#B58CFF')
. (Join-Path $script:root 'languages.ps1')
$script:targetNames = @($script:languageList | ForEach-Object { $_.Name + ' (' + $_.Native + ')' })
$script:targetCodes = @($script:languageList | ForEach-Object { $_.Code })
$script:phrases = @{
    ru = 'Привет, как дела?'
    en = 'Hello, how are you?'
    de = 'Hallo, wie geht es dir?'
    fr = 'Salut, comment ça va ?'
    es = 'Hola, ¿cómo estás?'
    zh = '你好，你好吗？'
}

function Get-Color([string]$hex, [string]$fallback) {
    if ($hex -match '^#[0-9A-Fa-f]{6}$') { return $hex }
    return $fallback
}

function Add-Swatches([string]$panelName) {
    $panel = $ui[$panelName]
    foreach ($hex in $script:palette) {
        $dot = New-Object Windows.Controls.Border
        $dot.Width = 22
        $dot.Height = 22
        $dot.CornerRadius = [Windows.CornerRadius]::new(11)
        $dot.Margin = [Windows.Thickness]::new(0, 0, 6, 6)
        $dot.Background = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($hex))
        $dot.Cursor = [Windows.Input.Cursors]::Hand
        $dot.ToolTip = $hex
        $dot.Tag = $panelName + '|' + $hex
        $dot.Add_MouseLeftButtonDown({
            param($s, $e)
            $parts = ([string]$s.Tag).Split('|')
            $ui[$script:boxMap[$parts[0]]].Text = $parts[1]
        })
        $panel.Children.Add($dot) | Out-Null
    }
}

foreach ($panelName in @('PalBg1', 'PalBg2', 'PalAccent', 'PalText')) { Add-Swatches $panelName }

function Update-Preview {
    if (-not $script:ready) { return }
    $bg1 = Get-Color $ui.TxtBg1.Text '#1F1F1F'
    $bg2 = Get-Color $ui.TxtBg2.Text '#030303'
    $accent = Get-Color $ui.TxtAccent.Text '#FFFFFF'
    $text = Get-Color $ui.TxtText.Text '#FFFFFF'

    $bg = New-Object Windows.Media.LinearGradientBrush
    $bg.StartPoint = New-Object Windows.Point 0, 0
    $bg.EndPoint = New-Object Windows.Point 1, 1
    $bg.GradientStops.Add((New-Object Windows.Media.GradientStop ([Windows.Media.ColorConverter]::ConvertFromString($bg1), 0)))
    $bg.GradientStops.Add((New-Object Windows.Media.GradientStop ([Windows.Media.ColorConverter]::ConvertFromString($bg2), 1)))
    $ui.PrevBg.Fill = $bg

    $targetIndex = $ui.CmbTarget.SelectedIndex
    if ($targetIndex -lt 0) { $targetIndex = 1 }
    $targetCode = $script:targetCodes[$targetIndex]

    $ui.PrevSource.Text = $script:phrases['ru']
    $ui.PrevTarget.Text = $script:phrases[$targetCode]
    $ui.PrevTarget.FontSize = [double]$ui.SldFont.Value
    $ui.PrevPair.Text = 'AUTO → ' + $targetCode.ToUpper()

    $key = $ui.TxtHotkey.Text.Trim()
    if (-not $key) { $key = '—' }
    $ui.PrevKey.Text = $key

    $textBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($text))
    $accentBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
    $accentSoft = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
    $accentSoft.Opacity = 0.2

    $ui.PrevTarget.Foreground = $textBrush
    $ui.PrevSource.Foreground = $textBrush
    $ui.PrevSource.Opacity = 0.65
    $ui.PrevHint.Foreground = $textBrush
    $ui.PrevHint.Opacity = 0.55
    $ui.PrevPair.Foreground = $textBrush
    $ui.PrevKey.Foreground = $textBrush
    $ui.PrevPairBadge.Background = $accentSoft
    $ui.PrevKeyBadge.Background = $accentSoft
    $ui.PrevRoot.Opacity = [double]$ui.SldOpacity.Value / 100.0

    $ui.LblFont.Text = [string][int]$ui.SldFont.Value + ' pt'
    $ui.LblOpacity.Text = [string][int]$ui.SldOpacity.Value + ' %'
}

foreach ($name in $script:targetNames) { $ui.CmbTarget.Items.Add($name) | Out-Null }
$selectedCodes = @('ru','en')
if ($cfg.Languages) { $selectedCodes = @($cfg.Languages) }
foreach ($lang in $script:languageList) {
    $box = New-Object Windows.Controls.CheckBox
    $box.Content = $lang.Name + ' (' + $lang.Native + ')' 
    $box.Tag = $lang.Code
    $box.Margin = '0,0,16,6'
    $box.FontSize = 13
    $box.IsChecked = ($selectedCodes -contains $box.Tag)
    $ui.LangPanel.Children.Add($box) | Out-Null
}

$ui.TxtHotkey.Text = [string]$cfg.Hotkey
$ui.TxtBg1.Text = [string]$cfg.Bg1
$ui.TxtBg2.Text = [string]$cfg.Bg2
$ui.TxtAccent.Text = [string]$cfg.Accent
$ui.TxtText.Text = [string]$cfg.TextColor
$targetIndex = [Array]::IndexOf($script:targetCodes, (Get-LanguageCode $cfg.Target))
if ($targetIndex -lt 0) { $targetIndex = 1 }
$ui.CmbTarget.SelectedIndex = $targetIndex
$ui.SldFont.Value = [double]$cfg.FontSize
$ui.SldOpacity.Value = [double]$cfg.Opacity
$ui.ChkOriginal.IsChecked = [bool]$cfg.ShowOriginal
$ui.ChkCopy.IsChecked = [bool]$cfg.CopyResult
$ui.ChkEsc.IsChecked = [bool]$cfg.CloseOnEsc
$ui.ChkSelection.IsChecked = [bool]$cfg.TranslateSelection
$ui.ChkEnabled.IsChecked = [bool]$cfg.Enabled
$ui.ChkTip.IsChecked = [bool]$cfg.ShowTrayTip
$ui.TxtTraining.Text = [string]$cfg.TrainingText

$script:ready = $true
Update-Preview

$ui.CmbTarget.Add_SelectionChanged({ Update-Preview })
foreach ($control in @($ui.SldFont, $ui.SldOpacity)) { $control.Add_ValueChanged({ Update-Preview }) }
foreach ($box in @($ui.TxtHotkey, $ui.TxtBg1, $ui.TxtBg2, $ui.TxtAccent, $ui.TxtText)) { $box.Add_TextChanged({ Update-Preview }) }

$ui.BtnResetColors.Add_Click({
    $ui.TxtBg1.Text = '#1F1F1F'
    $ui.TxtBg2.Text = '#030303'
    $ui.TxtAccent.Text = '#FFFFFF'
    $ui.TxtText.Text = '#FFFFFF'
})

function Save-Settings {
    $data = [ordered]@{
        Target             = $script:targetCodes[[Math]::Max(0, $ui.CmbTarget.SelectedIndex)]
        Hotkey             = $ui.TxtHotkey.Text.Trim()
        Languages          = @($ui.LangPanel.Children | Where-Object { $_.IsChecked } | ForEach-Object { [string]$_.Tag })
        Bg1                = (Get-Color $ui.TxtBg1.Text '#1F1F1F')
        Bg2                = (Get-Color $ui.TxtBg2.Text '#030303')
        Accent             = (Get-Color $ui.TxtAccent.Text '#FFFFFF')
        TextColor          = (Get-Color $ui.TxtText.Text '#FFFFFF')
        FontSize           = [int]$ui.SldFont.Value
        Opacity            = [int]$ui.SldOpacity.Value
        ShowOriginal       = [bool]$ui.ChkOriginal.IsChecked
        CopyResult         = [bool]$ui.ChkCopy.IsChecked
        CloseOnEsc         = [bool]$ui.ChkEsc.IsChecked
        TranslateSelection = [bool]$ui.ChkSelection.IsChecked
        Enabled            = [bool]$ui.ChkEnabled.IsChecked
        ShowTrayTip        = [bool]$ui.ChkTip.IsChecked
        TrainingText       = $ui.TxtTraining.Text
    }
    [IO.File]::WriteAllText($script:cfgFile, ($data | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
    Restart-Translator
    $ui.Status.Text = 'Сохранено'
}

function Restart-Translator {
    try {
        Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
            Where-Object { $_.CommandLine -like '*Translate.ps1*' -and $_.CommandLine -notlike '*-Command*' -and $_.ProcessId -ne $PID } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Get-CimInstance Win32_Process -Filter "Name='wscript.exe'" |
            Where-Object { $_.CommandLine -like '*Translate.vbs*' } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
        Start-Sleep -Milliseconds 500
        Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $script:root 'Translate.vbs') + '"')
    } catch { }
}

$ui.BtnSave.Add_Click({ Save-Settings })

$ui.BtnNet.Add_Click({
    $ui.Status.Text = 'Проверяю связь…'
    try {
        Add-Type -AssemblyName System.Net.Http
        try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
        $client = New-Object Net.Http.HttpClient
        $client.Timeout = [TimeSpan]::FromSeconds(8)
        $client.DefaultRequestHeaders.Add('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36')
        $url = 'https://translate.googleapis.com/translate_a/single?client=dict-chrome-ex&sl=auto&tl=ru&dt=t&q=test'
        $response = $client.GetAsync($url).Result
        $ui.Status.Text = 'Связь есть, ответ ' + [int]$response.StatusCode
    } catch {
        $ui.Status.Text = 'Ошибка: ' + $_.Exception.Message
    }
})

$ui.BtnTry.Add_Click({
    Save-Settings
    $file = Join-Path $env:TEMP 'perevod-training.txt'
    [IO.File]::WriteAllText($file, $ui.TxtTraining.Text, (New-Object Text.UTF8Encoding($false)))
    $script = Join-Path $script:root 'Translate.ps1'
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-Sta', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $script + '"'), '-TextFile', ('"' + $file + '"')) | Out-Null
})

$ui.BtnClose.Add_Click({ $window.Close() })

$window.ShowDialog() | Out-Null
