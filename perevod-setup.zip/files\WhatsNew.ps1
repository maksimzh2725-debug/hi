﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgFile = Join-Path $root 'settings.json'

$cfg = [ordered]@{
    Hotkey     = 'Ctrl+Alt+E'
    Bg1        = '#1F1F1F'
    Bg2        = '#030303'
    Accent     = '#FFFFFF'
    TextColor  = '#FFFFFF'
    Languages  = @('ru','en','uk','zh','ja','kk','uz','ur','ar','de','hi','tr','it','vi','el','th','he','sv','be')
}

if (Test-Path -LiteralPath $cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in @($cfg.Keys)) { if ($null -ne $saved.$k) { $cfg[$k] = $saved.$k } }
    } catch { }
}

. (Join-Path $root 'languages.ps1')

$codes = @()
if ($cfg.Languages) { foreach ($c in @($cfg.Languages)) { $codes += Get-LanguageCode $c } }
$codes = @($codes | Select-Object -Unique)
if ($codes.Count -eq 0) { $codes = @('ru', 'en') }
$names = @($codes | ForEach-Object { Get-LanguageLabel $_ })

function Get-Hex([string]$value, [string]$fallback) {
    if ($value -match '^#[0-9A-Fa-f]{6}$') { return $value }
    return $fallback
}

$bg1 = Get-Hex ([string]$cfg.Bg1) '#1F1F1F'
$bg2 = Get-Hex ([string]$cfg.Bg2) '#030303'
$accent = Get-Hex ([string]$cfg.Accent) '#FFFFFF'
$text = Get-Hex ([string]$cfg.TextColor) '#FFFFFF'
$hotkey = [string]$cfg.Hotkey

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True"
        ShowInTaskbar="False" Width="660" SizeToContent="Height" WindowStartupLocation="CenterScreen"
        FontFamily="Segoe UI">
    <Grid>
        <Canvas ClipToBounds="True">
            <Image x:Name="Back" Stretch="Fill">
                <Image.Effect>
                    <BlurEffect Radius="30" KernelType="Gaussian" RenderingBias="Performance"/>
                </Image.Effect>
            </Image>
        </Canvas>
        <Border x:Name="Card" CornerRadius="18" BorderThickness="1" Padding="30,24">
            <StackPanel>
                <TextBlock x:Name="Title" Text="Переводчик 2.0 установлен" FontSize="26" FontWeight="Light"/>
                <TextBlock x:Name="SubTitle" Text="Комбинация клавиш: $hotkey" FontSize="15" Margin="0,10,0,0"/>
                <TextBlock x:Name="LangTitle" Text="Можно перевести на:" FontSize="13" Opacity="0.6" Margin="0,18,0,0"/>
                <TextBlock x:Name="LangList" TextWrapping="Wrap" FontSize="15" Margin="0,4,0,0"/>
                <StackPanel x:Name="Items" Margin="0,18,0,0"/>
                <StackPanel Orientation="Horizontal" Margin="0,24,0,0">
                    <Button x:Name="BtnOk" Content="Понятно" Padding="18,7" BorderThickness="0"/>
                    <Button x:Name="BtnSettings" Content="Открыть настройки" Padding="16,7" BorderThickness="0" Margin="10,0,0,0"/>
                </StackPanel>
            </StackPanel>
        </Border>
    </Grid>
</Window>
"@

$window = [Windows.Markup.XamlReader]::Parse($xaml)
$card = $window.FindName('Card')
$title = $window.FindName('Title')
$subTitle = $window.FindName('SubTitle')
$langTitle = $window.FindName('LangTitle')
$langList = $window.FindName('LangList')
$items = $window.FindName('Items')
$btnOk = $window.FindName('BtnOk')
$btnSettings = $window.FindName('BtnSettings')
$back = $window.FindName('Back')

$gradient = New-Object Windows.Media.LinearGradientBrush
$gradient.StartPoint = New-Object Windows.Point 0, 0
$gradient.EndPoint = New-Object Windows.Point 1, 1
$c1 = [Windows.Media.ColorConverter]::ConvertFromString($bg1)
$c2 = [Windows.Media.ColorConverter]::ConvertFromString($bg2)
$c1.A = 150
$c2.A = 180
$gradient.GradientStops.Add((New-Object Windows.Media.GradientStop ($c1, 0)))
$gradient.GradientStops.Add((New-Object Windows.Media.GradientStop ($c2, 1)))
$card.Background = $gradient
$card.BorderBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$card.BorderBrush.Opacity = 0.35

$textBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($text))
foreach ($element in @($title, $subTitle, $langTitle, $langList)) { $element.Foreground = $textBrush }
$langList.Text = ($names -join ', ')

$accentBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$ar = [Convert]::ToInt32($accent.Substring(1, 2), 16)
$ag = [Convert]::ToInt32($accent.Substring(3, 2), 16)
$ab = [Convert]::ToInt32($accent.Substring(5, 2), 16)
$dark = ((0.299 * $ar + 0.587 * $ag + 0.114 * $ab) -gt 150)
$btnOk.Background = $accentBrush
$btnSettings.Background = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#2A2E34'))
$btnSettings.Foreground = $textBrush
if ($dark) { $btnOk.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#111111')) }
else { $btnOk.Foreground = $textBrush }

$bullets = @(
    ('Перевод работает без интернета — модели стоят локально'),
    ('Выделите текст в любой программе и нажмите ' + $hotkey),
    '16 языков, выбор языка в окне и в настройках',
    'Окно с блюром, цвета и шрифт настраиваются'
)
foreach ($line in $bullets) {
    $row = New-Object Windows.Controls.TextBlock
    $row.Text = '•  ' + $line
    $row.FontSize = 15
    $row.Margin = '0,0,0,8'
    $row.TextWrapping = 'Wrap'
    $row.Foreground = $textBrush
    $row.Opacity = 0.9
    $items.Children.Add($row) | Out-Null
}

$window.Opacity = 0
$window.Show()
$window.UpdateLayout()

try {
    $w = [int]$window.ActualWidth
    $h = [int]$window.ActualHeight
    $bmp = New-Object Drawing.Bitmap $w, $h
    $g = [Drawing.Graphics]::FromImage($bmp)
    $g.CopyFromScreen([int]$window.Left, [int]$window.Top, 0, 0, $bmp.Size)
    $g.Dispose()
    $half = New-Object Drawing.Bitmap ([int]($w / 2)), ([int]($h / 2))
    $g2 = [Drawing.Graphics]::FromImage($half)
    $g2.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
    $g2.DrawImage($bmp, 0, 0, $half.Width, $half.Height)
    $g2.Dispose()
    $bmp.Dispose()
    $ms = New-Object IO.MemoryStream
    $half.Save($ms, [Drawing.Imaging.ImageFormat]::Png)
    $half.Dispose()
    $ms.Position = 0
    $image = New-Object Windows.Media.Imaging.BitmapImage
    $image.BeginInit()
    $image.StreamSource = $ms
    $image.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $image.EndInit()
    $image.Freeze()
    $back.Source = $image
    $back.Width = $w + 80
    $back.Height = $h + 80
    [Windows.Controls.Canvas]::SetLeft($back, -40)
    [Windows.Controls.Canvas]::SetTop($back, -40)
} catch { }

$window.Opacity = 1
$btnOk.Add_Click({ $window.Close() })
$btnSettings.Add_Click({
    try {
        Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $root 'launch.vbs') + '"')
    } catch { }
    $window.Close()
})
$window.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Escape') { $window.Close() } })

$window.Add_Closed({ [Environment]::Exit(0) })
[Windows.Threading.Dispatcher]::Run()
