﻿param(
    [string]$TargetPath = (Join-Path $env:LOCALAPPDATA 'Приветствие'),
    [string]$UpdateUrl = 'https://maksimzh2725-debug.github.io/hi/',
    [switch]$Quiet
)

function Get-WifiSsid {
    try {
        $output = & netsh wlan show interfaces 2>$null
        foreach ($line in ($output -split "`r?`n")) {
            if ($line -match '^\s*SSID\s*:\s*(.+)$') { return $Matches[1].Trim() }
        }
    } catch { }
    return ''
}

$ErrorActionPreference = 'Stop'

# Если рядом лежит update-url.txt, берём адрес сайта оттуда
$urlFile = Join-Path $PSScriptRoot 'update-url.txt'
if (-not $UpdateUrl -and (Test-Path -LiteralPath $urlFile)) {
    $UpdateUrl = (Get-Content -LiteralPath $urlFile -Raw).Trim()
}

$source = Join-Path $PSScriptRoot 'files'
if (-not (Test-Path -LiteralPath $source)) {
    Write-Host "Не найдена папка files рядом с установщиком." -ForegroundColor Red
    exit 1
}

$target = $TargetPath
New-Item -ItemType Directory -Path $target -Force | Out-Null

Get-ChildItem -LiteralPath $source -File | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $target -Force
}
Get-ChildItem -LiteralPath $target -File | Unblock-File -ErrorAction SilentlyContinue

$cfgPath = Join-Path $target 'settings.json'
if (-not (Test-Path -LiteralPath $cfgPath)) {
    # Чистое состояние: базовые цвета и тексты, без погоды и без своего события
    $defaults = [ordered]@{
        Name        = 'друг'
        Message     = 'Добро пожаловать'
        SubMessage  = 'Хорошего дня'
        Bg1         = '#16233A'
        Bg2         = '#070B12'
        Accent      = '#FFFFFF'
        TextColor   = '#FFFFFF'
        FontSize    = 64
        Seconds     = 8
        WaitSeconds = 10
        TimeOfDay   = $true
        ShowClock   = $true
        ShowDate    = $true
        ShowDayInfo = $true
        ShowWeather = $false
        ShowEvent   = $true
        ShowInfo    = $true
        ShowNews    = $true
        EventName   = ''
        EventDate   = ''
        City        = ''
        NetworkName = (Get-WifiSsid)
        BlurRadius  = 30
        TintOpacity = 35
        UpdateUrl   = $UpdateUrl
    }
    [IO.File]::WriteAllText($cfgPath, ($defaults | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
} else {
    # Обновление поверх старой версии: добавляем адрес сайта, не трогая настройки
    try {
        $existing = [IO.File]::ReadAllText($cfgPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
        if (-not $existing.UpdateUrl -and $UpdateUrl) {
            $existing | Add-Member -NotePropertyName UpdateUrl -NotePropertyValue $UpdateUrl -Force
            [IO.File]::WriteAllText($cfgPath, ($existing | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
        }
    } catch { }
}

if (-not $Quiet) {
    $shell = New-Object -ComObject WScript.Shell
    $wscript = Join-Path $env:WINDIR 'System32\wscript.exe'
    $vbs = Join-Path $target 'launch.vbs'
    $desktop = [Environment]::GetFolderPath('Desktop')

    foreach ($pair in @(@('Приветствие (настройка)', 'settings'), @('Приветствие (показать)', 'welcome'))) {
        $lnk = $shell.CreateShortcut((Join-Path $desktop ($pair[0] + '.lnk')))
        $lnk.TargetPath = $wscript
        $lnk.Arguments = '"' + $vbs + '" ' + $pair[1]
        $lnk.WorkingDirectory = $target
        $lnk.Description = 'Приветствие при включении ПК'
        $lnk.Save()
    }

    $answer = Read-Host 'Включить автозапуск при включении ПК? (Д/н)'
    if ($answer -notmatch '^[nнNН]') {
        $taskName = 'Приветствие'
        $taskCreated = $false
        try {
            $existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
            if ($existing) { $taskCreated = $true }
            else {
                # Задача при входе стартует раньше папки «Автозагрузка» (нужны права администратора)
                $action = New-ScheduledTaskAction -Execute $wscript -Argument ('"' + $vbs + '" welcome')
                $trigger = New-ScheduledTaskTrigger -AtLogOn
                Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Description 'Приветствие при входе в систему' -Force -ErrorAction Stop | Out-Null
                $taskCreated = $true
            }
        } catch { $taskCreated = $false }

        $startupLink = Join-Path ([Environment]::GetFolderPath('Startup')) 'Приветствие.lnk'
        if ($taskCreated) {
            if (Test-Path -LiteralPath $startupLink) { Remove-Item -LiteralPath $startupLink -Force -ErrorAction SilentlyContinue }
        } else {
            $lnk = $shell.CreateShortcut($startupLink)
            $lnk.TargetPath = $wscript
            $lnk.Arguments = '"' + $vbs + '" welcome'
            $lnk.WorkingDirectory = $target
            $lnk.Description = 'Приветствие при включении ПК'
            $lnk.Save()
        }
    }

    $test = Read-Host 'Запустить предпросмотр сейчас? (Д/н)'
    if ($test -notmatch '^[nнNН]') {
        $welcome = Join-Path $target 'Welcome.ps1'
        $arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Seconds 6' -f $welcome
        Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WindowStyle Hidden
    }

    Write-Host ''
    Write-Host "Готово. Файлы установлены в: $target" -ForegroundColor Green
    Write-Host 'На рабочем столе: «Приветствие (настройка)» и «Приветствие (показать)».'
    Write-Host 'Настройки: имя, цвета, погода, событие, новость и автозапуск.'
}

exit 0
