﻿param([switch]$SelfTest)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$script:root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:cfgFile = Join-Path $script:root 'settings.json'
$script:welcomePath = Join-Path $script:root 'Welcome.ps1'
$script:picsDir = Join-Path $script:root 'pics'
$script:startupLink = Join-Path ([Environment]::GetFolderPath('Startup')) 'Приветствие.lnk'

$defaults = [ordered]@{
    Name        = 'друг'
    Message     = 'Добро пожаловать'
    SubMessage  = 'Хорошего дня'
    Bg1         = '#16233A'
    Bg2         = '#070B12'
    Accent      = '#FFFFFF'
    TextColor   = '#FFFFFF'
    FontSize    = 64
    Seconds     = 8
    WaitSeconds = 10
    TimeOfDay   = $true
    ShowClock   = $true
    ShowDate    = $true
    ShowDayInfo = $true
    ShowWeather = $true
    ShowEvent   = $true
    ShowInfo    = $true
    ShowNews    = $true
    NetworkName = ''
    EventName   = ''
    EventDate   = ''
    City        = ''
    BlurRadius  = 30
    TintOpacity = 35
    UpdateUrl   = ''
    WeatherEffect  = $true
    PreviewWeather = $true
    SoundFile      = 'startup.wav'
    SoundVolume    = 100
    MusicFile      = 'music.mp3'
    MusicVolume    = 60
    PicFile        = ''
    PicOpacity     = 100
    PicZoom        = 100
    PicFit         = $true
}

$cfg = [ordered]@{}
foreach ($k in $defaults.Keys) { $cfg[$k] = $defaults[$k] }
if (Test-Path -LiteralPath $script:cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($script:cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in $defaults.Keys) { if ($null -ne $saved.$k) { $cfg[$k] = $saved.$k } }
    } catch { }
}

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Настройка приветствия" Width="880" Height="980" MinWidth="700" MinHeight="480"
        WindowStartupLocation="CenterScreen" Background="#F5F7FA" FontFamily="Segoe UI">
    <Window.Resources>
        <Style TargetType="TextBox">
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="BorderBrush" Value="#C9D3E0"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="CheckBox">
            <Setter Property="Margin" Value="0,12,0,0"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="Slider">
            <Setter Property="Margin" Value="0,6,0,0"/>
        </Style>
        <Style x:Key="Label" TargetType="TextBlock">
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Foreground" Value="#243447"/>
            <Setter Property="Margin" Value="0,12,0,4"/>
        </Style>
        <Style x:Key="Hint" TargetType="TextBlock">
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Foreground" Value="#6B7A8F"/>
            <Setter Property="Margin" Value="0,6,0,0"/>
            <Setter Property="TextWrapping" Value="Wrap"/>
        </Style>
        <Style x:Key="SectionTitle" TargetType="TextBlock">
            <Setter Property="FontSize" Value="17"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Foreground" Value="#1F2C3D"/>
            <Setter Property="VerticalAlignment" Value="Center"/>
        </Style>
    </Window.Resources>
    <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="28,20,28,24">
        <StackPanel>
            <TextBlock Text="Настройка приветствия" FontSize="24" FontWeight="Light" Foreground="#1F2C3D"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Сверху — как будет выглядеть приветствие. Изменения применяются кнопкой «Сохранить», «Предпросмотр» сохраняет и показывает полную версию."/>

            <Border Margin="0,16,0,0" BorderBrush="#D7DEE8" BorderThickness="1">
                <Grid x:Name="PrevRoot" Height="300" ClipToBounds="True">
                    <Ellipse x:Name="PrevGlow" Width="300" Height="300" Fill="#5BC0EB" Opacity="0.3"
                             HorizontalAlignment="Left" VerticalAlignment="Top" Margin="-60,-80,0,0">
                        <Ellipse.Effect>
                            <BlurEffect Radius="60"/>
                        </Ellipse.Effect>
                    </Ellipse>
                    <Ellipse Width="260" Height="260" Fill="White" Opacity="0.15"
                             HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,-40,-60">
                        <Ellipse.Effect>
                            <BlurEffect Radius="60"/>
                        </Ellipse.Effect>
                    </Ellipse>
                    <Rectangle x:Name="PrevTint"/>
                    <Image x:Name="PrevPic" Stretch="UniformToFill" RenderTransformOrigin="0.5,0.5" Opacity="0">
                        <Image.RenderTransform>
                            <ScaleTransform x:Name="PrevPicScale" ScaleX="1" ScaleY="1"/>
                        </Image.RenderTransform>
                    </Image>
                    <Canvas x:Name="PrevWeatherFx" ClipToBounds="True"/>
                    <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center" Margin="20,0">
                        <TextBlock x:Name="PrevClock" Text="" HorizontalAlignment="Center" FontFamily="Segoe UI Light"
                                   FontSize="18" Foreground="White" Opacity="0.9"/>
                        <TextBlock x:Name="PrevDate" Text="" HorizontalAlignment="Center" FontSize="11"
                                   Foreground="White" Opacity="0.6"/>
                        <TextBlock x:Name="PrevDay" Text="" HorizontalAlignment="Center" FontSize="10"
                                   Foreground="White" Opacity="0.5"/>
                        <TextBlock x:Name="PrevWeather" Text="" HorizontalAlignment="Center" FontSize="11"
                                   Foreground="White" Opacity="0.75" Margin="0,3,0,0"/>
                        <TextBlock x:Name="PrevEvent" Text="" HorizontalAlignment="Center" FontSize="10"
                                   Foreground="White" Opacity="0.6"/>
                        <TextBlock x:Name="PrevTitle" Text="" HorizontalAlignment="Center" TextAlignment="Center"
                                   TextWrapping="Wrap" FontFamily="Segoe UI Light" FontSize="26" Foreground="White" Margin="0,6,0,0"/>
                        <Rectangle x:Name="PrevLine" Height="2" Width="70" HorizontalAlignment="Center" Fill="White" Margin="0,10,0,10" Opacity="0.8"/>
                        <TextBlock x:Name="PrevSub" Text="" HorizontalAlignment="Center" FontSize="14"
                                   Foreground="White" Opacity="0.8"/>
                    </StackPanel>
                </Grid>
            </Border>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Приветствие"/>
                <Button x:Name="BtnResetText" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Имя"/>
            <TextBox x:Name="TxtName"/>
            <TextBlock Style="{StaticResource Label}" Text="Свой текст приветствия"/>
            <TextBox x:Name="TxtMessage"/>
            <CheckBox x:Name="ChkTime" Content="Здороваться по времени суток и подставлять имя"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="С галочкой вместо своего текста будет «Доброе утро, Имя» / «Добрый вечер, Имя» и т. п. Свой текст тогда не используется."/>
            <TextBlock Style="{StaticResource Label}" Text="Подпись под приветствием"/>
            <TextBox x:Name="TxtSub"/>
            <TextBlock Style="{StaticResource Label}" Text="Размер текста"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldSize" Minimum="24" Maximum="140" Width="400" Value="64"
                        TickFrequency="2" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblSize" Text="64 pt" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <CheckBox x:Name="ChkClock" Content="Показывать часы (дата показывается всегда)"/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Что показывать"/>
                <Button x:Name="BtnResetScreen" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Hint}" Text="Снимите галочку, чтобы убрать строку с экрана. Часы настраиваются выше."/>
            <WrapPanel Margin="0,4,0,0">
                <CheckBox x:Name="ChkShowDate" Content="Дата с годом" Margin="0,8,24,0"/>
                <CheckBox x:Name="ChkShowDayInfo" Content="Неделя и день года" Margin="0,8,24,0"/>
                <CheckBox x:Name="ChkShowWeather" Content="Погода" Margin="0,8,24,0"/>
                <CheckBox x:Name="ChkShowEvent" Content="Дни до события" Margin="0,8,24,0"/>
                <CheckBox x:Name="ChkShowInfo" Content="Язык и звук" Margin="0,8,24,0"/>
                <CheckBox x:Name="ChkShowNews" Content="Новость" Margin="0,8,0,0"/>
            </WrapPanel>

            <TextBlock Style="{StaticResource Label}" Text="Событие — название и дата"/>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtEventName" Width="260"/>
                <TextBox x:Name="TxtEventDate" Width="140" Margin="8,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Например: «Новый год» и 01.01.2027. Если пусто — строка не показывается."/>

            <TextBlock Style="{StaticResource Label}" Text="Город для погоды"/>
            <TextBox x:Name="TxtCity" Width="260"/>
            <TextBlock Style="{StaticResource Hint}" Text="Например, Москва. Без города погода не показывается."/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Фон"/>
                <Button x:Name="BtnResetBg" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Готовая тема — нажмите, чтобы применить"/>
            <WrapPanel x:Name="PresetPanel" Margin="0,2,0,0"/>
            <TextBlock Style="{StaticResource Label}" Text="Свои цвета"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Нажмите цветной кружок, чтобы выбрать оттенок, и потяните ползунок «Яркость», чтобы сделать его светлее или темнее."/>

            <TextBlock Style="{StaticResource Label}" Text="Фон 1 — верхний угол"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PaletteBg1" VerticalAlignment="Center"/>
                <TextBlock Text="Яркость" Margin="14,0,8,0" VerticalAlignment="Center" FontSize="12" Foreground="#6B7A8F"/>
                <Slider x:Name="SldBrightBg1" Minimum="20" Maximum="180" Width="120" Value="100"
                        TickFrequency="5" IsSnapToTickEnabled="True" VerticalAlignment="Center" Margin="0"/>
                <TextBlock x:Name="LblBrightBg1" Text="100%" Width="44" Margin="8,0,0,0" VerticalAlignment="Center" FontSize="12"/>
                <Border x:Name="SwatchBg1" Width="22" Height="22" Margin="6,0,0,0" CornerRadius="4" BorderBrush="#C9D3E0" BorderThickness="1"/>
                <TextBox x:Name="TxtBg1" Width="82" Margin="8,0,0,0" IsReadOnly="True" FontSize="12" Padding="4,2" VerticalContentAlignment="Center"/>
            </StackPanel>

            <TextBlock Style="{StaticResource Label}" Text="Фон 2 — нижний угол"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PaletteBg2" VerticalAlignment="Center"/>
                <TextBlock Text="Яркость" Margin="14,0,8,0" VerticalAlignment="Center" FontSize="12" Foreground="#6B7A8F"/>
                <Slider x:Name="SldBrightBg2" Minimum="20" Maximum="180" Width="120" Value="100"
                        TickFrequency="5" IsSnapToTickEnabled="True" VerticalAlignment="Center" Margin="0"/>
                <TextBlock x:Name="LblBrightBg2" Text="100%" Width="44" Margin="8,0,0,0" VerticalAlignment="Center" FontSize="12"/>
                <Border x:Name="SwatchBg2" Width="22" Height="22" Margin="6,0,0,0" CornerRadius="4" BorderBrush="#C9D3E0" BorderThickness="1"/>
                <TextBox x:Name="TxtBg2" Width="82" Margin="8,0,0,0" IsReadOnly="True" FontSize="12" Padding="4,2" VerticalContentAlignment="Center"/>
            </StackPanel>

            <TextBlock Style="{StaticResource Label}" Text="Акцент — часы и линия"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PaletteAcc" VerticalAlignment="Center"/>
                <TextBlock Text="Яркость" Margin="14,0,8,0" VerticalAlignment="Center" FontSize="12" Foreground="#6B7A8F"/>
                <Slider x:Name="SldBrightAcc" Minimum="20" Maximum="180" Width="120" Value="100"
                        TickFrequency="5" IsSnapToTickEnabled="True" VerticalAlignment="Center" Margin="0"/>
                <TextBlock x:Name="LblBrightAcc" Text="100%" Width="44" Margin="8,0,0,0" VerticalAlignment="Center" FontSize="12"/>
                <Border x:Name="SwatchAcc" Width="22" Height="22" Margin="6,0,0,0" CornerRadius="4" BorderBrush="#C9D3E0" BorderThickness="1"/>
                <TextBox x:Name="TxtAccent" Width="82" Margin="8,0,0,0" IsReadOnly="True" FontSize="12" Padding="4,2" VerticalContentAlignment="Center"/>
            </StackPanel>

            <TextBlock Style="{StaticResource Label}" Text="Цвет текста"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PaletteTxt" VerticalAlignment="Center"/>
                <TextBlock Text="Яркость" Margin="14,0,8,0" VerticalAlignment="Center" FontSize="12" Foreground="#6B7A8F"/>
                <Slider x:Name="SldBrightTxt" Minimum="20" Maximum="180" Width="120" Value="100"
                        TickFrequency="5" IsSnapToTickEnabled="True" VerticalAlignment="Center" Margin="0"/>
                <TextBlock x:Name="LblBrightTxt" Text="100%" Width="44" Margin="8,0,0,0" VerticalAlignment="Center" FontSize="12"/>
                <Border x:Name="SwatchTxt" Width="22" Height="22" Margin="6,0,0,0" CornerRadius="4" BorderBrush="#C9D3E0" BorderThickness="1"/>
                <TextBox x:Name="TxtText" Width="82" Margin="8,0,0,0" IsReadOnly="True" FontSize="12" Padding="4,2" VerticalContentAlignment="Center"/>
            </StackPanel>

            <TextBlock Style="{StaticResource Label}" Text="Размытие обоев"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldBlur" Minimum="0" Maximum="80" Width="400" Value="30"
                        TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblBlur" Text="30" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Плотность фона"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldTint" Minimum="15" Maximum="100" Width="400" Value="35"
                        TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblTint" Text="35 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Меньше плотность — сильнее видно размытые обои. Больше плотность — текст читается лучше на светлом фоне."/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Картинка на фоне"/>
                <Button x:Name="BtnResetPic" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtPic" Width="300" IsReadOnly="True"/>
                <Button x:Name="BtnPickPic" Content="Выбрать…" Padding="12,4" Margin="8,0,0,0"/>
                <Button x:Name="BtnClearPic" Content="Убрать" Padding="12,4" Margin="6,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Файл копируется в папку pics рядом с программой. Картинка ложится поверх размытых обоев."/>
            <TextBlock Style="{StaticResource Label}" Text="Прозрачность картинки"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldPicOpacity" Minimum="10" Maximum="100" Value="100" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblPicOpacity" Text="100 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Размер картинки"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldPicZoom" Minimum="100" Maximum="300" Width="400" TickFrequency="5" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblPicZoom" Text="100 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            <CheckBox x:Name="ChkPicFit" Content="Подгонять картинку под размер окна" IsChecked="True"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Время"/>
                <Button x:Name="BtnResetTime" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Длительность загрузки, с — чёрный экран перед приветствием"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldWait" Minimum="0" Maximum="60" Width="400" Value="10"
                        TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblWait" Text="10 с" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Сколько секунд показывать готовое приветствие"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldSeconds" Minimum="2" Maximum="60" Width="400" Value="8"
                        TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblSeconds" Text="8 с" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Загрузка всегда длится ровно указанное время. Подключение к интернету может занять больше времени: если сеть не успеет, приветствие всё равно появится — без новостей и погоды. Показ — время, которое приветствие висит после полного появления; закрыть можно кликом или Esc."/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Погода на фоне"/>
            </Grid>
            <CheckBox x:Name="ChkWeatherEffect" Content="Показывать дождь и снег на фоне приветствия"/>
            <CheckBox x:Name="ChkPreviewWeather" Content="Показывать эффект в превью сверху"/>
            <TextBlock Style="{StaticResource Label}" Text="Тест эффекта — только для предпросмотра"/>
            <ComboBox x:Name="CmbTestWeather" Width="260" HorizontalAlignment="Left">
                <ComboBoxItem Content="Дождь"/>
                <ComboBoxItem Content="Снег"/>
                <ComboBoxItem Content="Дождь со снегом"/>
                <ComboBoxItem Content="Без эффекта"/>
            </ComboBox>
            <TextBlock Style="{StaticResource Hint}"
                       Text="В обычном запуске эффект берётся из текущей погоды: дождь, снег или дождь со снегом. В тесте можно выбрать вручную."/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Звук"/>
                <Button x:Name="BtnResetSound" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Звук приветствия"/>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtSound" Width="320"/>
                <Button x:Name="BtnPickSound" Content="Выбрать…" Padding="12,4" Margin="8,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Играет в момент появления приветствия. Имя файла можно менять — файл берётся из папки приветствия."/>
            <TextBlock Style="{StaticResource Label}" Text="Громкость звука приветствия"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldSound" Minimum="0" Maximum="100" Width="300" HorizontalAlignment="Left" VerticalAlignment="Center"/>
                <TextBlock x:Name="LblSoundVol" Width="60" Margin="10,6,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Фоновая музыка"/>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtMusic" Width="320"/>
                <Button x:Name="BtnPickMusic" Content="Выбрать…" Padding="12,4" Margin="8,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Начинает играть вместе с приветствием и плавно набирает громкость. Имя файла можно менять — файл берётся из папки приветствия."/>
            <TextBlock Style="{StaticResource Label}" Text="Громкость фоновой музыки"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldMusic" Minimum="0" Maximum="70" Width="300" HorizontalAlignment="Left" VerticalAlignment="Center"/>
                <TextBlock x:Name="LblMusicVol" Width="60" Margin="10,6,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Музыка звучит тише звука приветствия — это ограничение соблюдается всегда."/>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Запуск"/>
                <Button x:Name="BtnResetLaunch" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <CheckBox x:Name="ChkAuto" Content="Запускать приветствие при включении ПК"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Добавляет ярлык в автозапуск Windows. Если снять галочку и сохранить — ярлык удалится."/>

            <TextBlock Style="{StaticResource Label}" Text="Wi-Fi сеть для подключения при старте"/>
            <TextBox x:Name="TxtNetwork" Width="260"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="Обычно подставляется текущая сеть этого ПК — можно изменить. Подключение к сети может занять больше времени, чем длится загрузка — приветствие всё равно появится. Пусто — без подключения."/>

            <TextBlock Style="{StaticResource Label}" Text="Сайт обновлений — ссылка на папку или на updates.json"/>
            <TextBox x:Name="TxtUpdate" Width="420"/>
            <TextBlock Style="{StaticResource Hint}"
                       Text="При запуске приложение сверит версию с сайтом и предложит обновить файлы на месте. Скачивать архив можно сколько угодно раз. Пусто — проверка выключена."/>

            <StackPanel Orientation="Horizontal" Margin="0,30,0,0">
                <Button x:Name="BtnSave" Content="Сохранить" Background="#2563EB" Foreground="White"
                        BorderBrush="#2563EB" Padding="20,8" FontSize="14" FontWeight="SemiBold" Margin="0,0,8,0"/>
                <Button x:Name="BtnTest" Content="Предпросмотр" Padding="16,8" FontSize="14" Margin="0,0,8,0"/>
                <Button x:Name="BtnClose" Content="Закрыть" Padding="16,8" FontSize="14"/>
            </StackPanel>
            <TextBlock x:Name="LblStatus" Text="" Margin="0,14,0,0" Foreground="#3A7D44" FontSize="13"/>
        </StackPanel>
    </ScrollViewer>
</Window>
"@

$window = [Windows.Markup.XamlReader]::Parse($xaml)

$names = @(
    'PrevRoot', 'PrevGlow', 'PrevTint', 'PrevPic', 'PrevPicScale', 'PrevClock', 'PrevDate', 'PrevDay', 'PrevWeather', 'PrevEvent', 'PrevTitle', 'PrevLine', 'PrevSub',
    'TxtName', 'TxtMessage', 'TxtSub', 'TxtBg1', 'TxtBg2', 'TxtAccent', 'TxtText',
    'SwatchBg1', 'SwatchBg2', 'SwatchAcc', 'SwatchTxt',
    'PaletteBg1', 'PaletteBg2', 'PaletteAcc', 'PaletteTxt',
    'SldBrightBg1', 'SldBrightBg2', 'SldBrightAcc', 'SldBrightTxt',
    'LblBrightBg1', 'LblBrightBg2', 'LblBrightAcc', 'LblBrightTxt',
    'SldSize', 'SldSeconds', 'SldWait', 'SldBlur', 'SldTint',
    'SldPicOpacity', 'SldPicZoom', 'LblPicOpacity', 'LblPicZoom', 'TxtPic', 'BtnPickPic', 'BtnClearPic', 'BtnResetPic', 'ChkPicFit',
    'LblSize', 'LblSeconds', 'LblWait', 'LblBlur', 'LblTint',
    'ChkTime', 'ChkClock', 'ChkAuto', 'TxtNetwork', 'TxtUpdate', 'PresetPanel', 'ChkShowDate', 'ChkShowDayInfo', 'ChkShowWeather', 'ChkShowEvent', 'ChkShowInfo', 'ChkShowNews', 'TxtEventName', 'TxtEventDate', 'TxtCity', 'BtnResetScreen',
    'PrevWeatherFx', 'ChkWeatherEffect', 'ChkPreviewWeather', 'CmbTestWeather',
    'TxtSound', 'BtnPickSound', 'SldSound', 'LblSoundVol', 'TxtMusic', 'BtnPickMusic', 'SldMusic', 'LblMusicVol', 'BtnResetSound',
    'BtnSave', 'BtnTest', 'BtnClose', 'BtnResetText', 'BtnResetBg', 'BtnResetTime', 'BtnResetLaunch', 'BtnResetScreen', 'LblStatus'
)
$script:ui = @{}
foreach ($n in $names) { $script:ui[$n] = $window.FindName($n) }

if ($SelfTest) {
    $missing = @($names | Where-Object { $null -eq $script:ui[$_] })
    if ($missing.Count -gt 0) { throw "Не найдены элементы: $($missing -join ', ')" }
    Write-Output 'OK'
    return
}

$script:roles = [ordered]@{
    Bg1    = @{ Hex = 'TxtBg1'; Swatch = 'SwatchBg1'; Slider = 'SldBrightBg1'; Label = 'LblBrightBg1'; Panel = 'PaletteBg1' }
    Bg2    = @{ Hex = 'TxtBg2'; Swatch = 'SwatchBg2'; Slider = 'SldBrightBg2'; Label = 'LblBrightBg2'; Panel = 'PaletteBg2' }
    Accent = @{ Hex = 'TxtAccent'; Swatch = 'SwatchAcc'; Slider = 'SldBrightAcc'; Label = 'LblBrightAcc'; Panel = 'PaletteAcc' }
    Text   = @{ Hex = 'TxtText'; Swatch = 'SwatchTxt'; Slider = 'SldBrightTxt'; Label = 'LblBrightTxt'; Panel = 'PaletteTxt' }
}

$script:palette = @('#FFFFFF', '#111111', '#808080', '#E53935', '#FB8C00', '#FDD835', '#43A047', '#1E88E5', '#8E24AA')
$converter = New-Object Windows.Media.BrushConverter
$script:borderBrush = $converter.ConvertFromString('#C9D3E0')
$script:selectedBrush = $converter.ConvertFromString('#2563EB')

function Get-WifiSsid {
    try {
        $output = & netsh wlan show interfaces 2>$null
        foreach ($line in ($output -split "`r?`n")) {
            if ($line -match '^\s*SSID\s*:\s*(.+)$') { return $Matches[1].Trim() }
        }
    } catch { }
    return ''
}
function Test-Hex([string]$value, [string]$fallback) {
    if ($value -match '^#[0-9A-Fa-f]{6}$') { return $value.ToUpper() }
    return $fallback
}

function Get-BrightColor([string]$hex, [int]$percent) {
    $r = [Convert]::ToInt32($hex.Substring(1, 2), 16)
    $g = [Convert]::ToInt32($hex.Substring(3, 2), 16)
    $b = [Convert]::ToInt32($hex.Substring(5, 2), 16)
    $k = $percent / 100.0
    $r = [int][math]::Max(0, [math]::Min(255, [math]::Round($r * $k)))
    $g = [int][math]::Max(0, [math]::Min(255, [math]::Round($g * $k)))
    $b = [int][math]::Max(0, [math]::Min(255, [math]::Round($b * $k)))
    return ('#{0:X2}{1:X2}{2:X2}' -f $r, $g, $b)
}

function Get-Color([string]$hex) {
    return [Windows.Media.ColorConverter]::ConvertFromString($hex)
}

$script:colorBase = [ordered]@{
    Bg1    = (Test-Hex $cfg.Bg1 '#16233A')
    Bg2    = (Test-Hex $cfg.Bg2 '#070B12')
    Accent = (Test-Hex $cfg.Accent '#FFFFFF')
    Text   = (Test-Hex $cfg.TextColor '#FFFFFF')
}
$script:colorBright = @{ Bg1 = 100; Bg2 = 100; Accent = 100; Text = 100 }

function Get-PreviewWeather {
    $city = $script:ui.TxtCity.Text.Trim()
    try {
        $cachePath = Join-Path $script:root 'weather.json'
        if (Test-Path -LiteralPath $cachePath) {
            $cache = [IO.File]::ReadAllText($cachePath, [Text.Encoding]::UTF8) | ConvertFrom-Json
            if ($cache.Text -and $cache.Time -and ((Get-Date) - [datetime]$cache.Time).TotalHours -lt 6) { return [string]$cache.Text }
        }
    } catch { }
    if ($city) { return "$city · — °C" }
    return 'Погода (город не указан)'
}

function Update-Preview {
    try {
        $c1 = Get-Color $script:ui.TxtBg1.Text
        $c2 = Get-Color $script:ui.TxtBg2.Text
        $ca = Get-Color $script:ui.TxtAccent.Text
        $ct = Get-Color $script:ui.TxtText.Text

        $gradient = New-Object Windows.Media.LinearGradientBrush
        $gradient.StartPoint = New-Object Windows.Point(0, 0)
        $gradient.EndPoint = New-Object Windows.Point(1, 1)
        $gradient.GradientStops.Add((New-Object Windows.Media.GradientStop($c1, 0)))
        $gradient.GradientStops.Add((New-Object Windows.Media.GradientStop($c2, 1)))
        $script:ui.PrevRoot.Background = $gradient

        $alpha = [byte][math]::Round([int]$script:ui.SldTint.Value * 2.55)
        $script:ui.PrevTint.Fill = New-Object Windows.Media.SolidColorBrush ([Windows.Media.Color]::FromArgb($alpha, $c1.R, $c1.G, $c1.B))
        $script:ui.PrevGlow.Fill = New-Object Windows.Media.SolidColorBrush ($ca)

        $picName = ([string]$script:ui.TxtPic.Text).Trim()
        if ($picName) {
            if ($script:prevPicName -ne $picName) {
                $script:prevPicName = $picName
                $picPath = Join-Path $script:picsDir $picName
                if (Test-Path -LiteralPath $picPath) {
                    try {
                        $prevBmp = New-Object Windows.Media.Imaging.BitmapImage
                        $prevBmp.BeginInit()
                        $prevBmp.CacheOption = 'OnLoad'
                        $prevBmp.UriSource = New-Object Uri $picPath
                        $prevBmp.EndInit()
                        $script:ui.PrevPic.Source = $prevBmp
                    } catch { $script:ui.PrevPic.Source = $null }
                } else {
                    $script:ui.PrevPic.Source = $null
                }
            }
        } else {
            $script:prevPicName = ''
            $script:ui.PrevPic.Source = $null
        }
        $script:ui.PrevPic.Opacity = [double]$script:ui.SldPicOpacity.Value / 100.0
        if ($script:ui.ChkPicFit.IsChecked) {
            $script:ui.PrevPic.Stretch = 'UniformToFill'
            $picZoom = [double]$script:ui.SldPicZoom.Value / 100.0
            $script:ui.PrevPicScale.ScaleX = $picZoom
            $script:ui.PrevPicScale.ScaleY = $picZoom
        } else {
            $script:ui.PrevPic.Stretch = 'None'
            $script:ui.PrevPicScale.ScaleX = 1
            $script:ui.PrevPicScale.ScaleY = 1
        }
        $script:ui.LblPicOpacity.Text = [string][int]$script:ui.SldPicOpacity.Value + ' %'
        $script:ui.LblPicZoom.Text = [string][int]$script:ui.SldPicZoom.Value + ' %'

        $script:ui.PrevLine.Fill = New-Object Windows.Media.SolidColorBrush ($ca)
        $script:ui.PrevClock.Foreground = New-Object Windows.Media.SolidColorBrush ($ca)
        $script:ui.PrevTitle.Foreground = New-Object Windows.Media.SolidColorBrush ($ct)
        $script:ui.PrevSub.Foreground = New-Object Windows.Media.SolidColorBrush ($ct)
        $script:ui.PrevDate.Foreground = New-Object Windows.Media.SolidColorBrush ($ct)
        $script:ui.PrevDay.Foreground = New-Object Windows.Media.SolidColorBrush ($ct)
        $script:ui.PrevWeather.Foreground = New-Object Windows.Media.SolidColorBrush ($ct)
        $script:ui.PrevEvent.Foreground = New-Object Windows.Media.SolidColorBrush ($ct)

        $script:ui.PrevClock.Visibility = if ($script:ui.ChkClock.IsChecked) { 'Visible' } else { 'Collapsed' }
        $script:ui.PrevClock.Text = (Get-Date).ToString('HH:mm')

        $now = Get-Date
        $ru = [Globalization.CultureInfo]::GetCultureInfo('ru-RU')

        $script:ui.PrevDate.Visibility = if ($script:ui.ChkShowDate.IsChecked) { 'Visible' } else { 'Collapsed' }
        $script:ui.PrevDate.Text = $now.ToString("dddd, d MMMM yyyy 'года'", $ru)

        $script:ui.PrevDay.Visibility = if ($script:ui.ChkShowDayInfo.IsChecked) { 'Visible' } else { 'Collapsed' }
        $week = $ru.Calendar.GetWeekOfYear($now, [Globalization.CalendarWeekRule]::FirstFourDayWeek, [DayOfWeek]::Monday)
        $script:ui.PrevDay.Text = "$week-я неделя · $($now.DayOfYear)-й день года"

        $script:ui.PrevWeather.Visibility = if ($script:ui.ChkShowWeather.IsChecked) { 'Visible' } else { 'Collapsed' }
        $script:ui.PrevWeather.Text = Get-PreviewWeather

        $previewEvent = ''
        $eventName = $script:ui.TxtEventName.Text.Trim()
        if ($eventName -and $script:ui.TxtEventDate.Text.Trim()) {
            try {
                $eventDate = [datetime]::Parse($script:ui.TxtEventDate.Text.Trim(), $ru)
                $days = [int][math]::Ceiling(($eventDate.Date - $now.Date).TotalDays)
                if ($days -gt 1) { $previewEvent = "$eventName — через $days дн." }
                elseif ($days -eq 1) { $previewEvent = "$eventName — завтра" }
                elseif ($days -eq 0) { $previewEvent = "$eventName — сегодня" }
                elseif ($days -eq -1) { $previewEvent = "$eventName — был вчера" }
                elseif ($days -lt -1) { $previewEvent = "$eventName — прошёл $([math]::Abs($days)) дн. назад" }
            } catch { }
        }
        $script:ui.PrevEvent.Visibility = if ($script:ui.ChkShowEvent.IsChecked -and $previewEvent) { 'Visible' } else { 'Collapsed' }
        $script:ui.PrevEvent.Text = $previewEvent

        $size = [double]$script:ui.SldSize.Value
        $script:ui.PrevTitle.FontSize = [math]::Max(14, [math]::Min(38, $size * 0.4))
        $script:ui.PrevSub.FontSize = [math]::Max(11, [math]::Min(20, $size * 0.3))

        $title = $script:ui.TxtMessage.Text.Trim()
        if ($script:ui.ChkTime.IsChecked) {
            $h = (Get-Date).Hour
            $part = 'Доброй ночи'
            if ($h -ge 5 -and $h -lt 12) { $part = 'Доброе утро' }
            elseif ($h -ge 12 -and $h -lt 18) { $part = 'Добрый день' }
            elseif ($h -ge 18 -and $h -lt 23) { $part = 'Добрый вечер' }
            $who = $script:ui.TxtName.Text.Trim()
            $title = if ($who) { "$part, $who" } else { $part }
        }
        $script:ui.PrevTitle.Text = $title
        $script:ui.PrevSub.Text = $script:ui.TxtSub.Text
    } catch { }
    try { Start-PrevWeather } catch { }
}

function Update-RoleColor([string]$role) {
    $field = $script:roles[$role]
    $hex = Get-BrightColor $script:colorBase[$role] $script:colorBright[$role]
    $script:ui[$field.Hex].Text = $hex
    $script:ui[$field.Swatch].Background = $converter.ConvertFromString($hex)
}

function Update-RoleSelection([string]$role, $selected) {
    $panel = $script:ui[$script:roles[$role].Panel]
    foreach ($dot in $panel.Children) {
        $isSelected = ($null -ne $selected) -and ($dot -eq $selected)
        $dot.StrokeThickness = if ($isSelected) { 2.5 } else { 1 }
        $dot.Stroke = if ($isSelected) { $script:selectedBrush } else { $script:borderBrush }
    }
}

function Reset-Group([string]$group) {
    switch ($group) {
        'Text' {
            $script:ui.TxtName.Text = 'друг'
            $script:ui.TxtMessage.Text = 'Добро пожаловать'
            $script:ui.TxtSub.Text = 'Хорошего дня'
            $script:ui.SldSize.Value = 64
            $script:ui.ChkTime.IsChecked = $true
            $script:ui.ChkClock.IsChecked = $true
        }
        'Screen' {
            $script:ui.ChkShowDate.IsChecked = $true
            $script:ui.ChkShowDayInfo.IsChecked = $true
            $script:ui.ChkShowWeather.IsChecked = $true
            $script:ui.ChkShowEvent.IsChecked = $true
            $script:ui.ChkShowInfo.IsChecked = $true
            $script:ui.ChkShowNews.IsChecked = $true
            $script:ui.TxtEventName.Text = ''
            $script:ui.TxtEventDate.Text = ''
            $script:ui.TxtCity.Text = ''
        }
        'Bg' {
            $script:colorBase['Bg1'] = '#16233A'
            $script:colorBase['Bg2'] = '#070B12'
            $script:colorBase['Accent'] = '#FFFFFF'
            $script:colorBase['Text'] = '#FFFFFF'
            $script:ui.SldBlur.Value = 30
            $script:ui.SldTint.Value = 35
            foreach ($role in $script:roles.Keys) {
                $script:colorBright[$role] = 100
                $script:ui[$script:roles[$role].Slider].Value = 100
                $script:ui[$script:roles[$role].Label].Text = '100%'
                Update-RoleColor $role
                Update-RoleSelection $role $null
            }
        }
        'Time' {
            $script:ui.SldWait.Value = 10
            $script:ui.SldSeconds.Value = 8
        }
        'Sound' {
            $script:ui.SldSound.Value = 100
            $script:ui.SldMusic.Value = 60
            $script:ui.TxtSound.Text = 'startup.wav'
            $script:ui.TxtMusic.Text = 'music.mp3'
        }
        'Launch' {
            $script:ui.ChkAuto.IsChecked = $false
$script:ui.TxtNetwork.Text = ''
        }
    }
    Update-Preview
    $script:ui.LblStatus.Text = 'Сброшено. Нажмите «Сохранить», чтобы применить.'
}

foreach ($role in $script:roles.Keys) {
    $panel = $script:ui[$script:roles[$role].Panel]
    foreach ($color in $script:palette) {
        $dot = New-Object Windows.Shapes.Ellipse
        $dot.Width = 16
        $dot.Height = 16
        $dot.Margin = '0,0,4,0'
        $dot.Fill = $converter.ConvertFromString($color)
        $dot.Stroke = $script:borderBrush
        $dot.StrokeThickness = 1
        $dot.Cursor = [Windows.Input.Cursors]::Hand
        $dot.Tag = @($role, $color)
        $dot.Add_MouseLeftButtonDown({
            param($sender, $eventArgs)
            $role = $sender.Tag[0]
            $script:colorBase[$role] = $sender.Tag[1]
            $script:colorBright[$role] = 100
            $script:ui[$script:roles[$role].Slider].Value = 100
            Update-RoleColor $role
            Update-RoleSelection $role $sender
        })
        $panel.Children.Add($dot) | Out-Null
    }
}

foreach ($role in $script:roles.Keys) {
    $field = $script:roles[$role]
    $script:ui[$field.Slider].Tag = $role
    $script:ui[$field.Slider].Add_ValueChanged({
        param($sender, $eventArgs)
        $role = $sender.Tag
        $script:colorBright[$role] = [int]$sender.Value
        $script:ui[$script:roles[$role].Label].Text = [string][int]$sender.Value + '%'
        Update-RoleColor $role
    })
}

$script:ui.TxtName.Text = [string]$cfg.Name
$script:ui.TxtMessage.Text = [string]$cfg.Message
$script:ui.TxtSub.Text = [string]$cfg.SubMessage
$script:ui.SldSize.Value = [double]$cfg.FontSize
$script:ui.SldSeconds.Value = [double]$cfg.Seconds
$script:ui.SldWait.Value = [double]$cfg.WaitSeconds
$script:ui.SldBlur.Value = [double]$cfg.BlurRadius
$script:ui.SldTint.Value = [double]$cfg.TintOpacity
$script:ui.TxtPic.Text = [string]$cfg.PicFile
$picOpCfg = [int]$cfg.PicOpacity
if ($picOpCfg -lt 10) { $picOpCfg = 100 }
$script:ui.SldPicOpacity.Value = [double]$picOpCfg
$script:ui.SldPicZoom.Value = [double]$cfg.PicZoom
$script:ui.ChkPicFit.IsChecked = [bool]$cfg.PicFit
$script:ui.ChkTime.IsChecked = [bool]$cfg.TimeOfDay
$script:ui.ChkClock.IsChecked = [bool]$cfg.ShowClock
$script:ui.ChkShowDate.IsChecked = [bool]$cfg.ShowDate
$script:ui.ChkShowDayInfo.IsChecked = [bool]$cfg.ShowDayInfo
$script:ui.ChkShowWeather.IsChecked = [bool]$cfg.ShowWeather
$script:ui.ChkShowEvent.IsChecked = [bool]$cfg.ShowEvent
$script:ui.ChkShowInfo.IsChecked = [bool]$cfg.ShowInfo
$script:ui.ChkShowNews.IsChecked = [bool]$cfg.ShowNews
$script:ui.TxtEventName.Text = [string]$cfg.EventName
$script:ui.TxtEventDate.Text = [string]$cfg.EventDate
$script:ui.TxtCity.Text = [string]$cfg.City
$script:ui.TxtNetwork.Text = [string]$cfg.NetworkName
$script:ui.TxtUpdate.Text = [string]$cfg.UpdateUrl
# Пусто — подставляем сеть, к которой подключён этот ПК; пользователь может изменить
if (-not $script:ui.TxtNetwork.Text) { $script:ui.TxtNetwork.Text = Get-WifiSsid }
$script:ui.ChkAuto.IsChecked = Test-Path -LiteralPath $script:startupLink
$script:ui.ChkWeatherEffect.IsChecked = [bool]$cfg.WeatherEffect
$script:ui.ChkPreviewWeather.IsChecked = [bool]$cfg.PreviewWeather
$script:ui.CmbTestWeather.SelectedIndex = 0
$script:ui.TxtSound.Text = [string]$cfg.SoundFile
$script:ui.TxtMusic.Text = [string]$cfg.MusicFile
$script:ui.SldSound.Value = [double]$cfg.SoundVolume
$script:ui.SldMusic.Value = [double]$cfg.MusicVolume
$script:ui.LblSoundVol.Text = [string][int]$script:ui.SldSound.Value + ' %'
$script:ui.LblMusicVol.Text = [string][int]$script:ui.SldMusic.Value + ' %'
$script:ui.LblSize.Text = [string][int]$script:ui.SldSize.Value + ' pt'
$script:ui.LblSeconds.Text = [string][int]$script:ui.SldSeconds.Value + ' с'
$script:ui.LblWait.Text = [string][int]$script:ui.SldWait.Value + ' с'
$script:ui.LblBlur.Text = [string][int]$script:ui.SldBlur.Value
$script:ui.LblTint.Text = [string][int]$script:ui.SldTint.Value + ' %'
$script:ui.TxtMessage.IsEnabled = -not [bool]$cfg.TimeOfDay

foreach ($role in $script:roles.Keys) {
    $script:ui[$script:roles[$role].Slider].Value = 100
    $script:ui[$script:roles[$role].Label].Text = '100%'
    Update-RoleColor $role
    $panel = $script:ui[$script:roles[$role].Panel]
    $matched = @($panel.Children | Where-Object { $_.Tag[1] -eq $script:colorBase[$role] })
    if ($matched.Count -gt 0) { Update-RoleSelection $role $matched[0] } else { Update-RoleSelection $role $null }
}

$script:presets = [ordered]@{
    'Ночь'   = @('#16233A', '#070B12', '#FFFFFF', '#FFFFFF')
    'Космос' = @('#241B4B', '#0B0620', '#B388FF', '#FFFFFF')
    'Закат'  = @('#4A1B2F', '#14060C', '#FF8A5B', '#FFF3E6')
    'Лес'    = @('#12301F', '#05130B', '#7BE495', '#EAF7EE')
    'Сталь'  = @('#23272E', '#0E1013', '#9FB3C8', '#F0F3F7')
    'Роза'   = @('#3A1230', '#12040F', '#FF7BAC', '#FFE9F1')
}

foreach ($key in $script:presets.Keys) {
    $values = $script:presets[$key]
    $button = New-Object Windows.Controls.Button
    $button.Content = $key
    $button.Tag = $key
    $button.Padding = '16,8'
    $button.Margin = '0,0,8,8'
    $button.BorderThickness = 2
    $button.Background = $converter.ConvertFromString($values[0])
    $button.Foreground = $converter.ConvertFromString($values[3])
    $button.BorderBrush = $converter.ConvertFromString($values[2])
    $button.Add_Click({
        $values = $script:presets[$this.Tag]
        $script:colorBase['Bg1'] = $values[0]
        $script:colorBase['Bg2'] = $values[1]
        $script:colorBase['Accent'] = $values[2]
        $script:colorBase['Text'] = $values[3]
        foreach ($role in $script:roles.Keys) {
            $script:colorBright[$role] = 100
            $script:ui[$script:roles[$role].Slider].Value = 100
            $script:ui[$script:roles[$role].Label].Text = '100%'
            Update-RoleColor $role
            Update-RoleSelection $role $null
        }
        Update-Preview
    })
    $script:ui.PresetPanel.Children.Add($button) | Out-Null
}

$script:ui.SldSize.Add_ValueChanged({ $script:ui.LblSize.Text = [string][int]$script:ui.SldSize.Value + ' pt' })
$script:ui.SldSeconds.Add_ValueChanged({ $script:ui.LblSeconds.Text = [string][int]$script:ui.SldSeconds.Value + ' с' })
$script:ui.SldWait.Add_ValueChanged({ $script:ui.LblWait.Text = [string][int]$script:ui.SldWait.Value + ' с' })
$script:ui.SldBlur.Add_ValueChanged({ $script:ui.LblBlur.Text = [string][int]$script:ui.SldBlur.Value })
$script:ui.SldTint.Add_ValueChanged({ $script:ui.LblTint.Text = [string][int]$script:ui.SldTint.Value + ' %' })

$script:ui.ChkTime.Add_Checked({ $script:ui.TxtMessage.IsEnabled = $false })
$script:ui.ChkTime.Add_Unchecked({ $script:ui.TxtMessage.IsEnabled = $true })

foreach ($element in @($script:ui.TxtName, $script:ui.TxtMessage, $script:ui.TxtSub,
        $script:ui.TxtBg1, $script:ui.TxtBg2, $script:ui.TxtAccent, $script:ui.TxtText,
        $script:ui.TxtEventName, $script:ui.TxtEventDate, $script:ui.TxtCity, $script:ui.TxtNetwork)) {
    $element.Add_TextChanged({ param($sender, $eventArgs) Update-Preview })
}
foreach ($slider in @($script:ui.SldSize, $script:ui.SldBlur, $script:ui.SldTint, $script:ui.SldPicOpacity, $script:ui.SldPicZoom)) {
    $slider.Add_ValueChanged({ param($sender, $eventArgs) Update-Preview })
}
$script:ui.TxtPic.Add_TextChanged({ param($sender, $eventArgs) Update-Preview })
$script:ui.ChkPicFit.Add_Checked({ param($sender, $eventArgs) Update-Preview })
$script:ui.ChkPicFit.Add_Unchecked({ param($sender, $eventArgs) Update-Preview })
foreach ($check in @($script:ui.ChkTime, $script:ui.ChkClock, $script:ui.ChkShowDate,
        $script:ui.ChkShowDayInfo, $script:ui.ChkShowWeather, $script:ui.ChkShowEvent)) {
    $check.Add_Checked({ param($sender, $eventArgs) Update-Preview })
    $check.Add_Unchecked({ param($sender, $eventArgs) Update-Preview })
}

$script:ui.SldSound.Add_ValueChanged({ $script:ui.LblSoundVol.Text = [string][int]$script:ui.SldSound.Value + ' %' })
$script:ui.SldMusic.Add_ValueChanged({ $script:ui.LblMusicVol.Text = [string][int]$script:ui.SldMusic.Value + ' %' })

function Pick-Audio([string]$kind) {
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    if ($kind -eq 'sound') { $dlg.Title = 'Звук приветствия' } else { $dlg.Title = 'Фоновая музыка' }
    $dlg.Filter = 'Аудио (*.mp3;*.wav;*.ogg;*.m4a;*.wma)|*.mp3;*.wav;*.ogg;*.m4a;*.wma|Все файлы (*.*)|*.*'
    if ($dlg.ShowDialog() -ne $true) { return }
    $ext = [IO.Path]::GetExtension($dlg.FileName)
    if (-not $ext) { $ext = '.mp3' }
    $name = [IO.Path]::GetFileName($dlg.FileName)
    if (-not $name) { $name = 'audio' + $ext }
    $dest = Join-Path $script:root $name
    try {
        Copy-Item -LiteralPath $dlg.FileName -Destination $dest -Force
        if ($kind -eq 'sound') { $script:ui.TxtSound.Text = $name }
        else { $script:ui.TxtMusic.Text = $name }
        $script:ui.LblStatus.Text = 'Файл обновлён: ' + $name + '. Нажмите «Сохранить».'
    } catch {
        $script:ui.LblStatus.Text = 'Не удалось скопировать файл: ' + $_.Exception.Message
    }
}

$script:ui.BtnPickSound.Add_Click({ Pick-Audio 'sound' })
$script:ui.BtnPickMusic.Add_Click({ Pick-Audio 'music' })
$script:ui.BtnResetSound.Add_Click({ Reset-Group 'Sound' })

$script:ui.BtnResetText.Add_Click({ Reset-Group 'Text' })
$script:ui.BtnResetBg.Add_Click({ Reset-Group 'Bg' })

$script:ui.BtnPickPic.Add_Click({
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = 'Картинка на фон'
    $dlg.Filter = 'Изображения (*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp)|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp|Все файлы (*.*)|*.*'
    if ($dlg.ShowDialog() -ne $true) { return }
    $name = [IO.Path]::GetFileName($dlg.FileName)
    if (-not $name) { return }
    try {
        if (-not (Test-Path -LiteralPath $script:picsDir)) { [void](New-Item -ItemType Directory -Path $script:picsDir) }
        Copy-Item -LiteralPath $dlg.FileName -Destination (Join-Path $script:picsDir $name) -Force
        $script:ui.TxtPic.Text = $name
        if ([double]$script:ui.SldPicOpacity.Value -lt 10) { $script:ui.SldPicOpacity.Value = 100 }
        $script:ui.LblStatus.Text = 'Картинка скопирована в папку pics: ' + $name
    } catch {
        $script:ui.LblStatus.Text = 'Не удалось скопировать: ' + $_.Exception.Message
    }
})
$script:ui.BtnClearPic.Add_Click({
    $script:ui.TxtPic.Text = ''
    $script:ui.SldPicOpacity.Value = 100
    $script:ui.SldPicZoom.Value = 100
})
$script:ui.BtnResetPic.Add_Click({
    $script:ui.TxtPic.Text = ''
    $script:ui.SldPicOpacity.Value = 100
    $script:ui.SldPicZoom.Value = 100
})
$script:ui.BtnResetTime.Add_Click({ Reset-Group 'Time' })
$script:ui.BtnResetLaunch.Add_Click({ Reset-Group 'Launch' })
$script:ui.BtnResetScreen.Add_Click({ Reset-Group 'Screen' })

function Save-Settings {
    $missing = @()
    $soundName = $script:ui.TxtSound.Text.Trim()
    $musicName = $script:ui.TxtMusic.Text.Trim()
    if ($soundName -and -not (Test-Path -LiteralPath (Join-Path $script:root $soundName))) { $missing += 'звук приветствия' }
    if ($musicName -and -not (Test-Path -LiteralPath (Join-Path $script:root $musicName))) { $missing += 'фоновая музыка' }
    if ($missing.Count -gt 0) {
        $script:ui.LblStatus.Text = 'Не найдены файлы: ' + ($missing -join ', ') + '. Выберите файл кнопкой «Выбрать…».'
        return
    }
    $data = [ordered]@{
        Name        = $script:ui.TxtName.Text.Trim()
        Message     = $script:ui.TxtMessage.Text.Trim()
        SubMessage  = $script:ui.TxtSub.Text.Trim()
        Bg1         = $script:ui.TxtBg1.Text
        Bg2         = $script:ui.TxtBg2.Text
        Accent      = $script:ui.TxtAccent.Text
        TextColor   = $script:ui.TxtText.Text
        FontSize    = [int]$script:ui.SldSize.Value
        Seconds     = [int]$script:ui.SldSeconds.Value
        WaitSeconds = [int]$script:ui.SldWait.Value
        TimeOfDay   = [bool]$script:ui.ChkTime.IsChecked
        ShowClock   = [bool]$script:ui.ChkClock.IsChecked
        ShowDate    = [bool]$script:ui.ChkShowDate.IsChecked
        ShowDayInfo = [bool]$script:ui.ChkShowDayInfo.IsChecked
        ShowWeather = [bool]$script:ui.ChkShowWeather.IsChecked
        ShowEvent   = [bool]$script:ui.ChkShowEvent.IsChecked
        ShowInfo    = [bool]$script:ui.ChkShowInfo.IsChecked
        ShowNews    = [bool]$script:ui.ChkShowNews.IsChecked
        EventName   = $script:ui.TxtEventName.Text.Trim()
        EventDate   = $script:ui.TxtEventDate.Text.Trim()
        City        = $script:ui.TxtCity.Text.Trim()
        NetworkName = $script:ui.TxtNetwork.Text.Trim()
        UpdateUrl   = $script:ui.TxtUpdate.Text.Trim()
        BlurRadius  = [int]$script:ui.SldBlur.Value
        TintOpacity = [int]$script:ui.SldTint.Value
        WeatherEffect  = [bool]$script:ui.ChkWeatherEffect.IsChecked
        PreviewWeather = [bool]$script:ui.ChkPreviewWeather.IsChecked
        SoundFile      = $script:ui.TxtSound.Text.Trim()
        SoundVolume    = [int]$script:ui.SldSound.Value
        MusicFile      = $script:ui.TxtMusic.Text.Trim()
        MusicVolume    = [int]$script:ui.SldMusic.Value
        PicFile        = $script:ui.TxtPic.Text.Trim()
        PicOpacity     = [int]$script:ui.SldPicOpacity.Value
        PicZoom        = [int]$script:ui.SldPicZoom.Value
        PicFit         = [bool]$script:ui.ChkPicFit.IsChecked
    }
    [IO.File]::WriteAllText($script:cfgFile, ($data | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
    Set-Autostart ([bool]$script:ui.ChkAuto.IsChecked)
}

function Set-Autostart([bool]$enabled) {
    if ($enabled) {
        $taskExists = $false
        try { $taskExists = $null -ne (Get-ScheduledTask -TaskName 'Приветствие' -ErrorAction SilentlyContinue) } catch { }
        if (-not $taskExists) {
            $ws = New-Object -ComObject WScript.Shell
            $lnk = $ws.CreateShortcut($script:startupLink)
            $lnk.TargetPath = Join-Path $env:WINDIR 'System32\wscript.exe'
            $lnk.Arguments = '"' + (Join-Path $script:root 'launch.vbs') + '" welcome'
            $lnk.WorkingDirectory = $script:root
            $lnk.Description = 'Приветствие при включении ПК'
            $lnk.Save()
        }
    } else {
        if (Test-Path -LiteralPath $script:startupLink) { Remove-Item -LiteralPath $script:startupLink -Force }
        try { Unregister-ScheduledTask -TaskName 'Приветствие' -Confirm:$false -ErrorAction SilentlyContinue | Out-Null } catch { }
    }
}

$script:prevWeatherTimer = $null
$script:prevWeatherItems = New-Object System.Collections.ArrayList

function Stop-PrevWeather {
    if ($script:prevWeatherTimer) { try { $script:prevWeatherTimer.Stop() } catch { } }
    $script:prevWeatherItems.Clear()
    if ($script:ui.PrevWeatherFx) { $script:ui.PrevWeatherFx.Children.Clear() }
}

function Start-PrevWeather {
    Stop-PrevWeather
    if (-not $script:ui.ChkPreviewWeather.IsChecked) { return }
    $index = $script:ui.CmbTestWeather.SelectedIndex
    if ($index -eq 3) { return }
    $kind = @('rain', 'snow', 'mixed')[$index]

    $w = [double]$script:ui.PrevRoot.ActualWidth
    $h = 300.0
    if ($w -le 0) { $w = 800 }
    $hex = $script:ui.TxtText.Text
    if ($hex -notmatch '^#[0-9A-Fa-f]{6}$') { $hex = '#FFFFFF' }
    $brush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($hex))
    $brush.Opacity = 0.55

    $rain = 0
    $snow = 0
    switch ($kind) {
        'rain' { $rain = 45 }
        'snow' { $snow = 35 }
        'mixed' { $rain = 24; $snow = 18 }
    }

    for ($i = 0; $i -lt $rain; $i++) {
        $line = New-Object Windows.Shapes.Line
        $line.Stroke = $brush
        $line.StrokeThickness = 1
        $x = Get-Random -Minimum 0 -Maximum ([int]$w)
        $y = Get-Random -Minimum 0 -Maximum ([int]$h)
        $len = Get-Random -Minimum 7 -Maximum 14
        $line.X1 = $x; $line.Y1 = $y; $line.X2 = $x + 1; $line.Y2 = $y + $len
        $script:ui.PrevWeatherFx.Children.Add($line) | Out-Null
        [void]$script:prevWeatherItems.Add(@{ Kind = 'rain'; Element = $line; X = [double]$x; Y = [double]$y; Speed = (Get-Random -Minimum 260 -Maximum 420); Drift = (Get-Random -Minimum 20 -Maximum 50); Len = $len })
    }
    for ($i = 0; $i -lt $snow; $i++) {
        $dot = New-Object Windows.Shapes.Ellipse
        $d = Get-Random -Minimum 2 -Maximum 4
        $dot.Width = $d
        $dot.Height = $d
        $dot.Fill = $brush
        $x = Get-Random -Minimum 0 -Maximum ([int]$w)
        $y = Get-Random -Minimum 0 -Maximum ([int]$h)
        [Windows.Controls.Canvas]::SetLeft($dot, $x)
        [Windows.Controls.Canvas]::SetTop($dot, $y)
        $script:ui.PrevWeatherFx.Children.Add($dot) | Out-Null
        [void]$script:prevWeatherItems.Add(@{ Kind = 'snow'; Element = $dot; X = [double]$x; Y = [double]$y; Speed = (Get-Random -Minimum 12 -Maximum 35); Phase = (Get-Random -Minimum 0 -Maximum 628) / 100.0 })
    }

    $script:prevWeatherWidth = $w
    $script:prevWeatherTimer = New-Object Windows.Threading.DispatcherTimer
    $script:prevWeatherTimer.Interval = [TimeSpan]::FromMilliseconds(50)
    $script:prevWeatherTimer.Add_Tick({
        foreach ($p in $script:prevWeatherItems) {
            if ($p.Kind -eq 'rain') {
                $p.Y += $p.Speed * 0.05
                $p.X += $p.Drift * 0.05
                if ($p.Y -gt 300) {
                    $p.Y = -10
                    $p.X = Get-Random -Minimum 0 -Maximum ([int]$script:prevWeatherWidth)
                }
                $p.Element.X1 = $p.X
                $p.Element.Y1 = $p.Y
                $p.Element.X2 = $p.X + 1
                $p.Element.Y2 = $p.Y + $p.Len
            } else {
                $p.Y += $p.Speed * 0.05
                $p.Phase += 0.04
                $p.X += [math]::Sin($p.Phase) * 0.5
                if ($p.Y -gt 300) {
                    $p.Y = -6
                    $p.X = Get-Random -Minimum 0 -Maximum ([int]$script:prevWeatherWidth)
                }
                [Windows.Controls.Canvas]::SetLeft($p.Element, $p.X)
                [Windows.Controls.Canvas]::SetTop($p.Element, $p.Y)
            }
        }
    })
    $script:prevWeatherTimer.Start()
}

$script:ui.BtnSave.Add_Click({
    Save-Settings
    $script:ui.LblStatus.Text = 'Сохранено в ' + (Get-Date).ToString('HH:mm:ss')
})

$script:ui.ChkPreviewWeather.Add_Click({ Update-Preview })
$script:ui.CmbTestWeather.Add_SelectionChanged({ Update-Preview })
$script:ui.ChkWeatherEffect.Add_Click({ Update-Preview })

$script:ui.BtnTest.Add_Click({
    Save-Settings
    $effect = @('rain', 'snow', 'mixed', 'none')[$script:ui.CmbTestWeather.SelectedIndex]
    if (-not $script:ui.ChkWeatherEffect.IsChecked) { $effect = 'none' }
    $args = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "{0}" -Seconds 6 -WeatherEffect {1}' -f $script:welcomePath, $effect
    Start-Process -FilePath 'powershell.exe' -ArgumentList $args -WindowStyle Hidden
    $script:ui.LblStatus.Text = 'Предпросмотр запущен — окно закроется само'
})

$script:ui.BtnClose.Add_Click({ $window.Close() })

$window.Add_Closed({ try { Stop-PrevWeather } catch { } })

Update-Preview

$window.ShowDialog() | Out-Null
