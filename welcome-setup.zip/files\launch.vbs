Set fso = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
dir = fso.GetParentFolderName(WScript.ScriptFullName)

arg = "welcome"
If WScript.Arguments.Count > 0 Then arg = LCase(WScript.Arguments(0))

script = "Welcome.ps1"
If arg = "settings" Then script = "Settings.ps1"

sh.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & dir & "\" & script & """", 0, False
