﻿param(
    [switch]$SelfTest,
    [int]$Seconds = 0,
    [string]$WeatherEffect = 'auto'
)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class ScreenGuard
{
    [DllImport("user32.dll")]
    private static extern bool SetWindowDisplayAffinity(IntPtr hwnd, uint affinity);

    [DllImport("gdi32.dll")]
    private static extern bool DeleteObject(IntPtr hObject);

    public static bool Exclude(IntPtr hwnd)
    {
        return SetWindowDisplayAffinity(hwnd, 0x00000011);
    }

    public static void Release(IntPtr handle)
    {
        DeleteObject(handle);
    }
}
"@

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class AudioInfo
{
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    private class MMDeviceEnumeratorComObject { }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        int NotImpl1();
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int context, IntPtr param, [MarshalAs(UnmanagedType.IUnknown)] out object obj);
    }

    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioEndpointVolume
    {
        int NotImpl1();
        int NotImpl2();
        [PreserveSig] int GetChannelCount(out uint count);
        int NotImpl3();
        int NotImpl4();
        int NotImpl5();
        [PreserveSig] int GetMasterVolumeLevelScalar(out float level);
        int NotImpl6();
        int NotImpl7();
        int NotImpl8();
        int NotImpl9();
        int NotImpl10();
        [PreserveSig] int GetMute(out bool mute);
    }

    // -1 = звук выключен, 0..100 = громкость
    public static int GetVolume()
    {
        var enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumeratorComObject());
        IMMDevice device;
        enumerator.GetDefaultAudioEndpoint(0, 1, out device);
        Guid iid = typeof(IAudioEndpointVolume).GUID;
        object obj;
        device.Activate(ref iid, 23, IntPtr.Zero, out obj);
        var volume = (IAudioEndpointVolume)obj;
        float level;
        volume.GetMasterVolumeLevelScalar(out level);
        bool mute;
        volume.GetMute(out mute);
        if (mute) { return -1; }
        return (int)Math.Round(level * 100);
    }
}
"@

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$cfgFile = Join-Path $root 'settings.json'
$newsCache = Join-Path $root 'news.json'

$cfg = [ordered]@{
    Name         = 'друг'
    Message      = 'Добро пожаловать'
    SubMessage   = 'Хорошего дня'
    Bg1          = '#16233A'
    Bg2          = '#070B12'
    Accent       = '#FFFFFF'
    TextColor    = '#FFFFFF'
    FontSize     = 64
    Seconds      = 8
    WaitSeconds  = 10
    TimeOfDay    = $true
    ShowClock    = $true
    ShowDate     = $true
    ShowDayInfo  = $true
    ShowWeather  = $true
    ShowEvent    = $true
    ShowInfo     = $true
    ShowNews     = $true
    EventName    = ''
    EventDate    = ''
    City         = ''
    NetworkName  = ''
    BlurRadius   = 30
    TintOpacity  = 35
    UpdateUrl    = ''
    WeatherEffect = $true
    PreviewWeather = $true
    SoundFile    = 'startup.wav'
    SoundVolume  = 100
    MusicFile    = 'music.mp3'
    MusicVolume  = 60
    PicFile      = ''
    PicOpacity   = 100
    PicZoom      = 100
    PicFit       = $true
}

if (Test-Path -LiteralPath $cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in @($cfg.Keys)) {
            if ($null -ne $saved.$k) { $cfg[$k] = $saved.$k }
        }
    } catch { }
}

$versionFile = Join-Path $root 'version.txt'
$script:appVersion = '1.0'
if (Test-Path -LiteralPath $versionFile) {
    $savedVersion = (Get-Content -LiteralPath $versionFile -Raw).Trim()
    if ($savedVersion) { $script:appVersion = $savedVersion }
}

function Get-Hex([string]$value, [string]$fallback) {
    if ($value -match '^#[0-9A-Fa-f]{6}$') { return $value.ToUpper() }
    return $fallback
}

function Enc([string]$value) {
    if ([string]::IsNullOrEmpty($value)) { return '' }
    return [System.Security.SecurityElement]::Escape($value)
}

function Get-ClampedInt($value, [int]$fallback, [int]$min, [int]$max) {
    $n = 0
    if ([int]::TryParse([string]$value, [ref]$n) -and $n -ge $min -and $n -le $max) { return $n }
    return $fallback
}

$script:newsTask = $null
$script:newsDone = $false
$script:newsStart = $null
$script:newsClient = $null

function Start-NewsRequest {
    if ($script:newsTask -or $script:newsDone) { return }
    try {
        $client = New-Object System.Net.WebClient
        $client.Headers.Add('User-Agent', 'Mozilla/5.0')
        $script:newsClient = $client
        $script:newsStart = Get-Date
        $script:newsTask = $client.DownloadDataTaskAsync('https://news.google.com/rss?hl=ru&gl=RU&ceid=RU:ru')
    } catch { $script:newsDone = $true }
}

function Complete-NewsRequest {
    if ($script:newsDone) { return }
    if ($script:newsTask -and -not $script:newsTask.IsCompleted) {
        if ($script:newsStart -and ((Get-Date) - $script:newsStart).TotalSeconds -gt 12) { $script:newsDone = $true; $script:newsTask = $null }
        return
    }
    $script:newsDone = $true
    $bytes = $null
    try { if ($script:newsTask) { $bytes = $script:newsTask.GetAwaiter().GetResult() } } catch { }
    $raw = $null
    if ($bytes) { try { $raw = [Text.Encoding]::UTF8.GetString($bytes) } catch { } }
    $script:newsTask = $null

    $title = ''
    if ($raw) {
        try {
            $xml = [xml]$raw
            $titles = @(@($xml.rss.channel.item) | ForEach-Object { ([string]$_.title).Trim() } | Where-Object { $_ })
            if ($titles.Count -gt 0) {
                $state = $null
                try {
                    if (Test-Path -LiteralPath $newsCache) { $state = [IO.File]::ReadAllText($newsCache, [Text.Encoding]::UTF8) | ConvertFrom-Json }
                } catch { }
                $shown = @()
                if ($state -and $state.Shown) { $shown = @($state.Shown) }
                # Уже показанные пропускаем, чтобы при повторном запуске была другая новость
                $fresh = @($titles | Where-Object { $shown -notcontains $_ })
                if ($fresh.Count -eq 0) { $fresh = $titles; $shown = @() }
                $title = $fresh | Get-Random
                $shown = @($shown + $title)
                if ($shown.Count -gt 30) { $shown = @($shown | Select-Object -Last 30) }
                $cache = @{ Title = $title; Time = (Get-Date).ToString('o'); Shown = $shown }
                [IO.File]::WriteAllText($newsCache, ($cache | ConvertTo-Json -Depth 3), (New-Object Text.UTF8Encoding($false)))
            }
        } catch { }
    }

    if (-not $title) {
        try {
            if (Test-Path -LiteralPath $newsCache) {
                $state = [IO.File]::ReadAllText($newsCache, [Text.Encoding]::UTF8) | ConvertFrom-Json
                if ($state.Title -and $state.Time -and ((Get-Date) - [datetime]$state.Time).TotalHours -lt 48) { $title = [string]$state.Title }
            }
        } catch { }
    }

    if ($title) {
        if ($title.Length -gt 150) { $title = $title.Substring(0, 147) + '…' }
        $script:newsText.Text = 'Google Новости · ' + $title
    }
}

function Get-WeatherWord([int]$code) {
    if ($code -eq 0) { return 'ясно' }
    if ($code -le 3) { return 'облачно' }
    if ($code -eq 45 -or $code -eq 48) { return 'туман' }
    if ($code -ge 51 -and $code -le 57) { return 'морось' }
    if ($code -ge 61 -and $code -le 67) { return 'дождь' }
    if ($code -ge 71 -and $code -le 77) { return 'снег' }
    if ($code -ge 80 -and $code -le 82) { return 'ливень' }
    if ($code -ge 85 -and $code -le 86) { return 'снегопад' }
    if ($code -ge 95) { return 'гроза' }
    return 'облачно'
}

$script:weatherTask = $null
$script:weatherStage = 0
$script:weatherCity = ''
$script:weatherLat = 0
$script:weatherLon = 0
$script:weatherName = ''
$script:weatherStart = $null
$script:weatherClient = $null

function Get-CachedWeatherText {
    try {
        $path = Join-Path $root 'weather.json'
        if (Test-Path -LiteralPath $path) {
            $cache = [IO.File]::ReadAllText($path, [Text.Encoding]::UTF8) | ConvertFrom-Json
            if ($cache.Text -and $cache.Time -and ((Get-Date) - [datetime]$cache.Time).TotalHours -lt 6) { return [string]$cache.Text }
        }
    } catch { }
    return ''
}

function Show-WeatherText([string]$text) {
    if (-not $text) { return }
    $script:weatherLine.Text = $text
    $script:weatherLine.Visibility = 'Visible'
}

function Start-WeatherGeo {
    try {
        $client = New-Object System.Net.WebClient
        $script:weatherClient = $client
        $script:weatherStart = Get-Date
        $uri = 'https://geocoding-api.open-meteo.com/v1/search?name=' + [uri]::EscapeDataString($script:weatherCity) + '&count=1&language=ru&format=json'
        $script:weatherTask = $client.DownloadDataTaskAsync($uri)
        $script:weatherStage = 2
    } catch { $script:weatherStage = 99 }
}

function Start-WeatherForecast {
    try {
        $client = New-Object System.Net.WebClient
        $script:weatherClient = $client
        $script:weatherStart = Get-Date
        $uri = 'https://api.open-meteo.com/v1/forecast?latitude=' + $script:weatherLat + '&longitude=' + $script:weatherLon + '&current=temperature_2m,weather_code&timezone=auto'
        $script:weatherTask = $client.DownloadDataTaskAsync($uri)
        $script:weatherStage = 3
    } catch { $script:weatherStage = 99 }
}

function Start-WeatherRequest {
    if ($script:weatherStage -ne 0) { return }
    $city = ([string]$cfg.City).Trim()
    if ($city) {
        $script:weatherCity = $city
        Start-WeatherGeo
        return
    }
    try {
        $client = New-Object System.Net.WebClient
        $script:weatherClient = $client
        $script:weatherStart = Get-Date
        $script:weatherTask = $client.DownloadDataTaskAsync('http://ip-api.com/json/?fields=city&lang=ru')
        $script:weatherStage = 1
    } catch { $script:weatherStage = 99 }
}

function Complete-WeatherStep {
    if ($script:weatherStage -eq 0 -or $script:weatherStage -eq 99) { return }
    if ($script:weatherTask -and -not $script:weatherTask.IsCompleted) {
        if ($script:weatherStart -and ((Get-Date) - $script:weatherStart).TotalSeconds -gt 12) { $script:weatherStage = 99 }
        return
    }
    $bytes = $null
    try { if ($script:weatherTask) { $bytes = $script:weatherTask.GetAwaiter().GetResult() } } catch { }
    $raw = $null
    if ($bytes) { try { $raw = [Text.Encoding]::UTF8.GetString($bytes) } catch { } }
    $script:weatherTask = $null

    switch ($script:weatherStage) {
        1 {
            $city = ''
            if ($raw) { try { $city = ([string](($raw | ConvertFrom-Json).city)).Trim() } catch { } }
            if ($city) { $script:weatherCity = $city; Start-WeatherGeo } else { $script:weatherStage = 99 }
        }
        2 {
            $ok = $false
            if ($raw) {
                try {
                    $place = @(($raw | ConvertFrom-Json).results)[0]
                    if ($place) {
                        $script:weatherLat = $place.latitude
                        $script:weatherLon = $place.longitude
                        $script:weatherName = [string]$place.name
                        $ok = $true
                    }
                } catch { }
            }
            if ($ok) { Start-WeatherForecast } else { $script:weatherStage = 99 }
        }
        3 {
            if ($raw) {
                try {
                    $fc = $raw | ConvertFrom-Json
                    if ($fc.current) {
                        $temp = [int][math]::Round([double]$fc.current.temperature_2m)
                        $code = [int]$fc.current.weather_code
                        $word = Get-WeatherWord $code
                        $text = "$($script:weatherName) · $temp °C, $word"
                        Show-WeatherText $text
                        Apply-WeatherFromCode $code
                        $cache = @{ Text = $text; Time = (Get-Date).ToString('o'); Code = $code }
                        [IO.File]::WriteAllText((Join-Path $root 'weather.json'), ($cache | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
                    }
                } catch { }
            }
            $script:weatherStage = 99
        }
    }

    if ($script:weatherStage -eq 99) {
        $cached = Get-CachedWeatherText
        if ($cached) { Show-WeatherText $cached }
    }
}

$script:weatherItems = New-Object System.Collections.ArrayList
$script:weatherTimer = $null
$script:weatherKind = 'none'

function Get-WeatherEffectKind([int]$code) {
    if (@(71,73,75,77,85,86) -contains $code) { return 'snow' }
    if (@(66,67) -contains $code) { return 'mixed' }
    if (@(51,53,55,56,57,61,63,65,80,81,82,95,96,99) -contains $code) { return 'rain' }
    return 'none'
}

function Stop-WeatherEffect {
    if ($script:weatherTimer) { try { $script:weatherTimer.Stop() } catch { } }
    $script:weatherItems.Clear()
    if ($script:weatherLayer) { $script:weatherLayer.Children.Clear() }
}

function Start-WeatherEffect([string]$kind) {
    Stop-WeatherEffect
    $script:weatherKind = $kind
    if (-not $kind -or $kind -eq 'auto' -or $kind -eq 'none') { return }
    if (-not $cfg.WeatherEffect -and $WeatherEffect -eq 'auto') { return }

    $w = [double]$window.ActualWidth
    $h = [double]$window.ActualHeight
    if ($w -le 0) { $w = $script:screenBounds.Width }
    if ($h -le 0) { $h = $script:screenBounds.Height }

    $textHex = Get-Hex $cfg.TextColor '#FFFFFF'
    $rainBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($textHex))
    $rainBrush.Opacity = 0.35
    $snowBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($textHex))
    $snowBrush.Opacity = 0.8

    $rainCount = 0
    $snowCount = 0
    switch ($kind) {
        'rain' { $rainCount = 150 }
        'snow' { $snowCount = 110 }
        'mixed' { $rainCount = 80; $snowCount = 60 }
    }

    for ($i = 0; $i -lt $rainCount; $i++) {
        $line = New-Object Windows.Shapes.Line
        $line.Stroke = $rainBrush
        $line.StrokeThickness = [math]::Max(1, (S 1.2))
        $line.Opacity = (Get-Random -Minimum 25 -Maximum 70) / 100.0
        $x = Get-Random -Minimum 0 -Maximum ([int]$w)
        $y = Get-Random -Minimum 0 -Maximum ([int]$h)
        $len = Get-Random -Minimum 10 -Maximum 26
        $line.X1 = $x; $line.Y1 = $y; $line.X2 = $x + 2; $line.Y2 = $y + $len
        $script:weatherLayer.Children.Add($line) | Out-Null
        [void]$script:weatherItems.Add(@{ Kind='rain'; Element=$line; X=[double]$x; Y=[double]$y; Speed=(Get-Random -Minimum 700 -Maximum 1100); Drift=(Get-Random -Minimum 40 -Maximum 110); Len=$len })
    }
    for ($i = 0; $i -lt $snowCount; $i++) {
        $dot = New-Object Windows.Shapes.Ellipse
        $d = Get-Random -Minimum 2 -Maximum 6
        $dot.Width = $d
        $dot.Height = $d
        $dot.Fill = $snowBrush
        $dot.Opacity = (Get-Random -Minimum 40 -Maximum 90) / 100.0
        $x = Get-Random -Minimum 0 -Maximum ([int]$w)
        $y = Get-Random -Minimum 0 -Maximum ([int]$h)
        [Windows.Controls.Canvas]::SetLeft($dot, $x)
        [Windows.Controls.Canvas]::SetTop($dot, $y)
        $script:weatherLayer.Children.Add($dot) | Out-Null
        [void]$script:weatherItems.Add(@{ Kind='snow'; Element=$dot; X=[double]$x; Y=[double]$y; Speed=(Get-Random -Minimum 25 -Maximum 70); Phase=(Get-Random -Minimum 0 -Maximum 628)/100.0 })
    }

    $script:weatherWidth = $w
    $script:weatherHeight = $h
    $script:weatherTimer = New-Object Windows.Threading.DispatcherTimer
    $script:weatherTimer.Interval = [TimeSpan]::FromMilliseconds(40)
    $script:weatherTimer.Add_Tick({
        $dt = 0.04
        foreach ($p in $script:weatherItems) {
            if ($p.Kind -eq 'rain') {
                $p.Y += $p.Speed * $dt
                $p.X += $p.Drift * $dt
                if ($p.Y -gt $script:weatherHeight) {
                    $p.Y = -20
                    $p.X = Get-Random -Minimum 0 -Maximum ([int]$script:weatherWidth)
                }
                if ($p.X -gt $script:weatherWidth) { $p.X = 0 }
                $p.Element.X1 = $p.X
                $p.Element.Y1 = $p.Y
                $p.Element.X2 = $p.X + 2
                $p.Element.Y2 = $p.Y + $p.Len
            } else {
                $p.Y += $p.Speed * $dt
                $p.Phase += 0.03
                $p.X += [math]::Sin($p.Phase) * 0.7
                if ($p.Y -gt $script:weatherHeight) {
                    $p.Y = -10
                    $p.X = Get-Random -Minimum 0 -Maximum ([int]$script:weatherWidth)
                }
                if ($p.X -gt $script:weatherWidth) { $p.X = 0 }
                if ($p.X -lt 0) { $p.X = $script:weatherWidth }
                [Windows.Controls.Canvas]::SetLeft($p.Element, $p.X)
                [Windows.Controls.Canvas]::SetTop($p.Element, $p.Y)
            }
        }
    })
    $script:weatherTimer.Start()
}

function Apply-WeatherFromCode([int]$code) {
    if ($WeatherEffect -ne 'auto') { return }
    Start-WeatherEffect (Get-WeatherEffectKind $code)
}

$bg1    = Get-Hex $cfg.Bg1 '#16233A'
$bg2    = Get-Hex $cfg.Bg2 '#070B12'
$accent = Get-Hex $cfg.Accent '#FFFFFF'
$text   = Get-Hex $cfg.TextColor '#FFFFFF'

$size = Get-ClampedInt $cfg.FontSize 64 16 160

$scale = 1.0
try { $scale = [Windows.SystemParameters]::PrimaryScreenHeight / 1080.0 } catch { }
if ($scale -lt 0.75) { $scale = 0.75 }
if ($scale -gt 2.0) { $scale = 2.0 }

function S([double]$value) { return [int][math]::Round($value * $scale) }

$clockSize = S 30
$dateSize = S 16
$daySize = S 13
$weatherSize = S 15
$eventSize = S 14
$titleSize = S $size
$subSize = S 26
$infoSize = S 15
$newsSize = S 13
$hintSize = S 15
$loadingSize = S 16
$smallSize = S 13
$dividerWidth = S 140
$dividerHeight = [math]::Max(1, (S 2))
$dividerMargin = S 24
$titleMargin = S 24
$subMargin = S 10
$infoMargin = S 18
$centerMargin = S 60
$titleMax = S 1100
$subMax = S 900
$newsMargin = S 80
$newsBottom = S 88
$hintBottom = S 44
$newsMax = S 1200
$progressWidth = S 760
$progressHeight = S 6
$progressRadius = [int][math]::Max(2, ($progressHeight / 2))
$progressMargin = S 16
$netTitleSize = S 26
$netTextSize = S 15
$errorMax = S 620
$btnPadding = S 8
$updateMargin = S 32
$updatePadding = S 16
$updateRadius = [int](S 14)
$updateTitle = S 14
$updateSmall = S 12
$updateMax = S 360

$show = Get-ClampedInt $cfg.Seconds 8 2 300
$wait = Get-ClampedInt $cfg.WaitSeconds 10 0 60
if ($Seconds -gt 0) { $show = $Seconds; $wait = 0 }

$blur = Get-ClampedInt $cfg.BlurRadius 30 0 80
$tint = Get-ClampedInt $cfg.TintOpacity 35 15 100

$tintAlpha = ('{0:X2}' -f [int]($tint * 2.55))
$overlay1 = '#' + $tintAlpha + $bg1.Substring(1)
$overlay2 = '#' + $tintAlpha + $bg2.Substring(1)

$now = Get-Date
$fadeBg = 1.6
$fadeDecor = 2.6
$fadeTitle = 3.4
$fadeSub = 3.0
$fadeInfo = 2.4
$fadeNews = 2.0
$fadeHint = 1.6

$decorBegin = 0.6
$titleBegin = $decorBegin + 1.0
$subBegin = $titleBegin + 1.2
$infoBegin = $subBegin + 0.9
$newsBegin = $infoBegin + 0.7
$hintBegin = $newsBegin + 0.7
$showTotal = $hintBegin + $fadeHint

$title = [string]$cfg.Message
if ($cfg.TimeOfDay -eq $true) {
    $h = $now.Hour
    $part = 'Доброй ночи'
    if ($h -ge 5 -and $h -lt 12) { $part = 'Доброе утро' }
    elseif ($h -ge 12 -and $h -lt 18) { $part = 'Добрый день' }
    elseif ($h -ge 18 -and $h -lt 23) { $part = 'Добрый вечер' }
    $who = ([string]$cfg.Name).Trim()
    if ($who) { $title = "$part, $who" } else { $title = $part }
}

$ru = [Globalization.CultureInfo]::GetCultureInfo('ru-RU')

$clockVis = 'Collapsed'
if ($cfg.ShowClock -ne $false) { $clockVis = 'Visible' }

$dateVis = 'Collapsed'
if ($cfg.ShowDate -ne $false) { $dateVis = 'Visible' }
$dateText = ''
try { $dateText = $now.ToString("dddd, d MMMM yyyy 'года'", $ru) } catch { $dateText = $now.ToString('dddd, d MMMM yyyy') }

$dayVis = 'Collapsed'
if ($cfg.ShowDayInfo -ne $false) { $dayVis = 'Visible' }
$week = $now.DayOfYear
try {
    $week = $ru.Calendar.GetWeekOfYear($now, [Globalization.CalendarWeekRule]::FirstFourDayWeek, [DayOfWeek]::Monday)
} catch { }
$dayInfoText = "$week-я неделя · $($now.DayOfYear)-й день года"

$weatherVis = 'Collapsed'
$weatherText = ''

$eventText = ''
$eventName = ([string]$cfg.EventName).Trim()
if ($eventName -and ([string]$cfg.EventDate).Trim()) {
    try {
        $eventDate = [datetime]::Parse(([string]$cfg.EventDate).Trim(), $ru)
        $days = [int][math]::Ceiling(($eventDate.Date - $now.Date).TotalDays)
        if ($days -gt 1) { $eventText = "$eventName — через $days дн." }
        elseif ($days -eq 1) { $eventText = "$eventName — завтра" }
        elseif ($days -eq 0) { $eventText = "$eventName — сегодня" }
        elseif ($days -eq -1) { $eventText = "$eventName — был вчера" }
        elseif ($days -lt -1) { $eventText = "$eventName — прошёл $([math]::Abs($days)) дн. назад" }
    } catch { }
}
$eventVis = 'Collapsed'
if ($cfg.ShowEvent -ne $false -and $eventText) { $eventVis = 'Visible' }

$langText = ''
try {
    $layout = [System.Windows.Forms.InputLanguage]::CurrentInputLanguage
    $langText = $layout.Culture.TwoLetterISOLanguageName.ToUpper()
} catch { }

$volumeText = 'звук —'
try {
    $volume = [AudioInfo]::GetVolume()
    if ($volume -eq -1) { $volumeText = 'звук выкл' } elseif ($volume -ge 0) { $volumeText = "звук $volume%" }
} catch { }

$infoParts = @()
if ($langText) { $infoParts += $langText }
$infoParts += $volumeText
$infoText = $infoParts -join ' · '

$infoVis = 'Collapsed'
if ($cfg.ShowInfo -ne $false -and $infoText) { $infoVis = 'Visible' }

$newsVis = 'Collapsed'
if ($cfg.ShowNews -ne $false) { $newsVis = 'Visible' }

$networkName = ([string]$cfg.NetworkName).Trim()

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Приветствие" WindowStyle="None" ResizeMode="NoResize"
        WindowState="Maximized" ShowInTaskbar="False" Topmost="True" Background="Black">
    <Grid>
        <Grid x:Name="BgLayer" Opacity="0">
            <Rectangle>
                <Rectangle.Fill>
                    <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
                        <GradientStop Color="$bg1" Offset="0"/>
                        <GradientStop Color="$bg2" Offset="1"/>
                    </LinearGradientBrush>
                </Rectangle.Fill>
            </Rectangle>
            <Image x:Name="Backdrop" Stretch="UniformToFill" RenderOptions.BitmapScalingMode="HighQuality">
                <Image.Effect>
                    <BlurEffect Radius="$blur" KernelType="Gaussian" RenderingBias="Performance"/>
                </Image.Effect>
            </Image>
            <Image x:Name="UserPic" Stretch="UniformToFill" RenderOptions.BitmapScalingMode="HighQuality"
                   RenderTransformOrigin="0.5,0.5" Visibility="Collapsed">
                <Image.RenderTransform>
                    <ScaleTransform x:Name="UserPicScale" ScaleX="1" ScaleY="1"/>
                </Image.RenderTransform>
            </Image>
            <Rectangle>
                <Rectangle.Fill>
                    <LinearGradientBrush StartPoint="0,0" EndPoint="1,1">
                        <GradientStop Color="$overlay1" Offset="0"/>
                        <GradientStop Color="$overlay2" Offset="1"/>
                    </LinearGradientBrush>
                </Rectangle.Fill>
            </Rectangle>
        </Grid>
        <Canvas x:Name="WeatherLayer" IsHitTestVisible="False" ClipToBounds="True"/>
        <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center" Margin="$centerMargin,0">
            <StackPanel x:Name="Decor" Opacity="0" HorizontalAlignment="Center">
                <StackPanel.RenderTransform>
                    <TranslateTransform x:Name="DecorMove" Y="10"/>
                </StackPanel.RenderTransform>
                <TextBlock x:Name="Clock" Text="" HorizontalAlignment="Center" FontFamily="Segoe UI Light"
                           FontSize="$clockSize" Foreground="$accent" Visibility="$clockVis" Opacity="0.9"/>
                <TextBlock Text="$(Enc $dateText)" HorizontalAlignment="Center" FontFamily="Segoe UI"
                           FontSize="$dateSize" Foreground="$text" Opacity="0.6" Margin="0,2,0,0" Visibility="$dateVis"/>
                <TextBlock Text="$(Enc $dayInfoText)" HorizontalAlignment="Center" FontFamily="Segoe UI"
                           FontSize="$daySize" Foreground="$text" Opacity="0.45" Margin="0,2,0,0" Visibility="$dayVis"/>
                <TextBlock x:Name="WeatherLine" Text="$(Enc $weatherText)" HorizontalAlignment="Center" FontFamily="Segoe UI"
                           FontSize="$weatherSize" Foreground="$text" Opacity="0.75" Margin="0,4,0,0" Visibility="$weatherVis"/>
                <TextBlock Text="$(Enc $eventText)" HorizontalAlignment="Center" FontFamily="Segoe UI"
                           FontSize="$eventSize" Foreground="$text" Opacity="0.6" Margin="0,2,0,0" Visibility="$eventVis"/>
                <Rectangle Height="$dividerHeight" Width="$dividerWidth" Fill="$accent" HorizontalAlignment="Center" Margin="0,$dividerMargin,0,0" Opacity="0.8"/>
            </StackPanel>
            <TextBlock x:Name="Title" Text="$(Enc $title)" HorizontalAlignment="Center" TextAlignment="Center" TextWrapping="Wrap"
                       MaxWidth="$titleMax" FontFamily="Segoe UI Light" FontSize="$titleSize" Foreground="$text" Margin="0,$titleMargin,0,0" Opacity="0">
                <TextBlock.RenderTransform>
                    <TranslateTransform x:Name="TitleMove" Y="14"/>
                </TextBlock.RenderTransform>
            </TextBlock>
            <TextBlock x:Name="Sub" Text="$(Enc $cfg.SubMessage)" HorizontalAlignment="Center" TextAlignment="Center" TextWrapping="Wrap"
                       MaxWidth="$subMax" FontFamily="Segoe UI" FontSize="$subSize" Foreground="$text" Opacity="0" Margin="0,$subMargin,0,0">
                <TextBlock.RenderTransform>
                    <TranslateTransform x:Name="SubMove" Y="12"/>
                </TextBlock.RenderTransform>
            </TextBlock>
            <TextBlock x:Name="Info" Text="$(Enc $infoText)" HorizontalAlignment="Center" FontFamily="Segoe UI"
                       FontSize="$infoSize" Foreground="$text" Opacity="0" Margin="0,$infoMargin,0,0" Visibility="$infoVis"/>
        </StackPanel>
        <TextBlock x:Name="News" Text="" HorizontalAlignment="Center" VerticalAlignment="Bottom"
                   Margin="$newsMargin,0,$newsMargin,$newsBottom" FontFamily="Segoe UI" FontSize="$newsSize" Foreground="$text" Opacity="0"
                   TextAlignment="Center" TextWrapping="Wrap" MaxWidth="$newsMax" Visibility="$newsVis"/>
        <TextBlock x:Name="Hint" Text="Всё готово — клик или Esc" HorizontalAlignment="Center" VerticalAlignment="Bottom"
                   Margin="0,0,0,$hintBottom" FontFamily="Segoe UI" FontSize="$hintSize" Foreground="$text" Opacity="0"/>
        <StackPanel x:Name="LoadingPanel" VerticalAlignment="Center" HorizontalAlignment="Center">
            <TextBlock x:Name="Loading" Text="Подключение к сети…" HorizontalAlignment="Center"
                       FontFamily="Segoe UI" FontSize="$loadingSize" Foreground="#FFFFFF" Opacity="0.8"/>
            <ProgressBar x:Name="Progress" Width="$progressWidth" Height="$progressHeight" Margin="0,$progressMargin,0,0"
                         Minimum="0" Maximum="100" Value="0" Foreground="$accent" Background="#22FFFFFF" BorderThickness="0">
                <ProgressBar.Template>
                    <ControlTemplate TargetType="ProgressBar">
                        <Grid>
                            <Border x:Name="PART_Track" Background="{TemplateBinding Background}" CornerRadius="$progressRadius"/>
                            <Border x:Name="PART_Indicator" Background="{TemplateBinding Foreground}" CornerRadius="$progressRadius" HorizontalAlignment="Left"/>
                        </Grid>
                    </ControlTemplate>
                </ProgressBar.Template>
            </ProgressBar>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,$progressMargin,0,0">
                <TextBlock x:Name="PercentText" Text="0%" FontFamily="Segoe UI" FontSize="$smallSize" Foreground="#FFFFFF" Opacity="0.65"/>
                <TextBlock x:Name="TimeText" Text="0.0 с" FontFamily="Segoe UI" FontSize="$smallSize" Foreground="#FFFFFF" Opacity="0.4" Margin="$progressMargin,0,0,0"/>
            </StackPanel>
        </StackPanel>
        <StackPanel x:Name="NetError" Visibility="Collapsed" VerticalAlignment="Center" HorizontalAlignment="Center" MaxWidth="$errorMax">
            <TextBlock Text="Не удалось подключиться к сети" FontFamily="Segoe UI Light" FontSize="$netTitleSize"
                       Foreground="#FFFFFF" HorizontalAlignment="Center" TextAlignment="Center"/>
            <TextBlock Text="Новость может не появиться из-за отсутствия интернета. Проверьте Wi-Fi и попробуйте снова."
                       FontFamily="Segoe UI" FontSize="$netTextSize" Foreground="#FFFFFF" Opacity="0.6"
                       TextAlignment="Center" TextWrapping="Wrap" Margin="0,$netTextSize,0,0"/>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,$netTitleSize,0,0">
                <Button x:Name="BtnRetry" Content="Попробовать снова" Padding="$btnPadding,$btnPadding" FontSize="$netTextSize" Margin="0,0,$netTextSize,0"/>
                <Button x:Name="BtnContinue" Content="Продолжить" Padding="$btnPadding,$btnPadding" FontSize="$netTextSize"/>
            </StackPanel>
        </StackPanel>
        <Border x:Name="UpdatePanel" Visibility="Collapsed" HorizontalAlignment="Right" VerticalAlignment="Bottom"
                Margin="0,0,$updateMargin,$updateMargin" Padding="$updatePadding" CornerRadius="$updateRadius"
                Background="#F0121212" BorderBrush="#26FFFFFF" BorderThickness="1" MaxWidth="$updateMax">
            <StackPanel>
                <TextBlock Text="Доступно обновление" FontFamily="Segoe UI" FontSize="$updateTitle" Foreground="#FFFFFF" FontWeight="SemiBold"/>
                <TextBlock x:Name="UpdateText" Text="" FontFamily="Segoe UI" FontSize="$updateSmall" Foreground="#B3FFFFFF"
                           Margin="0,6,0,0" TextWrapping="Wrap"/>
                <StackPanel Orientation="Horizontal" Margin="0,$updatePadding,0,0">
                    <Button x:Name="BtnUpdate" Content="Обновить" Padding="12,6" Margin="0,0,8,0" BorderThickness="0"
                            Background="#FFFFFF" Foreground="#0B0B0B" FontSize="$updateSmall" Cursor="Hand"/>
                    <Button x:Name="BtnDownload" Content="Скачать архив" Padding="12,6" Margin="0,0,8,0" BorderThickness="0"
                            Background="#22FFFFFF" Foreground="#FFFFFF" FontSize="$updateSmall" Cursor="Hand"/>
                    <Button x:Name="BtnLater" Content="Позже" Padding="12,6" BorderThickness="0"
                            Background="Transparent" Foreground="#B3FFFFFF" FontSize="$updateSmall" Cursor="Hand"/>
                </StackPanel>
            </StackPanel>
        </Border>
    </Grid>
</Window>
"@

$window = [Windows.Markup.XamlReader]::Parse($xaml)

if ($SelfTest) { Write-Output 'OK'; return }

$script:backdrop = $window.FindName('Backdrop')
$script:loadingText = $window.FindName('Loading')
$script:loadingPanel = $window.FindName('LoadingPanel')
$script:newsText = $window.FindName('News')
$script:weatherLine = $window.FindName('WeatherLine')
$script:progress = $window.FindName('Progress')
$script:percentText = $window.FindName('PercentText')
$script:timeText = $window.FindName('TimeText')
$script:netError = $window.FindName('NetError')
$script:btnRetry = $window.FindName('BtnRetry')
$script:btnContinue = $window.FindName('BtnContinue')
$script:weatherLayer = $window.FindName('WeatherLayer')
$script:updatePanel = $window.FindName('UpdatePanel')
$script:updateText = $window.FindName('UpdateText')
$script:btnUpdate = $window.FindName('BtnUpdate')
$script:btnDownload = $window.FindName('BtnDownload')
$script:btnLater = $window.FindName('BtnLater')

$script:userPic = $window.FindName('UserPic')
$script:userPicScale = $window.FindName('UserPicScale')
$script:picDir = Join-Path (Split-Path -Parent $PSCommandPath) 'pics'
$picName = ([string]$cfg.PicFile).Trim()
if ($picName) {
    $picPath = Join-Path $script:picDir $picName
    if (-not (Test-Path -LiteralPath $picPath)) {
        if (Test-Path -LiteralPath $picName) { $picPath = $picName } else { $picPath = $null }
    }
    if ($picPath) {
        try {
            $userBmp = New-Object Windows.Media.Imaging.BitmapImage
            $userBmp.BeginInit()
            $userBmp.CacheOption = 'OnLoad'
            $userBmp.UriSource = New-Object Uri $picPath
            $userBmp.EndInit()
            $script:userPic.Source = $userBmp
            $picOp = [int]$cfg.PicOpacity
            if ($picOp -lt 10) { $picOp = 100 }
            $script:userPic.Opacity = [Math]::Max(10, [Math]::Min(100, $picOp)) / 100.0
            $picFit = $true
            if ($null -ne $cfg.PicFit) { $picFit = [bool]$cfg.PicFit }
            if ($picFit) {
                $script:userPic.Stretch = 'UniformToFill'
                $picZoom = [Math]::Max(100, [Math]::Min(300, [int]$cfg.PicZoom)) / 100.0
                $script:userPicScale.ScaleX = $picZoom
                $script:userPicScale.ScaleY = $picZoom
            } else {
                $script:userPic.Stretch = 'None'
                $script:userPicScale.ScaleX = 1
                $script:userPicScale.ScaleY = 1
            }
            $script:userPic.Visibility = 'Visible'
        } catch { }
    }
}

$script:screenBounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$script:fullBitmap = New-Object System.Drawing.Bitmap $script:screenBounds.Width, $script:screenBounds.Height
$script:fullGraphics = [System.Drawing.Graphics]::FromImage($script:fullBitmap)
$script:smallBitmap = New-Object System.Drawing.Bitmap ([int]($script:screenBounds.Width / 2)), ([int]($script:screenBounds.Height / 2))
$script:smallGraphics = [System.Drawing.Graphics]::FromImage($script:smallBitmap)
$script:smallGraphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
$script:frameStream = New-Object System.IO.MemoryStream

$script:grabScreen = {
    $b = $script:screenBounds
    $script:fullGraphics.CopyFromScreen($b.Left, $b.Top, 0, 0, $script:fullBitmap.Size)
    $script:smallGraphics.DrawImage($script:fullBitmap, 0, 0, $script:smallBitmap.Width, $script:smallBitmap.Height)
    $script:frameStream.SetLength(0)
    $script:smallBitmap.Save($script:frameStream, [System.Drawing.Imaging.ImageFormat]::Bmp)
    $script:frameStream.Position = 0
    $image = New-Object Windows.Media.Imaging.BitmapImage
    $image.BeginInit()
    $image.CacheOption = 'OnLoad'
    $image.StreamSource = $script:frameStream
    $image.EndInit()
    $image.Freeze()
    $script:backdrop.Source = $image
}

$script:frameTimer = New-Object Windows.Threading.DispatcherTimer
$script:frameTimer.Interval = [TimeSpan]::FromMilliseconds(160)
$script:frameTimer.Add_Tick({ try { & $script:grabScreen } catch { } })

$script:canClose = $false
$script:canCapture = $false
$script:closing = $false
$script:showing = $false
$script:netName = $networkName
$script:netStage = 0
$script:netDeadline = $null
$script:lastConnectTry = $null
$script:connectedAt = $null
$script:startTime = Get-Date

function Get-WifiSsid {
    try {
        $output = & netsh wlan show interfaces 2>$null
        foreach ($line in ($output -split "`r?`n")) {
            if ($line -match '^\s*SSID\s*:\s*(.+)$') { return $Matches[1].Trim() }
        }
    } catch { }
    return ''
}

function Connect-Wifi([string]$name) {
    try { & netsh wlan connect "name=$name" | Out-Null } catch { }
}

$script:showStoryboard = New-Object Windows.Media.Animation.Storyboard
function Add-ShowAnimation($element, [string]$property, [double]$from, [double]$to, [double]$begin, [double]$duration) {
    if ($null -eq $element) { return }
    $animation = New-Object Windows.Media.Animation.DoubleAnimation
    $animation.From = $from
    $animation.To = $to
    $animation.BeginTime = [TimeSpan]::FromSeconds($begin)
    $animation.Duration = [TimeSpan]::FromSeconds($duration)
    [Windows.Media.Animation.Storyboard]::SetTarget($animation, $element)
    [Windows.Media.Animation.Storyboard]::SetTargetProperty($animation, [Windows.PropertyPath]::new($property))
    $script:showStoryboard.Children.Add($animation) | Out-Null
}

Add-ShowAnimation ($window.FindName('BgLayer')) 'Opacity' 0 1 0 $fadeBg
Add-ShowAnimation ($window.FindName('Decor')) 'Opacity' 0 1 $decorBegin $fadeDecor
Add-ShowAnimation ($window.FindName('DecorMove')) 'Y' 10 0 $decorBegin $fadeDecor
Add-ShowAnimation ($window.FindName('Title')) 'Opacity' 0 1 $titleBegin $fadeTitle
Add-ShowAnimation ($window.FindName('TitleMove')) 'Y' 14 0 $titleBegin $fadeTitle
Add-ShowAnimation ($window.FindName('Sub')) 'Opacity' 0 1 $subBegin $fadeSub
Add-ShowAnimation ($window.FindName('SubMove')) 'Y' 12 0 $subBegin $fadeSub
Add-ShowAnimation ($window.FindName('Info')) 'Opacity' 0 1 $infoBegin $fadeInfo
Add-ShowAnimation ($window.FindName('News')) 'Opacity' 0 1 $newsBegin $fadeNews
Add-ShowAnimation ($window.FindName('Hint')) 'Opacity' 0 1 $hintBegin $fadeHint

$script:readyTimer = New-Object Windows.Threading.DispatcherTimer
$script:readyTimer.Add_Tick({
    $script:canClose = $true
    if ($script:canCapture) { $script:frameTimer.Start() }
    $script:readyTimer.Stop()
})

$script:autoTimer = New-Object Windows.Threading.DispatcherTimer
$script:autoTimer.Add_Tick({ Close-Fade })

$script:introPlayer = $null
$script:soundReady = $false
$script:soundPending = $false
$script:soundVolume = [Math]::Max(0, [Math]::Min(100, [int]$cfg.SoundVolume)) / 100
try {
    $soundPath = Join-Path $root ([string]$cfg.SoundFile)
    if (-not (Test-Path -LiteralPath $soundPath)) { $soundPath = Join-Path $root 'startup.wav' }
    if (-not (Test-Path -LiteralPath $soundPath)) { $soundPath = Join-Path $env:WINDIR 'Media\Windows Logon.wav' }
    if (Test-Path -LiteralPath $soundPath) {
        # Файл может быть MP3 под расширением .wav, поэтому играем через MediaPlayer
        $script:introPlayer = New-Object Windows.Media.MediaPlayer
        $script:introPlayer.Volume = $script:soundVolume
        $script:introPlayer.Add_MediaOpened({
            $script:soundReady = $true
            if ($script:soundPending) { try { $script:introPlayer.Play() } catch { } }
        })
        $script:introPlayer.Open([Uri]$soundPath)
    }
} catch { }

# Фоновая музыка: всегда тише звука приветствия и плавно появляется
$script:musicPlayer = $null
$script:musicTarget = 0
$script:musicVolume = [Math]::Max(0, [Math]::Min(100, [int]$cfg.MusicVolume)) / 100
$script:musicTarget = [Math]::Min($script:musicVolume, $script:soundVolume * 0.7)
try {
    $musicPath = Join-Path $root ([string]$cfg.MusicFile)
    if (-not (Test-Path -LiteralPath $musicPath)) { $musicPath = Join-Path $root 'music.mp3' }
    if (Test-Path -LiteralPath $musicPath) {
        $script:musicPlayer = New-Object Windows.Media.MediaPlayer
        $script:musicPlayer.Volume = 0
        $script:musicPlayer.Add_MediaEnded({
            try { $script:musicPlayer.Position = [TimeSpan]::Zero; $script:musicPlayer.Play() } catch { }
        })
        $script:musicPlayer.Open([Uri]$musicPath)
    }
} catch { }

$script:musicFadeTicks = 0
$script:musicFade = New-Object Windows.Threading.DispatcherTimer
$script:musicFade.Interval = [TimeSpan]::FromMilliseconds(50)
$script:musicFade.Add_Tick({
    $script:musicFadeTicks++
    $level = [Math]::Min(1.0, $script:musicFadeTicks / 50.0) * $script:musicTarget
    if ($script:musicPlayer) { try { $script:musicPlayer.Volume = $level } catch { } }
    if ($script:musicFadeTicks -ge 50) { $script:musicFade.Stop() }
})

function Start-Music {
    if (-not $script:musicPlayer) { return }
    if ($script:musicTarget -le 0) { return }
    $script:musicFadeTicks = 0
    try { $script:musicPlayer.Play() } catch { }
    $script:musicFade.Start()
}

function Stop-Music {
    try { $script:musicFade.Stop() } catch { }
    if ($script:musicPlayer) {
        try { $script:musicPlayer.Stop() } catch { }
        try { $script:musicPlayer.Close() } catch { }
    }
}

function Start-Show {
    if ($script:showing) { return }
    $script:showing = $true
    $script:statusTimer.Stop()
    $window.Cursor = [Windows.Input.Cursors]::Arrow
    $script:netError.Visibility = 'Collapsed'
    $script:loadingPanel.Visibility = 'Collapsed'
    if ($script:updateReady) { try { Show-UpdatePanel } catch { } }

    try { $script:showStoryboard.Begin() } catch { }

    if ($script:introPlayer) {
        if ($script:soundReady) { try { $script:introPlayer.Play() } catch { } }
        else { $script:soundPending = $true }
    }
    Start-Music

    $script:readyTimer.Interval = [TimeSpan]::FromSeconds($showTotal)
    $script:readyTimer.Start()
    $script:autoTimer.Interval = [TimeSpan]::FromSeconds($showTotal + $show)
    $script:autoTimer.Start()
}

function Show-NetError {
    $script:loadingPanel.Visibility = 'Collapsed'
    $script:netError.Visibility = 'Visible'
    $window.Cursor = [Windows.Input.Cursors]::Arrow
    $script:btnRetry.Focus() | Out-Null
}

$script:dataTimer = New-Object Windows.Threading.DispatcherTimer
$script:dataTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$script:dataTimer.Add_Tick({
    Complete-NewsRequest
    Complete-WeatherStep
    if ($script:newsDone -and ($script:weatherStage -eq 0 -or $script:weatherStage -eq 99)) { $script:dataTimer.Stop() }
})

$script:updateInfo = $null
$script:updateTask = $null
$script:updateBase = ''
$script:updateReady = $false
$script:updateNotified = $false
$script:updateNotify = $null

function Resolve-UpdateSource([string]$src) {
    if ($src -match '^https?://') {
        $uri = $src
        if ($uri -notmatch '\.json($|\?)') { $uri = $uri.TrimEnd('/') + '/updates.json' }
        $script:updateBase = $uri -replace '/[^/]+$', '/'
        return $uri
    }
    if (Test-Path -LiteralPath $src -PathType Leaf) {
        $script:updateBase = Split-Path -Parent $src
        return $src
    }
    $script:updateBase = $src
    return (Join-Path $src 'updates.json')
}

function Get-UpdateArchiveUrl {
    $u = [string]$script:updateInfo.url
    if (-not $u) { return '' }
    if ($u -match '^https?://') { return $u }
    if ($script:updateBase -match '^https?://') {
        return ([Uri]::new([Uri]$script:updateBase, $u)).AbsoluteUri
    }
    return (Join-Path $script:updateBase ($u -replace '/', '\'))
}

function Show-UpdatePanel {
    if (-not $script:updateInfo) { return }
    $text = 'Версия ' + $script:updateInfo.version
    if ($script:updateInfo.notes) { $text += ' — ' + $script:updateInfo.notes }
    $script:updateText.Text = $text
    $script:updatePanel.Visibility = 'Visible'
    if (-not $script:updateNotified) {
        $script:updateNotified = $true
        try {
            $script:updateNotify = New-Object Windows.Forms.NotifyIcon
            $script:updateNotify.Icon = [Drawing.SystemIcons]::Information
            $script:updateNotify.Visible = $true
            $script:updateNotify.BalloonTipTitle = 'Приветствие'
            $script:updateNotify.BalloonTipText = 'Доступно обновление ' + $script:updateInfo.version
            $script:updateNotify.ShowBalloonTip(8000)
        } catch { }
    }
}

function Complete-UpdateCheck {
    if (-not $script:updateInfo) { return }
    $remote = [string]$script:updateInfo.version
    if (-not $remote) { return }
    $newer = $false
    try { $newer = ([version]$remote -gt [version]$script:appVersion) } catch { $newer = $false }
    if (-not $newer) { return }
    $script:updateReady = $true
    if ($script:showing) { Show-UpdatePanel }
}

function Start-UpdateCheck {
    $src = ([string]$cfg.UpdateUrl).Trim()
    if (-not $src) { return }
    $uri = Resolve-UpdateSource $src
    if ($src -match '^https?://') {
        try {
            $wc = New-Object Net.WebClient
            $wc.Headers.Add('User-Agent', 'Welcome/' + $script:appVersion)
            $script:updateTask = $wc.DownloadStringTaskAsync([Uri]$uri)
            $script:updateTimer.Start()
        } catch { }
    } elseif (Test-Path -LiteralPath $uri) {
        try {
            $script:updateInfo = [IO.File]::ReadAllText($uri, [Text.Encoding]::UTF8) | ConvertFrom-Json
            Complete-UpdateCheck
        } catch { }
    }
}

function Save-UpdateArchive([string]$dest) {
    $u = Get-UpdateArchiveUrl
    if (-not $u) { throw 'в updates.json не указан url' }
    if ($u -match '^https?://') {
        $wc = New-Object Net.WebClient
        $wc.DownloadFile($u, $dest)
    } else {
        if (-not (Test-Path -LiteralPath $u)) { throw 'архив не найден: ' + $u }
        Copy-Item -LiteralPath $u -Destination $dest -Force
    }
    $expected = ([string]$script:updateInfo.sha256).Trim()
    if ($expected) {
        $actual = (Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash
        if ($actual -ne $expected.ToUpper()) { throw 'контрольная сумма не совпала' }
    }
}

function Install-Update {
    $tmp = Join-Path $env:TEMP ('welcome-update-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $tmp | Out-Null
    try {
        $zip = Join-Path $tmp 'update.zip'
        Save-UpdateArchive $zip
        $out = Join-Path $tmp 'out'
        Expand-Archive -LiteralPath $zip -DestinationPath $out -Force
        $files = Join-Path $out 'files'
        if (-not (Test-Path -LiteralPath $files)) { $files = $out }
        try { if ($script:introPlayer) { $script:introPlayer.Close() } } catch { }
        foreach ($item in @(Get-ChildItem -LiteralPath $files -File | Where-Object { $_.Name -ne 'settings.json' })) {
            $name = $item.Name
            for ($attempt = 0; $attempt -lt 5; $attempt++) {
                try {
                    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $root $name) -Force -ErrorAction Stop
                    break
                } catch {
                    Start-Sleep -Milliseconds 300
                }
            }
        }
        [IO.File]::WriteAllText($versionFile, [string]$script:updateInfo.version, (New-Object Text.UTF8Encoding($false)))
    } finally {
        Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
    try {
        Start-Process -FilePath 'powershell.exe' -ArgumentList @('-Sta', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + (Join-Path $root 'WhatsNew.ps1') + '"'))
    } catch { }
    Start-Process (Join-Path $env:WINDIR 'System32\wscript.exe') -ArgumentList ('"' + (Join-Path $root 'launch.vbs') + '" welcome')
    $window.Close()
}

$script:updateTimer = New-Object Windows.Threading.DispatcherTimer
$script:updateTimer.Interval = [TimeSpan]::FromMilliseconds(400)
$script:updateTimer.Add_Tick({
    if ($script:updateTask -and $script:updateTask.IsCompleted) {
        try { $script:updateInfo = $script:updateTask.Result | ConvertFrom-Json } catch { }
        $script:updateTask = $null
        $script:updateTimer.Stop()
        Complete-UpdateCheck
    }
})

$script:btnLater.Add_Click({ $script:updatePanel.Visibility = 'Collapsed' })

$script:btnDownload.Add_Click({
    try {
        $dir = Join-Path ([Environment]::GetFolderPath('UserProfile')) 'Downloads'
        if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
        $script:updateText.Text = 'Скачиваем архив…'
        $dest = Join-Path $dir ('Приветствие-' + $script:updateInfo.version + '.zip')
        Save-UpdateArchive $dest
        $script:updateText.Text = 'Архив сохранён: ' + $dest
    } catch {
        $script:updateText.Text = 'Не удалось скачать: ' + $_.Exception.Message
    }
})

$script:btnUpdate.Add_Click({
    try {
        $script:updateText.Text = 'Скачиваем и устанавливаем…'
        Install-Update
    } catch {
        $script:updateText.Text = 'Не удалось обновить: ' + $_.Exception.Message
    }
})

$script:statusTimer = New-Object Windows.Threading.DispatcherTimer
$script:statusTimer.Interval = [TimeSpan]::FromMilliseconds(200)
$script:statusTimer.Add_Tick({
    if ($script:showing) { $script:statusTimer.Stop(); return }

    $now = Get-Date
    $elapsed = ($now - $script:startTime).TotalSeconds
    $fraction = if ($wait -gt 0) { [math]::Min(1.0, $elapsed / $wait) } else { 1.0 }

    # Сеть подключаем параллельно, но загрузка длится ровно заданное время
    if ($script:netStage -eq 1) {
        $ssid = Get-WifiSsid
        if ($ssid -and $ssid -eq $script:netName) {
            $script:netStage = 2
            $script:connectedAt = $now
            if ($cfg.ShowNews -ne $false) { Start-NewsRequest }
            if ($cfg.ShowWeather -ne $false -or $cfg.WeatherEffect -ne $false) { Start-WeatherRequest }
            $script:dataTimer.Start()
        } elseif (-not $script:lastConnectTry -or ($now - $script:lastConnectTry).TotalSeconds -gt 8) {
            $script:lastConnectTry = $now
            Connect-Wifi $script:netName
        }
    }

    $percent = [int]([math]::Round($fraction * 100))
    if ($script:netStage -eq 1) {
        if ($fraction -lt 0.5) { $status = 'Подключение к сети…' }
        else { $status = 'Подключение к интернету занимает больше времени…' }
    } else {
        $status = 'Загрузка данных…'
        if ($fraction -ge 0.35) { $status = 'Загрузка обоев…' }
        if ($fraction -ge 0.7) { $status = 'Ищем новости…' }
        if ($fraction -ge 0.92) { $status = 'Готово' }
    }

    $script:progress.Value = $percent
    $script:percentText.Text = "$percent%"
    $script:timeText.Text = ('{0:0.0} с' -f [math]::Min($elapsed, [math]::Max(0, $wait)))
    $script:loadingText.Text = $status

    if ($fraction -ge 1) { Start-Show }
})

function Get-ScreenBrush {
    $b = $script:screenBounds
    $bitmap = New-Object System.Drawing.Bitmap $b.Width, $b.Height
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    $graphics.CopyFromScreen($b.Left, $b.Top, 0, 0, $bitmap.Size)
    $graphics.Dispose()
    $hbitmap = $bitmap.GetHbitmap()
    $source = [Windows.Interop.Imaging]::CreateBitmapSourceFromHBitmap(
        $hbitmap,
        [IntPtr]::Zero,
        [Windows.Int32Rect]::Empty,
        [Windows.Media.Imaging.BitmapSizeOptions]::FromEmptyOptions())
    $source.Freeze()
    [ScreenGuard]::Release($hbitmap)
    $bitmap.Dispose()
    $brush = New-Object Windows.Media.ImageBrush($source)
    $brush.Stretch = [Windows.Media.Stretch]::UniformToFill
    return $brush
}

$script:fadeOut = New-Object Windows.Media.Animation.Storyboard
foreach ($name in @('BgLayer', 'Decor', 'Title', 'Sub', 'Info', 'News', 'Hint')) {
    $element = $window.FindName($name)
    if ($null -eq $element) { continue }
    $animation = New-Object Windows.Media.Animation.DoubleAnimation
    $animation.From = 1.0
    $animation.To = 0.0
    $animation.Duration = [TimeSpan]::FromSeconds(3.0)
    [Windows.Media.Animation.Storyboard]::SetTarget($animation, $element)
    [Windows.Media.Animation.Storyboard]::SetTargetProperty($animation, [Windows.PropertyPath]::new('Opacity'))
    $script:fadeOut.Children.Add($animation) | Out-Null
}
$script:fadeOut.Add_Completed({ $window.Close() })

function Close-Fade {
    if ($script:closing) { return }
    $script:closing = $true
    Stop-Music
    try { $script:frameTimer.Stop() } catch { }
    # Под исчезающим блюром показываем снимок рабочего стола, чтобы не проступал чёрный фон окна
    try { $window.Background = Get-ScreenBrush } catch { }
    try { $script:fadeOut.Begin() } catch { $window.Close() }
}

$script:btnRetry.Add_Click({
    $script:netError.Visibility = 'Collapsed'
    $script:loadingPanel.Visibility = 'Visible'
    $script:netStage = 1
    $script:netDeadline = (Get-Date).AddSeconds(30)
    $script:lastConnectTry = $null
    $window.Cursor = [Windows.Input.Cursors]::None
    Connect-Wifi $script:netName
})

$script:btnContinue.Add_Click({ Start-Show })

$window.Add_Loaded({
    $excluded = $false
    try {
        $handle = (New-Object Windows.Interop.WindowInteropHelper($window)).Handle
        $excluded = [ScreenGuard]::Exclude($handle)
    } catch { }
    $script:canCapture = $excluded
    try { & $script:grabScreen } catch { }

    $script:startTime = Get-Date
    if ($script:netName) {
        $script:netStage = 1
        $script:netDeadline = $script:startTime.AddSeconds(30)
        $script:lastConnectTry = $script:startTime
        Connect-Wifi $script:netName
    } else {
        $script:netStage = 2
        $script:connectedAt = $script:startTime
        if ($cfg.ShowNews -ne $false) { Start-NewsRequest }
        if ($cfg.ShowWeather -ne $false -or $cfg.WeatherEffect -ne $false) { Start-WeatherRequest }
        $script:dataTimer.Start()
    }

    $script:statusTimer.Start()
    if ($WeatherEffect -ne 'auto') { try { Start-WeatherEffect $WeatherEffect } catch { } }
    try { Start-UpdateCheck } catch { }
})

$clock = $window.FindName('Clock')
if ($clock) {
    $clock.Text = (Get-Date).ToString('HH:mm')
    $clockTimer = New-Object Windows.Threading.DispatcherTimer
    $clockTimer.Interval = [TimeSpan]::FromSeconds(1)
    $clockTimer.Add_Tick({ $clock.Text = (Get-Date).ToString('HH:mm') })
    $clockTimer.Start()
}

# Клик закрывает только когда всё показано, Esc — всегда (аварийный выход)
$window.Add_MouseDown({ if ($script:canClose) { Close-Fade } })
$window.Add_KeyDown({ Close-Fade })
$window.Add_Closed({
    Stop-Music
    try { Stop-WeatherEffect } catch { }
    if ($script:updateNotify) {
        try { $script:updateNotify.Visible = $false; $script:updateNotify.Dispose() } catch { }
    }
})

$window.ShowDialog() | Out-Null
