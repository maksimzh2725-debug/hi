﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class UsageWin32 {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
}
"@

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$stateFile = Join-Path $root 'usage.json'

$created = $false
$mutex = New-Object Threading.Mutex($true, 'Local\UsageTrackerMutex', [ref]$created)
if (-not $created) { return }

$skip = @('powershell', 'pwsh', 'wscript', 'cscript', 'conhost', 'explorer', 'idle')

$date = (Get-Date).ToString('yyyy-MM-dd')
$usage = @{}
if (Test-Path -LiteralPath $stateFile) {
    try {
        $saved = [IO.File]::ReadAllText($stateFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        if ([string]$saved.date -eq $date -and $saved.apps) {
            foreach ($p in $saved.apps.PSObject.Properties) { $usage[$p.Name] = [double]$p.Value }
        }
    } catch { }
}

$procNames = @{}
$lastSave = Get-Date

function Save-Usage {
    try {
        $apps = [ordered]@{}
        foreach ($k in ($usage.Keys | Sort-Object)) { $apps[$k] = [Math]::Round([double]$usage[$k], 1) }
        $data = [pscustomobject]@{ date = $date; apps = $apps }
        $tmp = "$stateFile.tmp"
        [IO.File]::WriteAllText($tmp, ($data | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding($false)))
        Move-Item -LiteralPath $tmp -Destination $stateFile -Force
    } catch { }
}

$last = Get-Date
try {
    while ($true) {
        Start-Sleep -Milliseconds 1000
        $now = Get-Date
        $elapsed = ($now - $last).TotalSeconds
        $last = $now
        if ($elapsed -gt 5) { $elapsed = 5 }

        $today = $now.ToString('yyyy-MM-dd')
        if ($today -ne $date) {
            Save-Usage
            $date = $today
            $usage = @{}
        }

        try {
            $h = [UsageWin32]::GetForegroundWindow()
            if ($h -ne [IntPtr]::Zero) {
                [uint32]$procId = 0
                [void][UsageWin32]::GetWindowThreadProcessId($h, [ref]$procId)
                if ($procId -ne 0 -and $procId -ne $PID) {
                    $name = $null
                    if ($procNames.ContainsKey($procId)) {
                        $name = $procNames[$procId]
                    } else {
                        try { $name = (Get-Process -Id $procId -ErrorAction Stop).ProcessName } catch { $name = $null }
                        if ($name) { $procNames[$procId] = $name }
                    }
                    if ($name -and ($skip -notcontains $name.ToLower())) {
                        if ($usage.ContainsKey($name)) { $usage[$name] = [double]$usage[$name] + $elapsed }
                        else { $usage[$name] = $elapsed }
                    }
                }
            }
        } catch { }

        if (($now - $lastSave).TotalSeconds -ge 10) {
            Save-Usage
            $lastSave = $now
        }
    }
} finally {
    Save-Usage
}
