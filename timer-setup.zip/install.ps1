﻿param(
    [string]$TargetPath = (Join-Path $env:LOCALAPPDATA 'TimerApp')
)

$ErrorActionPreference = 'Stop'

$source = Join-Path $PSScriptRoot 'files'
if (-not (Test-Path -LiteralPath $source)) {
    Write-Host 'Не найдена папка files рядом с установщиком.' -ForegroundColor Red
    Read-Host 'Нажмите Enter'
    exit 1
}

$target = $TargetPath
New-Item -ItemType Directory -Path $target -Force | Out-Null

$hadSettings = Test-Path -LiteralPath (Join-Path $target 'settings.json')
foreach ($item in @(Get-ChildItem -LiteralPath $source -File)) {
    if ($hadSettings -and $item.Name -eq 'settings.json') { continue }
    Copy-Item -LiteralPath $item.FullName -Destination (Join-Path $target $item.Name) -Force
}

$soundSource = Join-Path $source 'sounds'
if (Test-Path -LiteralPath $soundSource) {
    $soundTarget = Join-Path $target 'sounds'
    New-Item -ItemType Directory -Path $soundTarget -Force | Out-Null
    Copy-Item -Path (Join-Path $soundSource '*') -Destination $soundTarget -Force
}

$wscript = Join-Path $env:WINDIR 'System32\wscript.exe'
$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')

$mainLink = $shell.CreateShortcut((Join-Path $desktop 'Таймер.lnk'))
$mainLink.TargetPath = $wscript
$mainLink.Arguments = '"' + (Join-Path $target 'Timer.vbs') + '"'
$mainLink.WorkingDirectory = $target
$mainLink.Description = 'Таймер, секундомер и напоминания'
$mainLink.Save()

$settingsLink = $shell.CreateShortcut((Join-Path $desktop 'Таймер (настройка).lnk'))
$settingsLink.TargetPath = $wscript
$settingsLink.Arguments = '"' + (Join-Path $target 'launch.vbs') + '"'
$settingsLink.WorkingDirectory = $target
$settingsLink.Description = 'Настройка таймера'
$settingsLink.Save()

$answer = Read-Host 'Запускать таймер при включении ПК, чтобы работали напоминания? (Д/н)'
if ($answer -notmatch '^[nнNН]') {
    $startupLink = $shell.CreateShortcut((Join-Path ([Environment]::GetFolderPath('Startup')) 'Таймер.lnk'))
    $startupLink.TargetPath = $wscript
    $startupLink.Arguments = '"' + (Join-Path $target 'Timer.vbs') + '"'
    $startupLink.WorkingDirectory = $target
    $startupLink.Description = 'Таймер и напоминания'
    $startupLink.Save()
}

Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + (Join-Path $target 'Timer.vbs') + '"')

$about = Join-Path $target 'WhatsNew.ps1'
if (Test-Path -LiteralPath $about) {
    Start-Process -FilePath 'powershell.exe' -ArgumentList @('-Sta', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ('"' + $about + '"'))
}

Write-Host ''
Write-Host "Готово. Программа установлена в: $target" -ForegroundColor Green
Write-Host 'На рабочем столе: «Таймер» и «Таймер (настройка)».'
Write-Host 'Напоминания срабатывают, пока таймер запущен (значок в трее).'
exit 0
