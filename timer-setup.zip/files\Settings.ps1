﻿param([switch]$SelfTest)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase

$script:root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:cfgFile = Join-Path $script:root 'settings.json'
$script:soundsDir = Join-Path $script:root 'sounds'
$script:picsDir = Join-Path $script:root 'pics'

$defaults = [ordered]@{
    Bg1       = '#1F1F1F'
    Bg2       = '#030303'
    Accent    = '#FFFFFF'
    TextColor = '#FFFFFF'
    FontSize  = 36
    Opacity   = 95
    Blur      = 30
    Topmost   = $true
    TickSound = 10
    EndSound  = 1
    TickFile  = ''
    EndFile   = ''
    StopMs    = $true
    StopFont  = 34
    TickVolume = 100
    EndVolume  = 33
    PicFile    = ''
    PicOpacity = 100
    PicZoom    = 100
    PicFit     = $true
}

$cfg = [ordered]@{}
foreach ($k in $defaults.Keys) { $cfg[$k] = $defaults[$k] }
if (Test-Path -LiteralPath $script:cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($script:cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in $defaults.Keys) { if ($null -ne $saved.$k) { $cfg[$k] = $saved.$k } }
    } catch { }
}

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Настройка таймера" Width="780" Height="980" MinWidth="700" MinHeight="480"
        WindowStartupLocation="CenterScreen" Background="#F5F7FA" FontFamily="Segoe UI">
    <Window.Resources>
        <Style TargetType="TextBox">
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="BorderBrush" Value="#C9D3E0"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="CheckBox">
            <Setter Property="Margin" Value="0,12,0,0"/>
            <Setter Property="FontSize" Value="14"/>
        </Style>
        <Style TargetType="Slider">
            <Setter Property="Margin" Value="0,6,0,0"/>
        </Style>
        <Style x:Key="Label" TargetType="TextBlock">
            <Setter Property="FontSize" Value="13"/>
            <Setter Property="Foreground" Value="#243447"/>
            <Setter Property="Margin" Value="0,12,0,4"/>
        </Style>
        <Style x:Key="Hint" TargetType="TextBlock">
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Foreground" Value="#6B7A8F"/>
            <Setter Property="Margin" Value="0,6,0,0"/>
            <Setter Property="TextWrapping" Value="Wrap"/>
        </Style>
        <Style x:Key="SectionTitle" TargetType="TextBlock">
            <Setter Property="FontSize" Value="17"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Foreground" Value="#1F2C3D"/>
            <Setter Property="VerticalAlignment" Value="Center"/>
        </Style>
    </Window.Resources>
    <ScrollViewer VerticalScrollBarVisibility="Auto" Padding="28,20,28,24">
        <StackPanel>
            <TextBlock Text="Настройка таймера" FontSize="24" FontWeight="Light" Foreground="#1F2C3D"/>
            <TextBlock Style="{StaticResource Hint}" Text="Сверху — как будет выглядеть окно. Настройки применяются кнопкой «Сохранить»."/>

            <Border Margin="0,16,0,0" BorderBrush="#D7DEE8" BorderThickness="1">
                <Grid x:Name="PrevRoot" Height="320" ClipToBounds="True">
                    <Rectangle x:Name="PrevBg"/>
                    <Image x:Name="PrevPic" Stretch="UniformToFill" RenderTransformOrigin="0.5,0.5" Opacity="0">
                        <Image.RenderTransform>
                            <ScaleTransform x:Name="PrevPicScale" ScaleX="1" ScaleY="1"/>
                        </Image.RenderTransform>
                    </Image>
                    <StackPanel VerticalAlignment="Center" HorizontalAlignment="Center">
                        <Canvas x:Name="PrevCanvas" Width="200" Height="200">
                            <Ellipse x:Name="PrevFace" Canvas.Left="8" Canvas.Top="8" Width="184" Height="184" StrokeThickness="1.5"/>
                            <Line x:Name="PrevHour" X1="100" Y1="100" X2="100" Y2="56" StrokeThickness="5" StrokeStartLineCap="Round" StrokeEndLineCap="Round">
                                <Line.RenderTransform>
                                    <RotateTransform x:Name="PrevHourRotate" CenterX="100" CenterY="100" Angle="2.5"/>
                                </Line.RenderTransform>
                            </Line>
                            <Line x:Name="PrevMinute" X1="100" Y1="100" X2="100" Y2="40" StrokeThickness="3" StrokeStartLineCap="Round" StrokeEndLineCap="Round">
                                <Line.RenderTransform>
                                    <RotateTransform x:Name="PrevMinuteRotate" CenterX="100" CenterY="100" Angle="30"/>
                                </Line.RenderTransform>
                            </Line>
                        </Canvas>
                        <TextBlock x:Name="PrevTime" Text="00:05:00" FontFamily="Consolas" FontSize="34" HorizontalAlignment="Center"/>
                        <TextBlock x:Name="PrevHint" Text="Старт · пауза · сброс" FontSize="11" HorizontalAlignment="Center" Margin="0,2,0,0"/>
                    </StackPanel>
                </Grid>
            </Border>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Цвета"/>
                <Button x:Name="BtnResetColors" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Фон 1"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalBg1" Width="430"/>
                <TextBox x:Name="TxtBg1" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldBrBg1" Minimum="10" Maximum="100" Width="300" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblBrBg1" Text="100%" Margin="10,6,0,0" FontSize="12"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Фон 2"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalBg2" Width="430"/>
                <TextBox x:Name="TxtBg2" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldBrBg2" Minimum="10" Maximum="100" Width="300" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblBrBg2" Text="100%" Margin="10,6,0,0" FontSize="12"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Цифры и стрелки"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalAccent" Width="430"/>
                <TextBox x:Name="TxtAccent" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldBrAccent" Minimum="10" Maximum="100" Width="300" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblBrAccent" Text="100%" Margin="10,6,0,0" FontSize="12"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Подписи"/>
            <StackPanel Orientation="Horizontal">
                <WrapPanel x:Name="PalText" Width="430"/>
                <TextBox x:Name="TxtText" Width="94" Margin="10,0,0,0" FontFamily="Consolas"/>
            </StackPanel>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldBrText" Minimum="10" Maximum="100" Width="300" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblBrText" Text="100%" Margin="10,6,0,0" FontSize="12"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Звуки"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Тик каждую секунду — свой файл"/>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtTick" Width="300" IsReadOnly="True"/>
                <Button x:Name="BtnPickTick" Content="Выбрать…" Padding="12,4" Margin="8,0,0,0"/>
                <Button x:Name="BtnClearTick" Content="Сброс" Padding="12,4" Margin="6,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Пусто — играет встроенный тик. Файл копируется в папку sounds, название сохраняется."/>

            <TextBlock Style="{StaticResource Label}" Text="Сигнал окончания — свой файл"/>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtEnd" Width="300" IsReadOnly="True"/>
                <Button x:Name="BtnPickEnd" Content="Выбрать…" Padding="12,4" Margin="8,0,0,0"/>
                <Button x:Name="BtnClearEnd" Content="Сброс" Padding="12,4" Margin="6,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Пусто — играет finish.mp3 или выбранный сигнал из встроенных."/>
            <TextBlock Style="{StaticResource Label}" Text="Встроенный тик каждую секунду"/>
            <StackPanel Orientation="Horizontal">
                <ComboBox x:Name="CmbTickSound" Width="220"/>
                <Button x:Name="BtnPrevTickSound" Content="Прослушать" Padding="10,3" Margin="10,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Встроенный сигнал окончания"/>
            <StackPanel Orientation="Horizontal">
                <ComboBox x:Name="CmbEndSound" Width="220"/>
                <Button x:Name="BtnPrevEndSound" Content="Прослушать" Padding="10,3" Margin="10,0,0,0"/>
            </StackPanel>

            <TextBlock Style="{StaticResource Label}" Text="Громкость тика"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldTickVol" Minimum="0" Maximum="100" Width="300" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="TxtTickVol" Margin="10,0,0,0" VerticalAlignment="Center" FontSize="13" Foreground="#243447"/>
                <Button x:Name="BtnPrevTick" Content="Прослушать" Padding="10,3" Margin="12,0,0,0"/>
            </StackPanel>

            <TextBlock Style="{StaticResource Label}" Text="Громкость сигнала окончания (100 % — максимум для сигнала)"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldEndVol" Minimum="0" Maximum="100" Width="300" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="TxtEndVol" Margin="10,0,0,0" VerticalAlignment="Center" FontSize="13" Foreground="#243447"/>
                <Button x:Name="BtnPrevEnd" Content="Прослушать" Padding="10,3" Margin="12,0,0,0"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Секундомер"/>
                <Button x:Name="BtnResetStop" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <CheckBox x:Name="ChkMs" Content="Показывать миллисекунды"/>
            <TextBlock Style="{StaticResource Label}" Text="Размер цифр секундомера"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldStopFont" Minimum="18" Maximum="60" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblStopFont" Text="34" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>

            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Вид"/>
                <Button x:Name="BtnResetView" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <TextBlock Style="{StaticResource Label}" Text="Размер цифр таймера"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldFont" Minimum="20" Maximum="60" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblFont" Text="36" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Прозрачность окна"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldOpacity" Minimum="50" Maximum="100" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblOpacity" Text="95 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Размытие фона"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldBlur" Minimum="0" Maximum="60" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblBlur" Text="30" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <Grid Margin="0,30,0,2">
                <TextBlock Style="{StaticResource SectionTitle}" Text="Картинка на фоне"/>
                <Button x:Name="BtnResetPic" Content="Сбросить" HorizontalAlignment="Right" Padding="10,3" FontSize="12"/>
            </Grid>
            <StackPanel Orientation="Horizontal">
                <TextBox x:Name="TxtPic" Width="300" IsReadOnly="True"/>
                <Button x:Name="BtnPickPic" Content="Выбрать…" Padding="12,4" Margin="8,0,0,0"/>
                <Button x:Name="BtnClearPic" Content="Убрать" Padding="12,4" Margin="6,0,0,0"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Hint}" Text="Файл копируется в папку pics рядом с программой. Картинка ложится на стеклянную карточку таймера."/>
            <TextBlock Style="{StaticResource Label}" Text="Прозрачность картинки"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldPicOpacity" Minimum="10" Maximum="100" Value="100" Width="400" TickFrequency="1" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblPicOpacity" Text="100 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <TextBlock Style="{StaticResource Label}" Text="Размер картинки"/>
            <StackPanel Orientation="Horizontal">
                <Slider x:Name="SldPicZoom" Minimum="100" Maximum="300" Width="400" TickFrequency="5" IsSnapToTickEnabled="True"/>
                <TextBlock x:Name="LblPicZoom" Text="100 %" Margin="12,0,0,0" VerticalAlignment="Center" FontSize="13"/>
            </StackPanel>
            <CheckBox x:Name="ChkPicFit" Content="Подгонять картинку под размер окна" IsChecked="True"/>
            <!--cut-->
            <CheckBox x:Name="ChkTopmost" Content="Поверх остальных окон"/>
            <TextBlock Style="{StaticResource Hint}" Text="Время задаётся прямо в окне таймера: часы, минуты и секунды."/>

            <StackPanel Orientation="Horizontal" Margin="0,30,0,0">
                <Button x:Name="BtnSave" Content="Сохранить" Background="#2563EB" Foreground="White"
                        BorderBrush="#2563EB" Padding="20,8" FontSize="14" FontWeight="SemiBold" Margin="0,0,8,0"/>
                <Button x:Name="BtnClose" Content="Закрыть" Padding="16,8" FontSize="14"/>
                <TextBlock x:Name="Status" Text="" Margin="14,0,0,0" VerticalAlignment="Center" FontSize="12" Foreground="#3B7A57"/>
            </StackPanel>
        </StackPanel>
    </ScrollViewer>
</Window>
"@

$window = [Windows.Markup.XamlReader]::Parse($xaml)
$names = @('PrevRoot','PrevBg','PrevPic','PrevPicScale','PrevCanvas','PrevFace','PrevHour','PrevMinute','PrevTime','PrevHint',
    'TxtBg1','TxtBg2','TxtAccent','TxtText','PalBg1','PalBg2','PalAccent','PalText','SldBrBg1','LblBrBg1','SldBrBg2','LblBrBg2','SldBrAccent','LblBrAccent','SldBrText','LblBrText',
    'SldFont','LblFont','SldOpacity','LblOpacity','SldBlur','LblBlur',
    'SldStopFont','LblStopFont','ChkMs','ChkTopmost',
    'TxtPic','BtnPickPic','BtnClearPic','SldPicOpacity','LblPicOpacity','SldPicZoom','LblPicZoom','BtnResetPic','ChkPicFit',
    'TxtTick','BtnPickTick','BtnClearTick','TxtEnd','BtnPickEnd','BtnClearEnd','CmbTickSound','CmbEndSound','BtnPrevTickSound','BtnPrevEndSound','SldTickVol','TxtTickVol','SldEndVol','TxtEndVol','BtnPrevTick','BtnPrevEnd',
    'BtnSave','BtnClose','Status','BtnResetColors','BtnResetView','BtnResetStop')
$ui = @{}
foreach ($n in $names) { $ui[$n] = $window.FindName($n) }

if ($SelfTest) {
    $missing = @($names | Where-Object { $null -eq $ui[$_] })
    if ($missing.Count -gt 0) { throw "Не найдены элементы: $($missing -join ', ')" }
    Write-Output 'OK'
    return
}

$script:palette = @('#1F1F1F', '#030303', '#16233A', '#070B12', '#FFFFFF', '#5BC0EB', '#F5C26B', '#E06C75', '#7BD88F', '#B58CFF')

$script:colorRoles = @(
    @{ Name = 'Bg1'; Box = $ui.TxtBg1; Sld = $ui.SldBrBg1; Lbl = $ui.LblBrBg1 },
    @{ Name = 'Bg2'; Box = $ui.TxtBg2; Sld = $ui.SldBrBg2; Lbl = $ui.LblBrBg2 },
    @{ Name = 'Accent'; Box = $ui.TxtAccent; Sld = $ui.SldBrAccent; Lbl = $ui.LblBrAccent },
    @{ Name = 'Text'; Box = $ui.TxtText; Sld = $ui.SldBrText; Lbl = $ui.LblBrText }
)
$script:colorBase = @{ Bg1 = '#1F1F1F'; Bg2 = '#030303'; Accent = '#FFFFFF'; Text = '#FFFFFF' }
$script:updatingColors = $false

function Get-BrightHex([string]$hex, [int]$percent) {
    if ($hex -notmatch '^#[0-9A-Fa-f]{6}$') { return $hex }
    $r = [Convert]::ToInt32($hex.Substring(1, 2), 16)
    $g = [Convert]::ToInt32($hex.Substring(3, 2), 16)
    $b = [Convert]::ToInt32($hex.Substring(5, 2), 16)
    $k = [Math]::Max(0, [Math]::Min(100, $percent)) / 100.0
    $r = [int][Math]::Round($r * $k); $g = [int][Math]::Round($g * $k); $b = [int][Math]::Round($b * $k)
    return ('#{0:X2}{1:X2}{2:X2}' -f $r, $g, $b)
}

foreach ($role in $script:colorRoles) {
    $role.Sld.Tag = $role.Name
    $role.Sld.Add_ValueChanged({
        param($sender, $eventArgs)
        if ($script:updatingColors) { return }
        $name = [string]$sender.Tag
        $item = $script:colorRoles | Where-Object { $_.Name -eq $name } | Select-Object -First 1
        if (-not $item) { return }
        $script:updatingColors = $true
        $item.Lbl.Text = [string][int]$sender.Value + '%'
        $item.Box.Text = Get-BrightHex $script:colorBase[$name] ([int]$sender.Value)
        $script:updatingColors = $false
        Update-Preview
    })
    $role.Box.Add_TextChanged({
        param($sender, $eventArgs)
        if ($script:updatingColors) { return }
        if ($sender.Text -match '^#[0-9A-Fa-f]{6}$') {
            $name = $null
            foreach ($r in $script:colorRoles) { if ($r.Box -eq $sender) { $name = $r.Name; break } }
            if ($name) {
                $script:colorBase[$name] = $sender.Text
                $script:updatingColors = $true
                $item = $script:colorRoles | Where-Object { $_.Name -eq $name } | Select-Object -First 1
                $item.Sld.Value = 100
                $item.Lbl.Text = '100%'
                $script:updatingColors = $false
            }
        }
    })
}
$script:boxMap = @{ PalBg1 = 'TxtBg1'; PalBg2 = 'TxtBg2'; PalAccent = 'TxtAccent'; PalText = 'TxtText' }

function Get-Color([string]$hex, [string]$fallback) {
    if ($hex -match '^#[0-9A-Fa-f]{6}$') { return $hex }
    return $fallback
}

function Add-Swatches([string]$panelName) {
    $panel = $ui[$panelName]
    foreach ($hex in $script:palette) {
        $dot = New-Object Windows.Controls.Border
        $dot.Width = 22
        $dot.Height = 22
        $dot.CornerRadius = [Windows.CornerRadius]::new(11)
        $dot.Margin = [Windows.Thickness]::new(0, 0, 6, 6)
        $dot.Background = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($hex))
        $dot.Cursor = [Windows.Input.Cursors]::Hand
        $dot.ToolTip = $hex
        $dot.Tag = $panelName + '|' + $hex
        $dot.Add_MouseLeftButtonDown({
            param($s, $e)
            $parts = ([string]$s.Tag).Split('|')
            $ui[$script:boxMap[$parts[0]]].Text = $parts[1]
        })
        $panel.Children.Add($dot) | Out-Null
    }
}

foreach ($panelName in @('PalBg1', 'PalBg2', 'PalAccent', 'PalText')) { Add-Swatches $panelName }

# деления и цифры на превью-циферблате
$center = 100
for ($i = 0; $i -lt 60; $i++) {
    $angle = $i * 6 * [Math]::PI / 180
    $major = ($i % 5 -eq 0)
    $outer = 88
    $inner = if ($major) { 78 } else { 82 }
    $line = New-Object Windows.Shapes.Line
    $line.X1 = $center + [Math]::Sin($angle) * $inner
    $line.Y1 = $center - [Math]::Cos($angle) * $inner
    $line.X2 = $center + [Math]::Sin($angle) * $outer
    $line.Y2 = $center - [Math]::Cos($angle) * $outer
    $line.StrokeThickness = if ($major) { 1.8 } else { 0.8 }
    $line.Tag = if ($major) { 'major' } else { 'minor' }
    $ui.PrevCanvas.Children.Add($line) | Out-Null
}
for ($n = 1; $n -le 12; $n++) {
    $angle = $n * 30 * [Math]::PI / 180
    $label = New-Object Windows.Controls.TextBlock
    $label.Text = [string]$n
    $label.FontSize = 10
    $label.Width = 24
    $label.TextAlignment = 'Center'
    [Windows.Controls.Canvas]::SetLeft($label, $center + [Math]::Sin($angle) * 66 - 12)
    [Windows.Controls.Canvas]::SetTop($label, $center - [Math]::Cos($angle) * 66 - 7)
    $label.Tag = 'num'
    $ui.PrevCanvas.Children.Add($label) | Out-Null
}

function Update-Preview {
    $bg1 = Get-Color $ui.TxtBg1.Text '#1F1F1F'
    $bg2 = Get-Color $ui.TxtBg2.Text '#030303'
    $accent = Get-Color $ui.TxtAccent.Text '#FFFFFF'
    $text = Get-Color $ui.TxtText.Text '#FFFFFF'

    $bg = New-Object Windows.Media.LinearGradientBrush
    $bg.StartPoint = New-Object Windows.Point 0, 0
    $bg.EndPoint = New-Object Windows.Point 1, 1
    $bg.GradientStops.Add((New-Object Windows.Media.GradientStop ([Windows.Media.ColorConverter]::ConvertFromString($bg1), 0)))
    $bg.GradientStops.Add((New-Object Windows.Media.GradientStop ([Windows.Media.ColorConverter]::ConvertFromString($bg2), 1)))
    $ui.PrevBg.Fill = $bg

    $accentBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
    $textBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($text))

    $ui.PrevFace.Stroke = $accentBrush
    $ui.PrevFace.Stroke = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
    $ui.PrevFace.Stroke.Opacity = 0.4
    $ui.PrevHour.Stroke = $accentBrush
    $ui.PrevMinute.Stroke = $textBrush
    $ui.PrevTime.Foreground = $accentBrush
    $ui.PrevTime.FontSize = [Math]::Max(18, [Math]::Min(40, [int]$ui.SldFont.Value))
    $ui.PrevHint.Foreground = $textBrush
    $ui.PrevHint.Opacity = 0.55

    foreach ($el in $ui.PrevCanvas.Children) {
        if ($el.Tag -eq 'major') { $el.Stroke = $textBrush; $el.Opacity = 0.85 }
        elseif ($el.Tag -eq 'minor') { $el.Stroke = $textBrush; $el.Opacity = 0.35 }
        elseif ($el.Tag -eq 'num') { $el.Foreground = $textBrush; $el.Opacity = 0.75 }
    }

    $ui.PrevRoot.Opacity = [double]$ui.SldOpacity.Value / 100.0
    $ui.LblFont.Text = [string][int]$ui.SldFont.Value
    $ui.LblOpacity.Text = [string][int]$ui.SldOpacity.Value + ' %'
    $ui.LblBlur.Text = [string][int]$ui.SldBlur.Value
    $ui.LblStopFont.Text = [string][int]$ui.SldStopFont.Value

    $picName = ([string]$ui.TxtPic.Text).Trim()
    if ($picName) {
        if ($script:prevPicName -ne $picName) {
            $script:prevPicName = $picName
            $picPath = Join-Path $script:picsDir $picName
            if (Test-Path -LiteralPath $picPath) {
                try {
                    $prevBmp = New-Object Windows.Media.Imaging.BitmapImage
                    $prevBmp.BeginInit()
                    $prevBmp.CacheOption = 'OnLoad'
                    $prevBmp.UriSource = New-Object Uri $picPath
                    $prevBmp.EndInit()
                    $ui.PrevPic.Source = $prevBmp
                } catch { $ui.PrevPic.Source = $null }
            } else {
                $ui.PrevPic.Source = $null
            }
        }
    } else {
        $script:prevPicName = ''
        $ui.PrevPic.Source = $null
    }
    $ui.PrevPic.Opacity = [double]$ui.SldPicOpacity.Value / 100.0
    if ($ui.ChkPicFit.IsChecked) {
        $ui.PrevPic.Stretch = 'UniformToFill'
        $picZoom = [double]$ui.SldPicZoom.Value / 100.0
        $ui.PrevPicScale.ScaleX = $picZoom
        $ui.PrevPicScale.ScaleY = $picZoom
    } else {
        $ui.PrevPic.Stretch = 'None'
        $ui.PrevPicScale.ScaleX = 1
        $ui.PrevPicScale.ScaleY = 1
    }
    $ui.LblPicOpacity.Text = [string][int]$ui.SldPicOpacity.Value + ' %'
    $ui.LblPicZoom.Text = [string][int]$ui.SldPicZoom.Value + ' %'
}

$ui.TxtBg1.Text = [string]$cfg.Bg1
$ui.TxtBg2.Text = [string]$cfg.Bg2
$ui.TxtAccent.Text = [string]$cfg.Accent
$ui.TxtText.Text = [string]$cfg.TextColor
$script:colorBase['Bg1'] = $ui.TxtBg1.Text
$script:colorBase['Bg2'] = $ui.TxtBg2.Text
$script:colorBase['Accent'] = $ui.TxtAccent.Text
$script:colorBase['Text'] = $ui.TxtText.Text
$script:updatingColors = $true
foreach ($role in $script:colorRoles) {
    $role.Sld.Value = 100
    $role.Lbl.Text = '100%'
}
$script:updatingColors = $false
$ui.SldFont.Value = [double]$cfg.FontSize
$ui.SldOpacity.Value = [double]$cfg.Opacity
$ui.SldBlur.Value = [double]$cfg.Blur
$ui.SldStopFont.Value = [double]$cfg.StopFont
$ui.SldTickVol.Value = [double]$cfg.TickVolume
$ui.SldEndVol.Value = [double]$cfg.EndVolume
$ui.TxtTickVol.Text = ('{0}%' -f [int]$ui.SldTickVol.Value)
$ui.TxtEndVol.Text = ('{0}%' -f [int]$ui.SldEndVol.Value)
$ui.SldTickVol.Add_ValueChanged({ $ui.TxtTickVol.Text = ('{0}%' -f [int]$ui.SldTickVol.Value) })
$ui.SldEndVol.Add_ValueChanged({ $ui.TxtEndVol.Text = ('{0}%' -f [int]$ui.SldEndVol.Value) })
$ui.ChkMs.IsChecked = [bool]$cfg.StopMs
$ui.ChkTopmost.IsChecked = [bool]$cfg.Topmost
$ui.TxtPic.Text = [string]$cfg.PicFile
$picOpCfg = [int]$cfg.PicOpacity
if ($picOpCfg -lt 10) { $picOpCfg = 100 }
$ui.SldPicOpacity.Value = [double]$picOpCfg
$ui.SldPicZoom.Value = [double]$cfg.PicZoom
$ui.ChkPicFit.IsChecked = [bool]$cfg.PicFit
for ($i = 1; $i -le 10; $i++) { [void]$ui.CmbTickSound.Items.Add('Звук ' + $i) }
for ($i = 1; $i -le 10; $i++) { [void]$ui.CmbEndSound.Items.Add('Сигнал ' + $i) }
$tickIdx = [int]$cfg.TickSound; if ($tickIdx -lt 1 -or $tickIdx -gt 10) { $tickIdx = 10 }
$endIdx = [int]$cfg.EndSound; if ($endIdx -lt 1 -or $endIdx -gt 10) { $endIdx = 1 }
$ui.CmbTickSound.SelectedIndex = $tickIdx - 1
$ui.CmbEndSound.SelectedIndex = $endIdx - 1
$ui.TxtTick.Text = [string]$cfg.TickFile
$ui.TxtEnd.Text = [string]$cfg.EndFile
Update-Preview

foreach ($box in @($ui.TxtBg1, $ui.TxtBg2, $ui.TxtAccent, $ui.TxtText)) { $box.Add_TextChanged({ Update-Preview }) }
foreach ($slider in @($ui.SldFont, $ui.SldOpacity, $ui.SldBlur, $ui.SldStopFont)) { $slider.Add_ValueChanged({ Update-Preview }) }

function Pick-AudioFile([string]$kind) {
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = if ($kind -eq 'tick') { 'Звук тика' } else { 'Звук окончания' }
    $dlg.Filter = 'Аудио (*.mp3;*.wav;*.ogg;*.m4a;*.wma)|*.mp3;*.wav;*.ogg;*.m4a;*.wma|Все файлы (*.*)|*.*'
    if ($dlg.ShowDialog() -ne $true) { return }
    $name = [IO.Path]::GetFileName($dlg.FileName)
    if (-not $name) { return }
    try {
        Copy-Item -LiteralPath $dlg.FileName -Destination (Join-Path $script:soundsDir $name) -Force
        if ($kind -eq 'tick') { $ui.TxtTick.Text = $name } else { $ui.TxtEnd.Text = $name }
        $ui.Status.Text = 'Файл скопирован в папку sounds: ' + $name
    } catch {
        $ui.Status.Text = 'Не удалось скопировать: ' + $_.Exception.Message
    }
}

$ui.BtnPickTick.Add_Click({ Pick-AudioFile 'tick' })
$ui.BtnPickEnd.Add_Click({ Pick-AudioFile 'end' })
$ui.BtnClearTick.Add_Click({ $ui.TxtTick.Text = '' })
$ui.BtnClearEnd.Add_Click({ $ui.TxtEnd.Text = '' })

$ui.BtnPickPic.Add_Click({
    $dlg = New-Object Microsoft.Win32.OpenFileDialog
    $dlg.Title = 'Картинка на фон'
    $dlg.Filter = 'Изображения (*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp)|*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.webp|Все файлы (*.*)|*.*'
    if ($dlg.ShowDialog() -ne $true) { return }
    $name = [IO.Path]::GetFileName($dlg.FileName)
    if (-not $name) { return }
    try {
        if (-not (Test-Path -LiteralPath $script:picsDir)) { [void](New-Item -ItemType Directory -Path $script:picsDir) }
        Copy-Item -LiteralPath $dlg.FileName -Destination (Join-Path $script:picsDir $name) -Force
        $ui.TxtPic.Text = $name
        if ([double]$ui.SldPicOpacity.Value -lt 10) { $ui.SldPicOpacity.Value = 100 }
        $ui.Status.Text = 'Картинка скопирована в папку pics: ' + $name
    } catch {
        $ui.Status.Text = 'Не удалось скопировать: ' + $_.Exception.Message
    }
})
$ui.BtnClearPic.Add_Click({
    $ui.TxtPic.Text = ''
    $ui.SldPicOpacity.Value = 100
    $ui.SldPicZoom.Value = 100
})
$ui.BtnResetPic.Add_Click({
    $ui.TxtPic.Text = ''
    $ui.SldPicOpacity.Value = 100
    $ui.SldPicZoom.Value = 100
})
$ui.SldPicOpacity.Add_ValueChanged({ Update-Preview })
$ui.SldPicZoom.Add_ValueChanged({ Update-Preview })
$ui.ChkPicFit.Add_Checked({ Update-Preview })
$ui.ChkPicFit.Add_Unchecked({ Update-Preview })
$ui.TxtPic.Add_TextChanged({ Update-Preview })

$ui.BtnResetColors.Add_Click({
    $ui.TxtBg1.Text = '#1F1F1F'
    $ui.TxtBg2.Text = '#030303'
    $ui.TxtAccent.Text = '#FFFFFF'
    $ui.TxtText.Text = '#FFFFFF'
})

$ui.BtnResetView.Add_Click({
    $ui.SldFont.Value = 36
    $ui.SldOpacity.Value = 95
    $ui.SldBlur.Value = 30
})

$ui.BtnResetStop.Add_Click({
    $ui.ChkMs.IsChecked = $true
    $ui.SldStopFont.Value = 34
})

function Save-Config {
    $data = [ordered]@{
        Bg1       = (Get-Color $ui.TxtBg1.Text '#1F1F1F')
        Bg2       = (Get-Color $ui.TxtBg2.Text '#030303')
        Accent    = (Get-Color $ui.TxtAccent.Text '#FFFFFF')
        TextColor = (Get-Color $ui.TxtText.Text '#FFFFFF')
        FontSize  = [int]$ui.SldFont.Value
        Opacity   = [int]$ui.SldOpacity.Value
        Blur      = [int]$ui.SldBlur.Value
        Topmost   = [bool]$ui.ChkTopmost.IsChecked
        TickSound = [int]$ui.CmbTickSound.SelectedIndex + 1
        EndSound  = [int]$ui.CmbEndSound.SelectedIndex + 1
        TickFile  = $ui.TxtTick.Text.Trim()
        EndFile   = $ui.TxtEnd.Text.Trim()
        StopMs    = [bool]$ui.ChkMs.IsChecked
        StopFont  = [int]$ui.SldStopFont.Value
        TickVolume = [int]$ui.SldTickVol.Value
        EndVolume  = [int]$ui.SldEndVol.Value
        PicFile    = $ui.TxtPic.Text.Trim()
        PicOpacity = [int]$ui.SldPicOpacity.Value
        PicZoom    = [int]$ui.SldPicZoom.Value
        PicFit     = [bool]$ui.ChkPicFit.IsChecked
    }
    [IO.File]::WriteAllText($script:cfgFile, ($data | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
}

$script:previewPlayers = @{}
function Play-Preview([string]$file, [double]$vol) {
    if (-not (Test-Path -LiteralPath $file)) { return }
    try {
        $player = New-Object Windows.Media.MediaPlayer
        $player.Open([Uri]$file)
        $player.Volume = [Math]::Max(0.0, [Math]::Min(1.0, $vol))
        $player.Play()
        $script:previewPlayers[$file] = $player
    } catch { }
}

$ui.BtnPrevTick.Add_Click({
    $vol = [double]$ui.SldTickVol.Value / 100.0
    $name = $ui.TxtTick.Text.Trim()
    $file = if ($name) { Join-Path $script:soundsDir $name } else { Join-Path $script:soundsDir 'tick10.mp3' }
    Play-Preview $file $vol
})
$ui.BtnPrevEnd.Add_Click({
    $vol = ([double]$ui.SldEndVol.Value / 100.0) * 0.2
    $name = $ui.TxtEnd.Text.Trim()
    $file = if ($name) { Join-Path $script:soundsDir $name } else { Join-Path $script:soundsDir 'finish.wav' }
    Play-Preview $file $vol
})

function Resolve-Sound([string]$prefix, [int]$index) {
    foreach ($ext in @('wav','mp3')) {
        $p = Join-Path $script:soundsDir ($prefix + $index + '.' + $ext)
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}
$ui.BtnPrevTickSound.Add_Click({
    $i = [int]$ui.CmbTickSound.SelectedIndex + 1
    $f = Resolve-Sound 'tick' $i
    if ($f) { Play-Preview $f ([double]$ui.SldTickVol.Value / 100.0) }
})
$ui.BtnPrevEndSound.Add_Click({
    $i = [int]$ui.CmbEndSound.SelectedIndex + 1
    $f = Resolve-Sound 'end' $i
    if ($f) { Play-Preview $f (([double]$ui.SldEndVol.Value / 100.0) * 0.2) }
})
$ui.BtnSave.Add_Click({
    Save-Config
    $ui.Status.Text = 'Сохранено'
})

# громкость применяется сразу, без отдельного сохранения
$script:volTimer = New-Object Windows.Threading.DispatcherTimer
$script:volTimer.Interval = [TimeSpan]::FromMilliseconds(300)
$script:volTimer.Add_Tick({
    $script:volTimer.Stop()
    Save-Config
    $ui.Status.Text = 'громкость применена'
})
foreach ($volSlider in @($ui.SldTickVol, $ui.SldEndVol)) {
    $volSlider.Add_ValueChanged({
        $script:volTimer.Stop()
        $script:volTimer.Start()
    })
}

$ui.BtnClose.Add_Click({ $window.Close() })

$window.ShowDialog() | Out-Null
