﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

$script:root = Split-Path -Parent $MyInvocation.MyCommand.Path
$script:cfgFile = Join-Path $script:root 'settings.json'

$script:cfg = [ordered]@{
    Bg1       = '#1F1F1F'
    Bg2       = '#030303'
    Accent    = '#FFFFFF'
    TextColor = '#FFFFFF'
    FontSize  = 36
    Opacity   = 95
    Topmost   = $true
    Blur      = 30
    TickSound = 10
    EndSound  = 1
    TickFile  = ''
    EndFile   = ''
    StopMs    = $true
    StopFont  = 34
    TickVolume = 100
    EndVolume  = 33
    PicFile    = ''
    PicOpacity = 100
    PicZoom    = 100
    PicFit     = $true
}
$script:volFile = $script:cfgFile
$script:volStamp = $null
if (Test-Path -LiteralPath $script:cfgFile) {
    try {
        $saved = [IO.File]::ReadAllText($script:cfgFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($k in @($script:cfg.Keys)) { if ($null -ne $saved.$k) { $script:cfg[$k] = $saved.$k } }
    } catch { }
}

function Get-Hex([string]$value, [string]$fallback) {
    if ($value -match '^#[0-9A-Fa-f]{6}$') { return $value }
    return $fallback
}

$bg1 = Get-Hex ([string]$script:cfg.Bg1) '#1F1F1F'
$bg2 = Get-Hex ([string]$script:cfg.Bg2) '#030303'
$accent = Get-Hex ([string]$script:cfg.Accent) '#FFFFFF'
$text = Get-Hex ([string]$script:cfg.TextColor) '#FFFFFF'
$fontSize = [Math]::Max(20, [Math]::Min(60, [int]$script:cfg.FontSize))
$blurRadius = [Math]::Max(0, [Math]::Min(60, [int]$script:cfg.Blur))

$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        ShowInTaskbar="False" SizeToContent="Height" Width="660" WindowStartupLocation="Manual"
        FontFamily="Segoe UI" ResizeMode="NoResize">
    <Window.Resources>
        <SolidColorBrush x:Key="FieldText" Color="#FFFFFF"/>
        <SolidColorBrush x:Key="FieldBg" Color="#20242A"/>
        <SolidColorBrush x:Key="FieldBorder" Color="#3A3F47"/>
        <Style x:Key="Field" TargetType="TextBox">
            <Setter Property="Foreground" Value="{DynamicResource FieldText}"/>
            <Setter Property="Background" Value="{DynamicResource FieldBg}"/>
            <Setter Property="BorderBrush" Value="{DynamicResource FieldBorder}"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="8,6"/>
            <Setter Property="CaretBrush" Value="{DynamicResource FieldText}"/>
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TextBox">
                        <Border x:Name="Bd" CornerRadius="10" Background="{TemplateBinding Background}"
                                BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}">
                            <Grid>
                                <ScrollViewer x:Name="PART_ContentHost" Margin="{TemplateBinding Padding}"
                                              VerticalScrollBarVisibility="{TemplateBinding VerticalScrollBarVisibility}"
                                              HorizontalScrollBarVisibility="{TemplateBinding HorizontalScrollBarVisibility}"/>
                                <TextBlock x:Name="Hint" Text="{TemplateBinding Tag}" Margin="11,0"
                                           VerticalAlignment="Center" Opacity="0.3" IsHitTestVisible="False"
                                           Foreground="{TemplateBinding Foreground}" Visibility="Collapsed"/>
                            </Grid>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="Text" Value="">
                                <Setter TargetName="Hint" Property="Visibility" Value="Visible"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="Bd" Property="Opacity" Value="0.5"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>
    <Grid x:Name="RootGrid">
        <Canvas ClipToBounds="True">
            <Image x:Name="Back" Stretch="Fill">
                <Image.Effect>
                    <BlurEffect Radius="$blurRadius" KernelType="Gaussian" RenderingBias="Performance"/>
                </Image.Effect>
            </Image>
        </Canvas>
        <Border x:Name="Card" CornerRadius="18" BorderThickness="1" Padding="0">
            <Grid>
                <Canvas x:Name="PicCanvas" ClipToBounds="True">
                    <Border x:Name="PicHost" CornerRadius="17" ClipToBounds="True" Visibility="Collapsed" Width="0" Height="0">
                        <Image x:Name="Pic" Stretch="UniformToFill" RenderTransformOrigin="0.5,0.5">
                            <Image.RenderTransform>
                                <ScaleTransform x:Name="PicScale" ScaleX="1" ScaleY="1"/>
                            </Image.RenderTransform>
                        </Image>
                    </Border>
                </Canvas>
                <StackPanel Margin="20,14">
                <DockPanel>
                    <Button x:Name="BtnClose" Content="✕" FontSize="11" Width="22" Height="22" Padding="0"
                            BorderThickness="0" DockPanel.Dock="Right" VerticalAlignment="Top"/>
                    <TextBlock x:Name="Caption" Text="Таймер" FontSize="12" Opacity="0.6" VerticalAlignment="Center"/>
                </DockPanel>

                <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,8,0,0">
                    <Button x:Name="BtnTabTimer" Content="Таймер" Padding="12,4" BorderThickness="0" FontSize="11"/>
                    <Button x:Name="BtnTabStop" Content="Секундомер" Padding="12,4" BorderThickness="0" FontSize="11" Margin="6,0,0,0"/>
                    <Button x:Name="BtnTabRem" Content="Напоминания" Padding="12,4" BorderThickness="0" FontSize="11" Margin="6,0,0,0"/>
                    <Button x:Name="BtnTabApps" Content="Приложения" Padding="12,4" BorderThickness="0" FontSize="11" Margin="6,0,0,0"/>
                </StackPanel>

                <Grid x:Name="PanelTimer" Margin="0,10,0,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="240"/>
                        <ColumnDefinition Width="24"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <Canvas x:Name="ClockFace" Width="240" Height="240" VerticalAlignment="Center">
                        <Ellipse x:Name="OuterRing" Canvas.Left="2" Canvas.Top="2" Width="236" Height="236" StrokeThickness="1"/>
                        <Ellipse x:Name="Face" Canvas.Left="10" Canvas.Top="10" Width="220" Height="220"
                                 StrokeThickness="1.5" Fill="Transparent"/>
                        <Ellipse x:Name="DialFill" Canvas.Left="12" Canvas.Top="12" Width="216" Height="216"/>
                        <Ellipse x:Name="InnerRing" Canvas.Left="48" Canvas.Top="48" Width="144" Height="144" StrokeThickness="1" Fill="Transparent"/>
                        <Path x:Name="ProgressArc" StrokeThickness="3" StrokeStartLineCap="Round" StrokeEndLineCap="Round"/>
                        <Line x:Name="HourHand" X1="120" Y1="120" X2="120" Y2="58" StrokeThickness="6" StrokeStartLineCap="Round" StrokeEndLineCap="Round">
                            <Line.RenderTransform>
                                <RotateTransform x:Name="HourRotate" CenterX="120" CenterY="120" Angle="0"/>
                            </Line.RenderTransform>
                        </Line>
                        <Line x:Name="MinuteHand" X1="120" Y1="120" X2="120" Y2="38" StrokeThickness="4" StrokeStartLineCap="Round" StrokeEndLineCap="Round">
                            <Line.RenderTransform>
                                <RotateTransform x:Name="MinuteRotate" CenterX="120" CenterY="120" Angle="0"/>
                            </Line.RenderTransform>
                        </Line>
                        <Line x:Name="SecondHand" X1="120" Y1="120" X2="120" Y2="28" StrokeThickness="1.5" StrokeStartLineCap="Round" StrokeEndLineCap="Round">
                            <Line.RenderTransform>
                                <RotateTransform x:Name="SecondRotate" CenterX="120" CenterY="120" Angle="0"/>
                            </Line.RenderTransform>
                        </Line>
                    </Canvas>
                    <StackPanel Grid.Column="2" VerticalAlignment="Center">
                        <TextBlock x:Name="Readout" Text="00:05:00" FontFamily="Consolas" FontSize="$fontSize" HorizontalAlignment="Left"/>
                        <TextBlock Text="часы : минуты : секунды" FontSize="10" Opacity="0.5" Margin="0,2,0,0"/>
                        <StackPanel Orientation="Horizontal" Margin="0,12,0,0">
                            <TextBox x:Name="TxtH" Width="52" MaxLength="2" Text="00" TextAlignment="Center" FontSize="16" Padding="4,5" Style="{StaticResource Field}" Tag="чч"/>
                            <TextBlock x:Name="Sep1" Text=":" FontSize="18" Margin="4,0" VerticalAlignment="Center"/>
                            <TextBox x:Name="TxtM" Width="52" MaxLength="2" Text="05" TextAlignment="Center" FontSize="16" Padding="4,5" Style="{StaticResource Field}" Tag="мм"/>
                            <TextBlock x:Name="Sep2" Text=":" FontSize="18" Margin="4,0" VerticalAlignment="Center"/>
                            <TextBox x:Name="TxtS" Width="52" MaxLength="2" Text="00" TextAlignment="Center" FontSize="16" Padding="4,5" Style="{StaticResource Field}" Tag="сс"/>
                        </StackPanel>
                        <StackPanel Orientation="Horizontal" Margin="0,14,0,0">
                            <Button x:Name="BtnStart" Content="Старт" Padding="18,7" BorderThickness="0" Margin="0,0,8,0"/>
                            <Button x:Name="BtnPause" Content="Пауза" Padding="18,7" BorderThickness="0" Margin="0,0,8,0"/>
                            <Button x:Name="BtnReset" Content="Сброс" Padding="18,7" BorderThickness="0"/>
                        </StackPanel>
                    </StackPanel>
                </Grid>

                <Grid x:Name="PanelStop" Visibility="Collapsed" Margin="0,10,0,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="20"/>
                        <ColumnDefinition Width="250"/>
                    </Grid.ColumnDefinitions>
                    <StackPanel Grid.Column="0" VerticalAlignment="Center">
                        <TextBlock x:Name="StopReadout" Text="00:00:00.000" FontFamily="Consolas" FontSize="34" HorizontalAlignment="Left"/>
                        <TextBlock Text="часы : минуты : секунды . миллисекунды" FontSize="10" Opacity="0.5" Margin="0,4,0,0"/>
                        <StackPanel Orientation="Horizontal" Margin="0,14,0,0">
                            <Button x:Name="BtnStopStart" Content="Старт" Padding="14,7" BorderThickness="0" Margin="0,0,6,0"/>
                            <Button x:Name="BtnStopPause" Content="Пауза" Padding="14,7" BorderThickness="0" Margin="0,0,6,0"/>
                            <Button x:Name="BtnStopLap" Content="Круг" Padding="14,7" BorderThickness="0" Margin="0,0,6,0"/>
                            <Button x:Name="BtnStopReset" Content="Сброс" Padding="14,7" BorderThickness="0"/>
                        </StackPanel>
                    </StackPanel>
                    <StackPanel Grid.Column="2">
                        <TextBlock Text="Круги" FontSize="10" Opacity="0.5"/>
                        <ListBox x:Name="StopLaps" Height="150" Margin="0,4,0,0" FontSize="11" FontFamily="Consolas"
                                 Background="#20242A" Foreground="#FFFFFF" BorderBrush="#3A3F47" BorderThickness="1"/>
                    </StackPanel>
                </Grid>

                <Grid x:Name="PanelRem" Visibility="Collapsed" Margin="0,10,0,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="20"/>
                        <ColumnDefinition Width="250"/>
                    </Grid.ColumnDefinitions>
                    <StackPanel Grid.Column="0">
                        <TextBlock Text="Заголовок" FontSize="10" Opacity="0.5" Foreground="#FFFFFF"/>
                        <TextBox x:Name="RemTitle" Margin="0,2,0,0" Style="{StaticResource Field}" Tag="Например: Чай"/>
                        <TextBlock Text="Текст" FontSize="10" Opacity="0.5" Margin="0,6,0,0" Foreground="#FFFFFF"/>
                        <TextBox x:Name="RemText" Margin="0,2,0,0" Height="52" Style="{StaticResource Field}" Tag="Текст напоминания"
                                 TextWrapping="Wrap" AcceptsReturn="True" VerticalScrollBarVisibility="Auto"/>
                        <Grid Margin="0,8,0,0">
                            <Grid.ColumnDefinitions>
                                <ColumnDefinition Width="*"/>
                                <ColumnDefinition Width="8"/>
                                <ColumnDefinition Width="96"/>
                            </Grid.ColumnDefinitions>
                            <StackPanel Grid.Column="0">
                                <TextBlock Text="Дата (пусто — сегодня)" FontSize="10" Opacity="0.5" Foreground="#FFFFFF"/>
                                <TextBox x:Name="RemDate" Margin="0,2,0,0" Style="{StaticResource Field}" Tag="дд.мм.гггг"/>
                            </StackPanel>
                            <StackPanel Grid.Column="2">
                                <TextBlock Text="Время чч:мм" FontSize="10" Opacity="0.5" Foreground="#FFFFFF"/>
                                <TextBox x:Name="RemTime" Margin="0,2,0,0" Style="{StaticResource Field}" Tag="18:30"/>
                            </StackPanel>
                        </Grid>
                        <Button x:Name="BtnRemAdd" Content="Добавить" Padding="16,6" BorderThickness="0"
                                Margin="0,10,0,0" HorizontalAlignment="Left"/>
                    </StackPanel>
                    <StackPanel Grid.Column="2">
                        <TextBlock Text="Мои напоминания" FontSize="10" Opacity="0.5"/>
                        <ListBox x:Name="RemList" Height="150" Margin="0,4,0,0" FontSize="11"
                                 Background="#20242A" Foreground="#FFFFFF" BorderBrush="#3A3F47" BorderThickness="1"/>
                        <Button x:Name="BtnRemDelete" Content="Удалить выбранное" Padding="12,5" BorderThickness="0"
                                FontSize="11" Margin="0,6,0,0" HorizontalAlignment="Left"/>
                    </StackPanel>
                </Grid>

                <StackPanel x:Name="PanelApps" Visibility="Collapsed" Margin="0,10,0,0">
                    <TextBlock x:Name="AppsCaption" Text="Сегодня" FontSize="11" Opacity="0.6" HorizontalAlignment="Left"/>
                    <ListBox x:Name="AppsList" Height="170" Margin="0,8,0,0" FontSize="11"
                             Background="#20242A" Foreground="#FFFFFF" BorderBrush="#3A3F47" BorderThickness="1"
                             ScrollViewer.HorizontalScrollBarVisibility="Disabled"/>
                    <TextBlock Text="Считается время активных окон, сбрасывается в полночь." FontSize="9"
                               Opacity="0.45" TextWrapping="Wrap" Margin="0,6,0,0" Foreground="#FFFFFF"/>
                </StackPanel>                </StackPanel>
            </Grid>
        </Border>
    </Grid>
</Window>
"@

$window = [Windows.Markup.XamlReader]::Parse($xaml)
$card = $window.FindName('Card')
$back = $window.FindName('Back')
$grid = $window.FindName('RootGrid')
$clockCanvas = $window.FindName('ClockFace')
$face = $window.FindName('Face')
$hourHand = $window.FindName('HourHand')
$minuteHand = $window.FindName('MinuteHand')
$secondHand = $window.FindName('SecondHand')
$hourRotate = $window.FindName('HourRotate')
$minuteRotate = $window.FindName('MinuteRotate')
$secondRotate = $window.FindName('SecondRotate')
$caption = $window.FindName('Caption')
$readout = $window.FindName('Readout')
$txtH = $window.FindName('TxtH')
$txtM = $window.FindName('TxtM')
$txtS = $window.FindName('TxtS')
$sep1 = $window.FindName('Sep1')
$sep2 = $window.FindName('Sep2')
$btnStart = $window.FindName('BtnStart')
$btnPause = $window.FindName('BtnPause')
$btnReset = $window.FindName('BtnReset')
$btnClose = $window.FindName('BtnClose')
$panelTimer = $window.FindName('PanelTimer')
$panelStop = $window.FindName('PanelStop')
$btnTabTimer = $window.FindName('BtnTabTimer')
$btnTabStop = $window.FindName('BtnTabStop')
$stopReadout = $window.FindName('StopReadout')
$btnStopStart = $window.FindName('BtnStopStart')
$btnStopPause = $window.FindName('BtnStopPause')
$btnStopReset = $window.FindName('BtnStopReset')
$btnStopLap = $window.FindName('BtnStopLap')
$stopLaps = $window.FindName('StopLaps')
$panelRem = $window.FindName('PanelRem')
$panelApps = $window.FindName('PanelApps')
$btnTabRem = $window.FindName('BtnTabRem')
$btnTabApps = $window.FindName('BtnTabApps')
$remTitle = $window.FindName('RemTitle')
$remText = $window.FindName('RemText')
$remDate = $window.FindName('RemDate')
$remTime = $window.FindName('RemTime')
$btnRemAdd = $window.FindName('BtnRemAdd')
$remList = $window.FindName('RemList')
$btnRemDelete = $window.FindName('BtnRemDelete')
$appsList = $window.FindName('AppsList')
$appsCaption = $window.FindName('AppsCaption')

$gradient = New-Object Windows.Media.LinearGradientBrush
$gradient.StartPoint = New-Object Windows.Point 0, 0
$gradient.EndPoint = New-Object Windows.Point 1, 1
$c1 = [Windows.Media.ColorConverter]::ConvertFromString($bg1)
$c2 = [Windows.Media.ColorConverter]::ConvertFromString($bg2)
$c1.A = 150
$c2.A = 185
$gradient.GradientStops.Add((New-Object Windows.Media.GradientStop ($c1, 0)))
$gradient.GradientStops.Add((New-Object Windows.Media.GradientStop ($c2, 1)))
$card.Background = $gradient
$card.BorderBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$card.BorderBrush.Opacity = 0.35

function Resolve-Pic([string]$name) {
    if (-not $name) { return $null }
    $local = Join-Path (Join-Path $script:root 'pics') $name
    if (Test-Path -LiteralPath $local) { return $local }
    if (Test-Path -LiteralPath $name) { return $name }
    return $null
}

$picHost = $window.FindName('PicHost')
$pic = $window.FindName('Pic')
$picScale = $window.FindName('PicScale')
function Apply-Pic {
    try {
        $picPath = Resolve-Pic ([string]$script:cfg.PicFile)
        if (-not $picPath) {
            $picHost.Visibility = 'Collapsed'
            $pic.Source = $null
            return
        }
        $bmp = New-Object Windows.Media.Imaging.BitmapImage
        $bmp.BeginInit()
        $bmp.CacheOption = 'OnLoad'
        $bmp.UriSource = New-Object Uri $picPath
        $bmp.EndInit()
        $pic.Source = $bmp
        $picOp = [int]$script:cfg.PicOpacity
        if ($picOp -lt 10) { $picOp = 100 }
        $picHost.Opacity = [Math]::Max(10, [Math]::Min(100, $picOp)) / 100.0
        $picFit = $true
        if ($null -ne $script:cfg.PicFit) { $picFit = [bool]$script:cfg.PicFit }
        if ($picFit) {
            $pic.Stretch = 'UniformToFill'
            $picZoom = [Math]::Max(100, [Math]::Min(300, [int]$script:cfg.PicZoom)) / 100.0
            $picScale.ScaleX = $picZoom
            $picScale.ScaleY = $picZoom
        } else {
            $pic.Stretch = 'None'
            $picScale.ScaleX = 1
            $picScale.ScaleY = 1
        }
        $picHost.Visibility = 'Visible'
    } catch { }
}
Apply-Pic
$syncPic = {
    try {
        $pw = [double]$card.ActualWidth - 2
        $ph = [double]$card.ActualHeight - 2
        if ($pw -lt 0) { $pw = 0 }
        if ($ph -lt 0) { $ph = 0 }
        $picHost.Width = $pw
        $picHost.Height = $ph
        [Windows.Controls.Canvas]::SetLeft($picHost, 1)
        [Windows.Controls.Canvas]::SetTop($picHost, 1)
    } catch { }
}
$card.Add_SizeChanged({ & $syncPic })
$window.Add_Loaded({ & $syncPic })

$accentBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$textBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($text))
$mutedBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($text))
$mutedBrush.Opacity = 0.5



$face.Stroke = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$face.Stroke.Opacity = 0.4
$outerRing = $window.FindName('OuterRing')
$dialFill = $window.FindName('DialFill')
$innerRing = $window.FindName('InnerRing')
$progressArc = $window.FindName('ProgressArc')
$outerRing.Stroke = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$outerRing.Stroke.Opacity = 0.18
$innerRing.Stroke = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($text))
$innerRing.Stroke.Opacity = 0.08
$progressArc.Stroke = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($accent))
$progressArc.Stroke.Opacity = 0.85

# лёгкий «стеклянный» градиент внутри циферблата
$dialBrush = New-Object Windows.Media.RadialGradientBrush
$dialBrush.Center = New-Object Windows.Point 0.5, 0.35
$dialBrush.GradientOrigin = New-Object Windows.Point 0.5, 0.35
$dialBrush.RadiusX = 0.6
$dialBrush.RadiusY = 0.6
$gStop1 = [Windows.Media.ColorConverter]::ConvertFromString($accent)
$gStop1.A = 26
$gStop2 = [Windows.Media.ColorConverter]::ConvertFromString($bg2)
$gStop2.A = 60
$dialBrush.GradientStops.Add((New-Object Windows.Media.GradientStop ($gStop1, 0)))
$dialBrush.GradientStops.Add((New-Object Windows.Media.GradientStop ($gStop2, 1)))
$dialFill.Fill = $dialBrush

# свечение стрелок
foreach ($hand in @($hourHand, $minuteHand)) {
    $glow = New-Object Windows.Media.Effects.DropShadowEffect
    $glow.Color = [Windows.Media.ColorConverter]::ConvertFromString($accent)
    $glow.BlurRadius = 8
    $glow.ShadowDepth = 0
    $glow.Opacity = 0.55
    $hand.Effect = $glow
}
$hourHand.Stroke = $accentBrush
$minuteHand.Stroke = $textBrush
$secondHand.Stroke = $mutedBrush
$caption.Foreground = $textBrush
$appsCaption.Foreground = $mutedBrush
$readout.Foreground = $accentBrush
$stopReadout.Foreground = $accentBrush
$stopReadout.FontSize = [Math]::Min(60, [Math]::Max(18, [int]$script:cfg.StopFont))
$sep1.Foreground = $textBrush
$sep2.Foreground = $textBrush

$fieldBorderBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#3A3F47'))
$fieldHoverBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#4C525C'))
$fieldBgBrush = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#20242A'))
$accentColorValue = [Windows.Media.ColorConverter]::ConvertFromString($accent)
foreach ($box in @($txtH, $txtM, $txtS, $remTitle, $remText, $remDate, $remTime)) {
    $box.Foreground = $textBrush
    $box.Background = $fieldBgBrush
    $box.BorderBrush = $fieldBorderBrush
    $box.CaretBrush = $accentBrush
    $box.Add_MouseEnter({ param($s, $e) if (-not $s.IsFocused) { $s.BorderBrush = $fieldHoverBrush } })
    $box.Add_MouseLeave({ param($s, $e) if (-not $s.IsFocused) { $s.BorderBrush = $fieldBorderBrush } })
    $box.Add_GotFocus({
        param($s, $e)
        $s.BorderBrush = $accentBrush
        $glow = New-Object Windows.Media.Effects.DropShadowEffect
        $glow.Color = $accentColorValue
        $glow.BlurRadius = 12
        $glow.ShadowDepth = 0
        $glow.Opacity = 0.45
        $s.Effect = $glow
    })
    $box.Add_LostFocus({
        param($s, $e)
        $s.BorderBrush = $fieldBorderBrush
        $s.Effect = $null
    })
}

$ar = [Convert]::ToInt32($accent.Substring(1, 2), 16)
$ag = [Convert]::ToInt32($accent.Substring(3, 2), 16)
$ab = [Convert]::ToInt32($accent.Substring(5, 2), 16)
$accentLight = (0.299 * $ar + 0.587 * $ag + 0.114 * $ab) -gt 150
$darkButton = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#2A2E34'))
foreach ($b in @($btnStart, $btnPause, $btnReset, $btnStopStart, $btnStopPause, $btnStopReset, $btnStopLap, $btnTabTimer, $btnTabStop, $btnTabRem, $btnTabApps, $btnRemAdd, $btnRemDelete)) {
    $b.Background = $darkButton
    $b.Foreground = $textBrush
}
foreach ($b in @($btnTabTimer, $btnTabStop, $btnTabRem, $btnTabApps, $btnRemDelete)) { $b.FontSize = 11 }
$btnStart.Background = $accentBrush
$btnStart.Foreground = if ($accentLight) { New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#111111')) } else { $textBrush }
$btnStopStart.Background = $accentBrush
$btnStopStart.Foreground = $btnStart.Foreground
$btnClose.Background = $darkButton
$btnClose.Foreground = $textBrush

$center = 120
for ($i = 0; $i -lt 60; $i++) {
    $angle = $i * 6 * [Math]::PI / 180
    $major = ($i % 5 -eq 0)
    $outer = 106
    $inner = if ($major) { 94 } else { 100 }
    $line = New-Object Windows.Shapes.Line
    $line.X1 = $center + [Math]::Sin($angle) * $inner
    $line.Y1 = $center - [Math]::Cos($angle) * $inner
    $line.X2 = $center + [Math]::Sin($angle) * $outer
    $line.Y2 = $center - [Math]::Cos($angle) * $outer
    $line.Stroke = $textBrush
    $line.StrokeThickness = if ($major) { 2.2 } else { 1 }
    $line.Opacity = if ($major) { 0.85 } else { 0.35 }
    $clockCanvas.Children.Add($line) | Out-Null
}
for ($n = 1; $n -le 12; $n++) {
    $angle = $n * 30 * [Math]::PI / 180
    $radius = 82
    $label = New-Object Windows.Controls.TextBlock
    $label.Text = [string]$n
    $label.FontSize = 12
    $label.FontWeight = 'SemiBold'
    $label.Width = 30
    $label.TextAlignment = 'Center'
    $label.Foreground = $textBrush
    $label.Opacity = 0.75
    [Windows.Controls.Canvas]::SetLeft($label, $center + [Math]::Sin($angle) * $radius - 15)
    [Windows.Controls.Canvas]::SetTop($label, $center - [Math]::Cos($angle) * $radius - 9)
    $clockCanvas.Children.Add($label) | Out-Null
}
for ($h = 0; $h -lt 12; $h++) {
    $angle = $h * 30 * [Math]::PI / 180
    $radius = 62
    $dot = New-Object Windows.Shapes.Ellipse
    $dot.Width = 3
    $dot.Height = 3
    $dot.Fill = $accentBrush
    $dot.Opacity = 0.35
    [Windows.Controls.Canvas]::SetLeft($dot, $center + [Math]::Sin($angle) * $radius - 1.5)
    [Windows.Controls.Canvas]::SetTop($dot, $center - [Math]::Cos($angle) * $radius - 1.5)
    $clockCanvas.Children.Add($dot) | Out-Null
}

$centerDot = New-Object Windows.Shapes.Ellipse
$centerDot.Width = 10
$centerDot.Height = 10
$centerDot.Fill = $accentBrush
[Windows.Controls.Canvas]::SetLeft($centerDot, $center - 5)
[Windows.Controls.Canvas]::SetTop($centerDot, $center - 5)
$clockCanvas.Children.Add($centerDot) | Out-Null

$window.Topmost = [bool]$script:cfg.Topmost
$window.Opacity = [double]$script:cfg.Opacity / 100.0

$script:players = @{}
function Resolve-SoundPath([string]$prefix, [int]$index) {
    $base = Join-Path $script:root ('sounds\' + $prefix + $index)
    foreach ($ext in @('.wav', '.mp3')) {
        $candidate = $base + $ext
        if (Test-Path -LiteralPath $candidate) { return $candidate }
    }
    return $null
}

function Play-AudioFile([string]$path, [double]$volume = 1.0) {
    if (-not (Test-Path -LiteralPath $path)) { return }
    try {
        if (-not $script:players.ContainsKey($path)) {
            $player = New-Object Windows.Media.MediaPlayer
            $player.Open([Uri]$path)
            $script:players[$path] = $player
        }
        $player = $script:players[$path]
        $player.Volume = $volume
        $player.Position = [TimeSpan]::Zero
        $player.Play()
    } catch { }
}

function Get-VolumeFactor([double]$percent) {
    $v = $percent / 100.0
    if ($v -lt 0.0) { return 0.0 }
    if ($v -gt 1.0) { return 1.0 }
    return $v
}

# сигнал окончания: 100 % на шкале = 20 % громкости плеера
function Get-EndVolumeFactor([double]$percent) {
    return (Get-VolumeFactor $percent) * 0.2
}

function Play-Tick {
    $vol = Get-VolumeFactor ([double]$script:cfg.TickVolume)
    if ([string]$script:cfg.TickFile) {
        $path = Join-Path $script:root ('sounds\' + [string]$script:cfg.TickFile)
        if (Test-Path -LiteralPath $path) {
            Play-AudioFile $path $vol
            return
        }
    }
    Play-Sound 'tick' ([int]$script:cfg.TickSound) $vol
}

function Play-Finish {
    $vol = Get-EndVolumeFactor ([double]$script:cfg.EndVolume)
    if ([string]$script:cfg.EndFile) {
        $path = Join-Path $script:root ('sounds\' + [string]$script:cfg.EndFile)
        if (Test-Path -LiteralPath $path) {
            Play-AudioFile $path $vol
            return $true
        }
    }
    $builtin = [int]$script:cfg.EndSound
    if ($builtin -gt 0) {
        $bp = Resolve-SoundPath 'end' $builtin
        if ($bp) {
            Play-AudioFile $bp $vol
            return $true
        }
    }
    $custom = Join-Path $script:root 'sounds\finish.wav'
    if (-not (Test-Path -LiteralPath $custom)) {
        $custom = Join-Path $script:root 'sounds\finish.mp3'
    }
    if (-not (Test-Path -LiteralPath $custom)) { return $false }
    try {
        if (-not $script:players.ContainsKey($custom)) {
            $player = New-Object Windows.Media.MediaPlayer
            $player.Open([Uri]$custom)
            $player.Volume = $vol
            $script:players[$custom] = $player
        }
        $player = $script:players[$custom]
        $player.Volume = $vol
        $player.Position = [TimeSpan]::Zero
        $player.Play()
        return $true
    } catch {
        return $false
    }
}

function Play-Sound([string]$prefix, [int]$index, [double]$volume = 1.0) {
    if ($index -le 0) { return }
    $path = Resolve-SoundPath $prefix $index
    if (-not $path) { return }
    try {
        if (-not $script:players.ContainsKey($path)) {
            $player = New-Object Windows.Media.MediaPlayer
            $player.Open([Uri]$path)
            $script:players[$path] = $player
        }
        $player = $script:players[$path]
        $player.Volume = $volume
        $player.Position = [TimeSpan]::Zero
        $player.Play()
    } catch { }
}

$script:totalSeconds = 300
$script:remaining = $script:totalSeconds
$script:target = $null
$script:running = $false
$script:updating = $false
$script:lastSecond = -1
$script:lastWatchSecond = -1

function Format-Hms([int]$seconds) {
    $h = [Math]::Floor($seconds / 3600)
    $m = [Math]::Floor($seconds / 60) % 60
    $s = $seconds % 60
    return ('{0:00}:{1:00}:{2:00}' -f $h, $m, $s)
}

function Read-Time {
    $h = 0; $m = 0; $s = 0
    [void][int]::TryParse($txtH.Text.Trim(), [ref]$h)
    [void][int]::TryParse($txtM.Text.Trim(), [ref]$m)
    [void][int]::TryParse($txtS.Text.Trim(), [ref]$s)
    $h = [Math]::Max(0, [Math]::Min(23, $h))
    $m = [Math]::Max(0, [Math]::Min(59, $m))
    $s = [Math]::Max(0, [Math]::Min(59, $s))
    $total = $h * 3600 + $m * 60 + $s
    if ($total -le 0) { $total = 60 }
    return $total
}

function Set-TimeFields([int]$seconds) {
    $script:updating = $true
    $txtH.Text = ('{0:00}' -f [Math]::Floor($seconds / 3600))
    $txtM.Text = ('{0:00}' -f ([Math]::Floor($seconds / 60) % 60))
    $txtS.Text = ('{0:00}' -f ($seconds % 60))
    $script:updating = $false
}

function Update-Hands {
    $sec = [Math]::Max(0, [int]$script:remaining)
    $h = [Math]::Floor($sec / 3600) % 12
    $m = [Math]::Floor($sec / 60) % 60
    $s = $sec % 60
    $hourRotate.Angle = $h * 30 + $m * 0.5
    $minuteRotate.Angle = $m * 6 + $s * 0.1
    $secondRotate.Angle = $s * 6
    $readout.Text = Format-Hms $sec

    # дуга по краю показывает, сколько времени осталось
    $fraction = 0
    if ($script:totalSeconds -gt 0) { $fraction = [Math]::Max(0, [Math]::Min(1, $sec / $script:totalSeconds)) }
    $angle = 360 * $fraction
    if ($angle -le 0.5) {
        $progressArc.Visibility = 'Collapsed'
    } else {
        $progressArc.Visibility = 'Visible'
        $radius = 114
        $rad = $angle * [Math]::PI / 180
        $startPoint = New-Object Windows.Point 120, 6
        $endPoint = New-Object Windows.Point (120 + [Math]::Sin($rad) * $radius), (120 - [Math]::Cos($rad) * $radius)
        $figure = New-Object Windows.Media.PathFigure
        $figure.StartPoint = $startPoint
        $segment = New-Object Windows.Media.ArcSegment
        $segment.Point = $endPoint
        $segment.Size = New-Object Windows.Size $radius, $radius
        $segment.IsLargeArc = ($angle -gt 180)
        $segment.SweepDirection = [Windows.Media.SweepDirection]::Clockwise
        $figure.Segments.Add($segment)
        $geometry = New-Object Windows.Media.PathGeometry
        $geometry.Figures.Add($figure)
        $progressArc.Data = $geometry
    }
}

function Set-InputEnabled([bool]$enabled) {
    foreach ($box in @($txtH, $txtM, $txtS)) {
        $box.IsReadOnly = -not $enabled
        $box.Opacity = if ($enabled) { 1 } else { 0.7 }
    }
}

function Normalize-Field($box, [int]$max) {
    if ($script:updating) { return }
    $raw = $box.Text.Trim()
    if (-not $raw) { return }
    $value = 0
    [void][int]::TryParse($raw, [ref]$value)
    if ($value -gt $max -or $value -lt 0) {
        if ($value -gt $max) { $value = $max }
        if ($value -lt 0) { $value = 0 }
        $script:updating = $true
        $box.Text = '{0:00}' -f $value
        $box.CaretIndex = $box.Text.Length
        $script:updating = $false
    }
}

function Pad-Field($box, [int]$max) {
    if ($script:updating) { return }
    $value = 0
    [void][int]::TryParse($box.Text.Trim(), [ref]$value)
    if ($value -gt $max) { $value = $max }
    if ($value -lt 0) { $value = 0 }
    $script:updating = $true
    $box.Text = '{0:00}' -f $value
    $script:updating = $false
}

function Refresh-FromFields {
    if ($script:running) { return }
    $script:totalSeconds = Read-Time
    $script:remaining = $script:totalSeconds
    $script:lastSecond = -1
    Update-Hands
}

$script:tick = New-Object Windows.Threading.DispatcherTimer
$script:tick.Interval = [TimeSpan]::FromMilliseconds(200)
$script:tick.Add_Tick({
    if (-not $script:running -or -not $script:target) { return }
    $left = [Math]::Ceiling(($script:target - (Get-Date)).TotalSeconds)
    $script:remaining = [Math]::Max(0, $left)
    $sec = [int]$script:remaining
    if ($sec -ne $script:lastSecond) {
        $script:lastSecond = $sec
        if ($sec -gt 0) { Play-Tick }
    }
    Update-Hands
    if ($script:remaining -le 0) {
        $script:running = $false
        $script:tick.Stop()
        Set-InputEnabled $true
        $caption.Text = 'Время вышло'
        if (-not (Play-Finish)) { Play-Sound 'end' ([int]$script:cfg.EndSound) (Get-EndVolumeFactor ([double]$script:cfg.EndVolume)) }
        try { $window.Show(); $window.Activate() | Out-Null } catch { }
    }
})

$btnStart.Add_Click({
    if ($script:running) { return }
    if ($script:remaining -le 0) {
        $script:totalSeconds = Read-Time
        $script:remaining = $script:totalSeconds
    }
    $script:target = (Get-Date).AddSeconds([double]$script:remaining)
    $script:running = $true
    $script:lastSecond = -1
    Set-InputEnabled $false
    $caption.Text = 'Идёт отсчёт'
    $script:tick.Start()
})

$btnPause.Add_Click({
    if (-not $script:running) { return }
    $script:remaining = [Math]::Max(0, [Math]::Ceiling(($script:target - (Get-Date)).TotalSeconds))
    $script:running = $false
    $script:tick.Stop()
    Set-InputEnabled $true
    Update-Hands
    $caption.Text = 'Пауза'
})

$btnReset.Add_Click({
    $script:running = $false
    $script:tick.Stop()
    $script:totalSeconds = Read-Time
    $script:remaining = $script:totalSeconds
    $script:lastSecond = -1
    Set-TimeFields $script:totalSeconds
    Set-InputEnabled $true
    Update-Hands
    $caption.Text = 'Таймер'
})

$txtH.Add_TextChanged({ Normalize-Field $txtH 23; Refresh-FromFields })
$txtM.Add_TextChanged({ Normalize-Field $txtM 59; Refresh-FromFields })
$txtS.Add_TextChanged({ Normalize-Field $txtS 59; Refresh-FromFields })
$txtH.Add_LostFocus({ Pad-Field $txtH 23 })
$txtM.Add_LostFocus({ Pad-Field $txtM 59 })
$txtS.Add_LostFocus({ Pad-Field $txtS 59 })

# Секундомер
function Get-StopText {
    if ([bool]$script:cfg.StopMs) { return $script:watch.Elapsed.ToString('hh\:mm\:ss\.fff') }
    return $script:watch.Elapsed.ToString('hh\:mm\:ss')
}

$script:watch = New-Object Diagnostics.Stopwatch
$script:watchTimer = New-Object Windows.Threading.DispatcherTimer
$script:watchTimer.Interval = [TimeSpan]::FromMilliseconds(47)
$script:watchTimer.Add_Tick({
    $stopReadout.Text = $script:watch.Elapsed.ToString('hh\:mm\:ss\.fff')
    if ($script:watch.IsRunning) {
        $sec = [int][Math]::Floor($script:watch.Elapsed.TotalSeconds)
        if ($sec -ne $script:lastWatchSecond) {
            $script:lastWatchSecond = $sec
            Play-Tick
        }
    }
})

function Set-Tab([string]$tab) {
    $panelTimer.Visibility = if ($tab -eq 'timer') { 'Visible' } else { 'Collapsed' }
    $panelStop.Visibility = if ($tab -eq 'stop') { 'Visible' } else { 'Collapsed' }
    $panelRem.Visibility = if ($tab -eq 'rem') { 'Visible' } else { 'Collapsed' }
    $panelApps.Visibility = if ($tab -eq 'apps') { 'Visible' } else { 'Collapsed' }

    $ink = if ($accentLight) { New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString('#111111')) } else { $textBrush }
    $map = [ordered]@{ timer = $btnTabTimer; stop = $btnTabStop; rem = $btnTabRem; apps = $btnTabApps }
    foreach ($k in $map.Keys) {
        $b = $map[$k]
        $b.Background = if ($k -eq $tab) { $accentBrush } else { $darkButton }
        $b.Foreground = if ($k -eq $tab) { $ink } else { $textBrush }
    }
    if ($tab -eq 'apps') { Refresh-Apps }
}

$btnTabTimer.Add_Click({ Set-Tab 'timer' })
$btnTabStop.Add_Click({ Set-Tab 'stop' })
$btnTabRem.Add_Click({ Set-Tab 'rem' })
$btnTabApps.Add_Click({ Set-Tab 'apps' })
$btnStopStart.Add_Click({ $script:watch.Start(); $script:lastWatchSecond = -1; $script:watchTimer.Start(); $caption.Text = 'Секундомер' })
$btnStopPause.Add_Click({ $script:watch.Stop(); $script:watchTimer.Stop(); $stopReadout.Text = $script:watch.Elapsed.ToString('hh\:mm\:ss\.fff') })
$btnStopReset.Add_Click({ $script:watch.Reset(); $script:watchTimer.Stop(); $script:lastWatchSecond = -1; $stopLaps.Items.Clear(); $stopReadout.Text = (Get-StopText) })
$script:lapCount = 0
$btnStopLap.Add_Click({
    if ($script:watch.Elapsed.TotalMilliseconds -le 0) { return }
    $script:lapCount++
    $text = ('Круг ' + $script:lapCount + ':  ' + (Get-StopText))
    $stopLaps.Items.Insert(0, $text) | Out-Null
    while ($stopLaps.Items.Count -gt 6) { $stopLaps.Items.RemoveAt($stopLaps.Items.Count - 1) }
})

# --- напоминания ---
$script:remFile = Join-Path $script:root 'reminders.json'
$script:reminders = @()

function Save-Reminders {
    try {
        $data = @($script:reminders | ForEach-Object {
            [pscustomobject]@{ id = $_.Id; title = $_.Title; text = $_.Text; due = $_.Due.ToString('o') }
        })
        [IO.File]::WriteAllText($script:remFile, (ConvertTo-Json -InputObject $data -Depth 3), (New-Object Text.UTF8Encoding($false)))
    } catch { }
}

function Load-Reminders {
    $script:reminders = @()
    if (-not (Test-Path -LiteralPath $script:remFile)) { return }
    try {
        $raw = [IO.File]::ReadAllText($script:remFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($r in @($raw)) {
            if (-not $r) { continue }
            $due = [datetime]::MinValue
            if (-not [datetime]::TryParse([string]$r.due, [ref]$due)) { continue }
            $script:reminders += @{ Id = [string]$r.id; Title = [string]$r.title; Text = [string]$r.text; Due = $due }
        }
    } catch { }
}

function Format-RemDue([datetime]$due) {
    $today = (Get-Date).Date
    if ($due.Date -eq $today) { return 'сегодня ' + $due.ToString('HH:mm') }
    if ($due.Date -eq $today.AddDays(1)) { return 'завтра ' + $due.ToString('HH:mm') }
    return $due.ToString('dd.MM.yyyy HH:mm')
}

function Refresh-RemList {
    $remList.Items.Clear()
    foreach ($r in @($script:reminders | Sort-Object { $_.Due })) {
        $line = '[' + (Format-RemDue $r.Due) + '] ' + $r.Title
        if ($r.Text) { $line += ' — ' + $r.Text }
        [void]$remList.Items.Add($line)
    }
}

function Add-Reminder {
    $title = $remTitle.Text.Trim()
    if (-not $title) { $title = 'Напоминание' }
    $body = $remText.Text.Trim()

    $time = [datetime]::MinValue
    $formats = [string[]]@('H:mm', 'HH:mm')
    if (-not [datetime]::TryParseExact($remTime.Text.Trim(), $formats, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::None, [ref]$time)) {
        $caption.Text = 'Укажите время, например 18:30'
        return
    }

    $now = Get-Date
    $datePart = $now.Date
    $dateText = $remDate.Text.Trim()
    if ($dateText) {
        $parsed = [datetime]::MinValue
        if (-not [datetime]::TryParse($dateText, [ref]$parsed)) {
            $caption.Text = 'Дата не распознана (дд.мм.гггг)'
            return
        }
        $datePart = $parsed.Date
    }

    $due = $datePart.Add($time.TimeOfDay)
    while ($due -le $now) { $due = $due.AddDays(1) }

    $script:reminders += @{ Id = [guid]::NewGuid().ToString(); Title = $title; Text = $body; Due = $due }
    Save-Reminders
    Refresh-RemList
    $remTitle.Text = ''
    $remText.Text = ''
    $remDate.Text = ''
    $remTime.Text = ''
    $caption.Text = 'Напоминание: ' + (Format-RemDue $due)
}

function Show-Reminder($r) {
    Play-AudioFile (Join-Path $script:root 'sounds\reminder.mp3')
    try {
        $tray.ShowBalloonTip(15000, [string]$r.Title, [string]$r.Text, [Windows.Forms.ToolTipIcon]::None)
    } catch { }
}

function Invoke-ReminderCheck {
    $now = Get-Date
    $due = @($script:reminders | Where-Object { $_.Due -le $now })
    if ($due.Count -eq 0) { return }
    foreach ($r in $due) { Show-Reminder $r }
    $ids = @($due | ForEach-Object { $_.Id })
    $script:reminders = @($script:reminders | Where-Object { $ids -notcontains $_.Id })
    Save-Reminders
    Refresh-RemList
}

$btnRemAdd.Add_Click({ Add-Reminder })
$btnRemDelete.Add_Click({
    $i = $remList.SelectedIndex
    if ($i -lt 0) { return }
    $sorted = @($script:reminders | Sort-Object { $_.Due })
    if ($i -ge $sorted.Count) { return }
    $id = $sorted[$i].Id
    $script:reminders = @($script:reminders | Where-Object { $_.Id -ne $id })
    Save-Reminders
    Refresh-RemList
    $caption.Text = 'Напоминание удалено'
})

# --- учёт времени в приложениях ---
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public static class TimerWin32 {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
}
"@

$script:usageFile = Join-Path $script:root 'usage.json'
$script:usageDate = (Get-Date).ToString('yyyy-MM-dd')
$script:usage = @{}
$script:usageStamp = $null
$script:procNames = @{}
$script:usageTicks = 0

function Save-Usage {
    try {
        $apps = [ordered]@{}
        foreach ($k in ($script:usage.Keys | Sort-Object)) { $apps[$k] = [int]$script:usage[$k] }
        $obj = [pscustomobject]@{ date = $script:usageDate; apps = $apps }
        [IO.File]::WriteAllText($script:usageFile, ($obj | ConvertTo-Json -Depth 3), (New-Object Text.UTF8Encoding($false)))
    } catch { }
}

function Load-Usage {
    $script:usage = @{}
    if (-not (Test-Path -LiteralPath $script:usageFile)) { return }
    try {
        $raw = [IO.File]::ReadAllText($script:usageFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        if ([string]$raw.date -ne $script:usageDate) { return }
        foreach ($p in $raw.apps.PSObject.Properties) { $script:usage[$p.Name] = [int]$p.Value }
    } catch { }
}

function Reload-Usage {
    try {
        if (-not (Test-Path -LiteralPath $script:usageFile)) { return }
        $stamp = (Get-Item -LiteralPath $script:usageFile).LastWriteTimeUtc
        if ($stamp -eq $script:usageStamp) { return }
        $script:usageStamp = $stamp
        $raw = [IO.File]::ReadAllText($script:usageFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
        $today = (Get-Date).ToString('yyyy-MM-dd')
        if ([string]$raw.date -ne $today) {
            $script:usage = @{}
            $script:usageDate = $today
            return
        }
        $fresh = @{}
        if ($raw.apps) {
            foreach ($pr in $raw.apps.PSObject.Properties) {
                $fresh[$pr.Name] = [int][Math]::Floor([double]$pr.Value)
            }
        }
        $script:usage = $fresh
        $script:usageDate = $today
    } catch { }
}

function Track-Foreground {
    try {
        $h = [TimerWin32]::GetForegroundWindow()
        if ($h -eq [IntPtr]::Zero) { return }
        [uint32]$procId = 0
        [void][TimerWin32]::GetWindowThreadProcessId($h, [ref]$procId)
        if ($procId -eq 0 -or $procId -eq $PID) { return }
        if ($script:procNames.ContainsKey($procId)) {
            $name = $script:procNames[$procId]
        } else {
            $name = (Get-Process -Id $procId -ErrorAction Stop).ProcessName
            $script:procNames[$procId] = $name
        }
        if (-not $name) { return }
        if ($script:usage.ContainsKey($name)) { $script:usage[$name] = [int]$script:usage[$name] + 1 }
        else { $script:usage[$name] = 1 }
    } catch { }
}

function Format-Usage([int]$sec) {
    $h = [Math]::Floor($sec / 3600)
    $m = [Math]::Floor($sec / 60) % 60
    $s = $sec % 60
    return ('{0} ч {1:00} мин {2:00} с' -f $h, $m, $s)
}

$script:icons = @{}
$script:defaultIcon = $null

function Convert-IconToImage($ico) {
    $bmp = $ico.ToBitmap()
    $ms = New-Object IO.MemoryStream
    try { $bmp.Save($ms, [Drawing.Imaging.ImageFormat]::Png) } finally { $bmp.Dispose() }
    $ms.Position = 0
    $image = New-Object Windows.Media.Imaging.BitmapImage
    $image.BeginInit()
    $image.StreamSource = $ms
    $image.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
    $image.EndInit()
    $image.Freeze()
    return $image
}

function Get-AppIcon([string]$name) {
    if ($script:icons.ContainsKey($name)) { return $script:icons[$name] }
    $image = $null
    try {
        $path = $null
        foreach ($pr in @(Get-Process -Name $name -ErrorAction Stop)) {
            try { if ($pr.Path) { $path = $pr.Path; break } } catch { }
        }
        if ($path -and (Test-Path -LiteralPath $path)) {
            $ico = [Drawing.Icon]::ExtractAssociatedIcon($path)
            if ($ico) { $image = Convert-IconToImage $ico }
        }
    } catch { }
    if (-not $image) {
        if (-not $script:defaultIcon) { $script:defaultIcon = Convert-IconToImage ([Drawing.SystemIcons]::Application) }
        $image = $script:defaultIcon
    }
    $script:icons[$name] = $image
    return $image
}

function Refresh-Apps {
    $items = @($script:usage.GetEnumerator() | Sort-Object Value -Descending | Select-Object -First 14)

    # если состав и порядок не менялись — только обновляем подписи, чтобы не сбрасывать прокрутку
    $same = ($appsList.Items.Count -eq $items.Count)
    if ($same) {
        for ($i = 0; $i -lt $items.Count; $i++) {
            $row = $appsList.Items[$i]
            if (-not ($row -is [Windows.Controls.StackPanel]) -or [string]$row.Tag -ne $items[$i].Key) {
                $same = $false
                break
            }
        }
    }
    if ($same) {
        for ($i = 0; $i -lt $items.Count; $i++) {
            $appsList.Items[$i].Children[1].Text = '{0}  {1}' -f $items[$i].Key, (Format-Usage ([int]$items[$i].Value))
        }
        $appsCaption.Text = 'Сегодня, ' + (Get-Date).ToString('dd.MM.yyyy')
        return
    }

    $appsList.Items.Clear()
    foreach ($e in $items) {
        $row = New-Object Windows.Controls.StackPanel
        $row.Orientation = 'Horizontal'
        $picture = New-Object Windows.Controls.Image
        $picture.Width = 16
        $picture.Height = 16
        $picture.Margin = New-Object Windows.Thickness 0, 0, 8, 0
        $picture.VerticalAlignment = 'Center'
        $picture.Source = Get-AppIcon $e.Key
        $textBlock = New-Object Windows.Controls.TextBlock
        $textBlock.Text = '{0}  {1}' -f $e.Key, (Format-Usage ([int]$e.Value))
        $textBlock.VerticalAlignment = 'Center'
        [void]$row.Children.Add($picture)
        [void]$row.Children.Add($textBlock)
        $row.Tag = $e.Key
        [void]$appsList.Items.Add($row)
    }
    $appsCaption.Text = 'Сегодня, ' + (Get-Date).ToString('dd.MM.yyyy')
}

function Reset-UsageIfNeeded {
    $today = (Get-Date).ToString('yyyy-MM-dd')
    if ($today -eq $script:usageDate) { return }
    $script:usageDate = $today
    $script:usage = @{}
    Save-Usage
    Refresh-Apps
}

$btnClose.Add_Click({ $window.Hide() })
$window.Add_KeyDown({ param($s, $e) if ($e.Key -eq 'Escape') { $window.Hide() } })
$card.Add_MouseLeftButtonDown({ try { $window.DragMove() } catch { } })

$applyClip = {
    $w = $window.ActualWidth
    $h = $window.ActualHeight
    if ($w -lt 1 -or $h -lt 1) { return }
    $grid.Clip = New-Object Windows.Media.RectangleGeometry((New-Object Windows.Rect(0, 0, $w, $h)), 18, 18)
    # окно меняет высоту при смене вкладки — фон должен закрывать новую площадь
    $back.Width = $w + 80
    $back.Height = $h + 80
    [Windows.Controls.Canvas]::SetLeft($back, -40)
    [Windows.Controls.Canvas]::SetTop($back, -40)
}

$capture = {
    try {
        $w = [int]$window.ActualWidth
        $h = [int]$window.ActualHeight
        if ($w -lt 10 -or $h -lt 10) { return }
        $src = [Windows.PresentationSource]::FromVisual($window)
        $scale = 1.0
        if ($src -and $src.CompositionTarget) { $scale = $src.CompositionTarget.TransformToDevice.M11 }
        $window.Visibility = 'Hidden'
        Start-Sleep -Milliseconds 40
        $bmp = New-Object Drawing.Bitmap ([int]($w * $scale)), ([int]($h * $scale))
        $g = [Drawing.Graphics]::FromImage($bmp)
        $g.CopyFromScreen([int]($window.Left * $scale), [int]($window.Top * $scale), 0, 0, $bmp.Size)
        $g.Dispose()
        $window.Visibility = 'Visible'
        $half = New-Object Drawing.Bitmap ([int]($bmp.Width / 2)), ([int]($bmp.Height / 2))
        $g2 = [Drawing.Graphics]::FromImage($half)
        $g2.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear
        $g2.DrawImage($bmp, 0, 0, $half.Width, $half.Height)
        $g2.Dispose()
        $bmp.Dispose()
        $ms = New-Object IO.MemoryStream
        $half.Save($ms, [Drawing.Imaging.ImageFormat]::Png)
        $half.Dispose()
        $ms.Position = 0
        $image = New-Object Windows.Media.Imaging.BitmapImage
        $image.BeginInit()
        $image.StreamSource = $ms
        $image.CacheOption = [Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        $image.EndInit()
        $image.Freeze()
        $back.Source = $image
        $back.Width = $w + 80
        $back.Height = $h + 80
        [Windows.Controls.Canvas]::SetLeft($back, -40)
        [Windows.Controls.Canvas]::SetTop($back, -40)
    } catch {
        try { $window.Visibility = 'Visible' } catch { }
    }
}

Set-TimeFields $script:totalSeconds
Update-Hands
Set-Tab 'timer'
$window.Opacity = 0
$work = [Windows.SystemParameters]::WorkArea
$window.Left = $work.Left + ($work.Width - 380) / 2
$window.Top = $work.Top + 40
$window.Show()
$window.UpdateLayout()
& $applyClip
$window.Add_SizeChanged({ & $applyClip })
& $capture
$window.Opacity = [double]$script:cfg.Opacity / 100.0

$script:moveTimer = New-Object Windows.Threading.DispatcherTimer
$script:moveTimer.Interval = [TimeSpan]::FromMilliseconds(200)
$script:moveTimer.Add_Tick({
    $script:moveTimer.Stop()
    & $capture
})
$window.Add_LocationChanged({
    if ($script:moveTimer) { $script:moveTimer.Stop(); $script:moveTimer.Start() }
})

# --- один экземпляр: повторный запуск просто показывает уже открытое окно ---
$created = $false
$script:mutex = New-Object Threading.Mutex($true, 'Local\TimerAppMutex', [ref]$created)
if (-not $created) {
    try { [IO.File]::WriteAllText((Join-Path $script:root 'show.flag'), 'show') } catch { }
    return
}
$script:showFlag = Join-Path $script:root 'show.flag'
$script:flagTimer = New-Object Windows.Threading.DispatcherTimer
$script:flagTimer.Interval = [TimeSpan]::FromMilliseconds(500)
$script:flagTimer.Add_Tick({
    if (Test-Path -LiteralPath $script:showFlag) {
        Remove-Item -LiteralPath $script:showFlag -Force -ErrorAction SilentlyContinue
        try { $window.Show(); $window.Activate() | Out-Null } catch { }
    }
})
$script:flagTimer.Start()

# значок в трее, чтобы вернуть окно после закрытия
$tray = New-Object Windows.Forms.NotifyIcon
$tray.Icon = [Drawing.SystemIcons]::Application
$tray.Text = 'Таймер'
$trayMenu = New-Object Windows.Forms.ContextMenuStrip
$itemOpen = $trayMenu.Items.Add('Открыть')
$itemOpen.Add_Click({ try { $window.Show(); $window.Activate() | Out-Null } catch { } })
$itemExit = $trayMenu.Items.Add('Выход')
$itemExit.Add_Click({
    Save-Reminders
    try { $tray.Visible = $false; $tray.Dispose() } catch { }
    [Environment]::Exit(0)
})
$tray.ContextMenuStrip = $trayMenu
$tray.Visible = $true
$tray.Add_DoubleClick({ try { $window.Show(); $window.Activate() | Out-Null } catch { } })
$tray.Add_BalloonTipClicked({ Set-Tab 'rem'; try { $window.Show(); $window.Activate() | Out-Null } catch { } })

# отдельный фоновый учёт времени в приложениях (работает и без таймера)
try {
    $trackerVbs = Join-Path $script:root 'UsageTracker.vbs'
    if (Test-Path -LiteralPath $trackerVbs) {
        Start-Process -FilePath 'wscript.exe' -ArgumentList ('"' + $trackerVbs + '"') | Out-Null
    }
} catch { }

Load-Reminders
Refresh-RemList
Load-Usage
Refresh-Apps

$script:mainTimer = New-Object Windows.Threading.DispatcherTimer
$script:mainTimer.Interval = [TimeSpan]::FromSeconds(1)
$script:mainTimer.Add_Tick({
    try {
        if (Test-Path -LiteralPath $script:volFile) {
            $stamp = (Get-Item -LiteralPath $script:volFile).LastWriteTimeUtc
            if ($stamp -ne $script:volStamp) {
                $script:volStamp = $stamp
                $fresh = [IO.File]::ReadAllText($script:volFile, [Text.Encoding]::UTF8) | ConvertFrom-Json
                if ($null -ne $fresh.TickVolume) { $script:cfg.TickVolume = [int]$fresh.TickVolume }
                if ($null -ne $fresh.EndVolume) { $script:cfg.EndVolume = [int]$fresh.EndVolume }
                if ($null -ne $fresh.TickSound) { $script:cfg.TickSound = [int]$fresh.TickSound }
                if ($null -ne $fresh.EndSound) { $script:cfg.EndSound = [int]$fresh.EndSound }
                $script:cfg.TickFile = [string]$fresh.TickFile
                $script:cfg.EndFile = [string]$fresh.EndFile
                $script:cfg.PicFile = [string]$fresh.PicFile
                $script:cfg.PicOpacity = [int]$fresh.PicOpacity
                $script:cfg.PicZoom = [int]$fresh.PicZoom
                $script:cfg.PicFit = [bool]$fresh.PicFit
                Apply-Pic
            }
        }
    } catch { }
    Reload-Usage
    Invoke-ReminderCheck
    $script:usageTicks++
    if ($script:usageTicks % 2 -eq 0 -and $panelApps.Visibility -eq 'Visible') { Refresh-Apps }
})
$script:mainTimer.Start()

[Windows.Threading.Dispatcher]::Run()
